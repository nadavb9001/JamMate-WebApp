#pragma once
// JamMate DRUM 240x320 portrait renderer (TFT_eSPI, RGB565, no bitmap resources).
// Hero 34..166: large DSP beat-of-bar and beat markers; controls 174..289;
// status footer 294..319: CPU percentage + small DSP beat LED.
#include <TFT_eSPI.h>
#include <stdint.h>
#include <stdio.h>

namespace JmDrumPortrait {
static constexpr int Width=240, Height=320;
struct Model {
    uint8_t beat = 0;      // ONE-BASED; 0=unknown/offline
    uint8_t beats = 4;     // felt beats from DSP BEAT payload (6/8 -> 2)
    uint32_t bar = 0;      // DSP bar index (zero-based)
    bool clock_active = false;
    bool beat_lit = false; // only lit briefly after an actual BEAT packet
    bool running = false;  // drum state
    uint8_t style = 0;    // 0..3
    uint8_t bpm = 120;
    uint8_t level = 80;    // percent
    uint8_t selected = 0; // 0 Style, 1 BPM, 2 Level, 3 Drums
    bool editing = false;
    int cpu = -1;
};
inline uint16_t color(TFT_eSPI& t, uint8_t r, uint8_t g, uint8_t b){return t.color565(r,g,b);}
inline uint16_t bg(TFT_eSPI& t){return color(t,3,9,21);}
inline uint16_t panel(TFT_eSPI& t){return color(t,10,23,41);}
inline uint16_t edge(TFT_eSPI& t){return color(t,39,69,95);}
inline uint16_t text(TFT_eSPI& t){return color(t,240,250,255);}
inline uint16_t dim(TFT_eSPI& t){return color(t,161,192,217);}
inline uint16_t cyan(TFT_eSPI& t){return color(t,0,222,253);}
inline uint16_t green(TFT_eSPI& t){return color(t,0,241,137);}
inline uint16_t amber(TFT_eSPI& t){return color(t,255,182,45);}
inline void centered(TFT_eSPI& t,const char* s,int x,int y,int font,uint16_t fg,uint16_t b){
    t.setTextDatum(MC_DATUM); t.setTextFont(font); t.setTextColor(fg,b); t.drawString(s,x,y,font);
}
inline void left(TFT_eSPI& t,const char* s,int x,int y,int font,uint16_t fg,uint16_t b){
    t.setTextDatum(TL_DATUM); t.setTextFont(font); t.setTextColor(fg,b); t.drawString(s,x,y,font);
}
inline void header(TFT_eSPI& t){
    const uint16_t c=color(t,8,25,44); t.fillRect(0,0,Width,30,c);
    t.drawFastHLine(0,29,Width,edge(t));t.fillRoundRect(8,6,4,16,1,color(t,255,74,98));
    left(t,"DRUMS",18,3,4,text(t),c);
}
// Dynamic redraw covers ONLY 34..167 and is safe every time a DSP beat arrives.
inline void beatArea(TFT_eSPI& t,const Model& m){
    const uint16_t area=color(t,7,20,35);
    t.fillRoundRect(7,34,226,134,8,area);
    t.drawRoundRect(7,34,226,134,8,m.clock_active?cyan(t):edge(t));
    left(t,"BEAT",18,39,2,dim(t),area);
    char bar[22];
    if(m.clock_active) snprintf(bar,sizeof(bar),"BAR %lu",(unsigned long)(m.bar+1u));
    else snprintf(bar,sizeof(bar),"BAR --");
    left(t,bar,152,39,2,dim(t),area);

    char fraction[18];
    if(m.clock_active && m.beat>=1 && m.beat<=m.beats)
        snprintf(fraction,sizeof(fraction),"%u/%u",(unsigned)m.beat,(unsigned)m.beats);
    else snprintf(fraction,sizeof(fraction),"--/%u",(unsigned)(m.beats?m.beats:4));
    // Built-in TFT font 4 doubled: large legible ~44px readout; no free fonts.
    t.setTextDatum(MC_DATUM);t.setTextFont(4);t.setTextSize(2);
    t.setTextColor(m.clock_active?(m.beat==1?amber(t):text(t)):dim(t),area);
    t.drawString(fraction,120,91,4); t.setTextSize(1);

    // Bright moving beat marker. Supports non-4/4 felt beats; no static 4/4 assumptions.
    uint8_t count=m.beats?m.beats:4;
    if(count>16) count=16;  // avoid invisible tiny markers on the 240px LCD
    const int usable=204; const int pitch=usable/count; const int first=18+pitch/2;
    for(int i=0;i<count;++i){
        const int cx=first+i*pitch;
        const bool active=m.clock_active && m.beat==i+1;
        const bool down=(i==0);
        const uint16_t pulse=down?amber(t):green(t);
        t.fillCircle(cx,146,active?8:5,active?(m.beat_lit?text(t):pulse):color(t,32,66,83));
        if(active)t.drawCircle(cx,146,10,pulse);
    }
}
// An 8-bit beat canvas (226x134 ~30 KB), pushed as one SPI transaction.
inline void beatAreaSprite(TFT_eSprite& s,const Model& m){
  const uint16_t area=0x10A6;
  s.fillSprite(area);
  s.drawRoundRect(0,0,226,134,8,m.clock_active?0x07FF:0x4A4F);
  s.setTextDatum(TL_DATUM);s.setTextFont(2);
  s.setTextColor(0xC65A,area);
  s.drawString("BEAT",11,5,2);
  char b[24];
  if(m.clock_active)snprintf(b,sizeof(b),"BAR %lu",(unsigned long)(m.bar+1));
  else strcpy(b,"BAR --");
  s.drawString(b,145,5,2);
  if(m.clock_active&&m.beat&&m.beat<=m.beats)
    snprintf(b,sizeof(b),"%u/%u",(unsigned)m.beat,(unsigned)m.beats);
  else snprintf(b,sizeof(b),"--/%u",(unsigned)(m.beats?m.beats:4));
  s.setTextDatum(MC_DATUM);s.setTextFont(4);s.setTextSize(2);
  s.setTextColor(m.clock_active?(m.beat==1?0xFD20:TFT_WHITE):0xC65A,area);
  s.drawString(b,113,57,4);s.setTextSize(1);
  int count=m.beats?m.beats:4;if(count>16)count=16;
  const int pitch=204/count,first=11+pitch/2;
  for(int i=0;i<count;++i){
    const int cx=first+i*pitch;
    const bool active=m.clock_active&&m.beat==i+1;
    const uint16_t pulse=i==0?0xFD20:0x07E8;
    s.fillCircle(cx,112,active?8:5,active?(m.beat_lit?TFT_WHITE:pulse):0x3209);
    if(active)s.drawCircle(cx,112,10,pulse);
  }
}
inline void settings(TFT_eSPI& t,const Model& m){
    static const char* styles[]={"Rock","Pop","Jazz","Metal"};
    static const char* labels[]={"STYLE","BPM","LEVEL","DRUMS"};
    char values[4][20]{};
    snprintf(values[0],sizeof(values[0]),"%s",styles[m.style<4?m.style:0]);
    snprintf(values[1],sizeof(values[1]),"%u",(unsigned)m.bpm);
    snprintf(values[2],sizeof(values[2]),"%u%%",(unsigned)m.level);
    snprintf(values[3],sizeof(values[3]),"%s",m.running?"ON":"OFF");
    for(int i=0;i<4;++i){
        const int y=175+29*i;
        const bool selected=(m.selected==i);
        const uint16_t boundary=selected?(m.editing?amber(t):cyan(t)):edge(t);
        const uint16_t fill=selected?(m.editing?color(t,46,29,17):color(t,12,40,57)):panel(t);
        t.fillRoundRect(7,y,226,26,5,fill);t.drawRoundRect(7,y,226,26,5,boundary);
        left(t,labels[i],15,y+4,2,selected?text(t):dim(t),fill);
        t.setTextDatum(MR_DATUM);t.setTextFont(2);
        t.setTextColor(selected?(m.editing?amber(t):cyan(t)):text(t),fill);
        t.drawString(values[i],222,y+13,2);
        if(i==2){ // narrow level meter at bottom, no added text
            t.fillRect(91,y+21,55,2,edge(t));
            t.fillRect(91,y+21,((m.level<=100?m.level:100)*55)/100,2,green(t));
        }
    }
}
inline void footer(TFT_eSPI& t,const Model& m){
    const uint16_t fill=color(t,8,24,39);
    t.fillRect(0,294,Width,26,fill);t.drawFastHLine(0,294,Width,edge(t));
    char b[20]; if(m.cpu>=0)snprintf(b,sizeof(b),"CPU %d%%",m.cpu<=100?m.cpu:100);
    else snprintf(b,sizeof(b),"CPU --");
    left(t,b,9,299,2,text(t),fill);
    t.fillRoundRect(103,304,85,6,2,color(t,29,54,77));
    if(m.cpu>0)t.fillRoundRect(103,304,((m.cpu<=100?m.cpu:100)*85)/100,6,2,cyan(t));
    t.fillCircle(223,307,10,color(t,7,47,40));
    t.drawCircle(223,307,8,color(t,27,138,85));
    t.fillCircle(223,307,5,m.clock_active&&m.beat_lit?(m.beat==1?amber(t):green(t)):color(t,25,60,49));
}
inline void draw(TFT_eSPI& t,const Model& m){
    t.fillScreen(bg(t));header(t);beatArea(t,m);settings(t,m);footer(t,m);
}
} // namespace JmDrumPortrait
