#pragma once
#include "JmWebSyncProtocol.hpp"
#include "JmDefaultConfig.hpp"

struct BleCommand { uint8_t* data; size_t size; uint32_t epoch; };
static QueueHandle_t s_bleCommands=nullptr;
static uint8_t s_webDrumGrid[144]={};
static uint16_t s_webGridRevision=0;
static uint32_t s_webReadyEpoch=0;

static void webSlotPath(uint8_t bank,uint8_t slot,char* out,size_t n){
  snprintf(out,n,bank<5?"/presets/f_%u_%u.bin":"/presets/c_%u_%u.bin",bank<5?bank:bank-5,slot);
}
static bool writeVerifiedFile(const char* path,const uint8_t* bytes,size_t n){
  const char* temp="/.web-write.tmp";
  File f=LittleFS.open(temp,"w");if(!f)return false;
  const size_t written=f.write(bytes,n);f.close();
  if(written!=n){LittleFS.remove(temp);return false;}
  f=LittleFS.open(temp,"r");bool ok=f&&f.size()==n;
  uint8_t check[96];size_t off=0;
  while(ok&&off<n){size_t k=std::min(sizeof(check),n-off);ok=f.read(check,k)==k&&!memcmp(check,bytes+off,k);off+=k;}
  f.close();
  if(!ok||!LittleFS.rename(temp,path)){LittleFS.remove(temp);return false;}
  return true;
}
static String webConfigText(){
  File f=LittleFS.open("/config.json","r");
  if(!f)return String();
  if(f.size()>4096){f.close();return String();}
  String text=f.readString();f.close();return text;
}
static void ensureWebConfig(){
  if(!LittleFS.exists("/config.json"))
    writeVerifiedFile("/config.json",(const uint8_t*)g_webDefaultConfig,strlen(g_webDefaultConfig));
}
static void sendWebConfig(){
  String text=webConfigText();
  std::vector<uint8_t> payload(text.length()+1);payload[0]=1;
  memcpy(payload.data()+1,text.c_str(),text.length());
  btManager.sendBLEBlob(0x55,payload.data(),payload.size());
}
static void receiveWebConfig(const uint8_t* p,size_t n){
  static String pending;
  static uint16_t next=0,last=0xffff,lastCrc=0,committedCrc=0;
  static bool active=false;
  const uint16_t index=JmWebSync::get16(p),chunkCrc=JmWebSync::crc16(p,n);
  uint8_t status=0;
  if(index==last && chunkCrc==lastCrc){
    // Duplicate of the most recently acknowledged chunk is idempotent.
  }else{
    if(index==0){pending="";next=0;active=true;committedCrc=0;}
    if(!active||index!=next||pending.length()+n-3>4096||p[2]>1)status=2;
    else{
      for(size_t i=3;i<n;i++)pending+=(char)p[i];
      if(p[2]){
        uint8_t layout[18][2];
        if(!JmWebSync::validateConfig(pending.c_str(),pending.length(),layout))status=3;
        else if(!writeVerifiedFile("/config.json",(const uint8_t*)pending.c_str(),pending.length()))status=1;
        else{
          loadFxLayoutFromConfig();
          committedCrc=JmWebSync::crc16((const uint8_t*)pending.c_str(),pending.length());
        }
        active=false;
      }
      if(!status){last=index;lastCrc=chunkCrc;next++;}
    }
  }
  uint8_t ack[6]={0x53,status};JmWebSync::put16(ack+2,index);JmWebSync::put16(ack+4,committedCrc);
  btManager.sendBLEData(ack,sizeof(ack));
}
static bool validWebPreset(const uint8_t* b,size_t n){
  if(n<4||n>MAX_BLOB_SIZE||b[0]!=3||b[3]>=PRESET_NAME_LENGTH||size_t(b[3])+4>n)return false;
  size_t off=4+b[3];uint32_t seen=0;
  while(off<n){
    if(n-off<2)return false;
    uint8_t id=b[off++],count=b[off++];
    if(id==0xfe)return count<=12 && off+size_t(count)*5==n && seen==0x3ffff;
    if(id>=18||(seen&(1u<<id))||count!=1+FX_LAYOUT[id][0]+FX_LAYOUT[id][1]||off+count>n)return false;
    seen|=1u<<id;off+=count;
  }
  return seen==0x3ffff;
}
static void presetAck(uint8_t cmd,uint8_t status,uint8_t bank,uint8_t slot){
  uint8_t bytes[]={0x59,cmd,status,bank,slot};btManager.sendBLEData(bytes,sizeof(bytes));
}
static size_t webReadSlot(uint8_t bank,uint8_t slot,uint8_t* bytes){
  // Cache normalized blobs, with a fixed volume: global volume is not preset data.
  Preset preset{};
  if(!loadPreset(bank,slot,preset))return 0;
  preset.masterVolume=20;
  return serializeStructToBlob(preset,bytes);
}
static void sendWebCatalog(){
  uint8_t catalog[2+35*6]={1,35};uint8_t bytes[MAX_BLOB_SIZE];
  for(uint8_t b=0;b<7;b++)for(uint8_t s=0;s<5;s++){
    size_t n=webReadSlot(b,s,bytes),o=2+(b*5+s)*6;
    catalog[o]=b;catalog[o+1]=s;JmWebSync::put16(catalog+o+2,n);
    JmWebSync::put16(catalog+o+4,JmWebSync::crc16(bytes,n));
  }
  btManager.sendBLEBlob(0x38,catalog,sizeof(catalog));
}
static void sendWebSlot(uint8_t bank,uint8_t slot){
  if(!JmWebSync::validSlot(bank,slot))return;
  uint8_t bytes[MAX_BLOB_SIZE+2]={bank,slot};size_t n=webReadSlot(bank,slot,bytes+2);
  if(n)btManager.sendBLEBlob(0x3a,bytes,n+2);
}
void sendWebSnapshot(bool force){
  if(!btManager.connected()||s_webReadyEpoch!=btManager.session())return;
  static bool initialized=false;
  static uint8_t selection[4],controls[18];
  static uint16_t presetCrc=0;
  static Preset previous{};
  uint8_t selected[]={currentPreset.bank,currentPreset.number,state.volume,currentPreset.bpm};
  const bool presetSelected=!initialized||memcmp(selection,selected,2);
  const bool selectionChanged=!initialized||memcmp(selection,selected,4);
  if(force||selectionChanged){
    memcpy(selection,selected,4);uint8_t frame[5]={0x3f};memcpy(frame+1,selected,4);btManager.sendBLEData(frame,5);
  }
  uint8_t values[]={uint8_t(display.drumEnabled),uint8_t(display.drumLevel),uint8_t(display.drumStyle),
    uint8_t(display.drumPattern),uint8_t(currentPreset.bpm),uint8_t(display.looperEnabled),uint8_t(display.looperLevel),
    uint8_t(display.looperSync),uint8_t(display.looperAutoArm),uint8_t(display.looperBars),uint8_t(display.looperNum),
    uint8_t(display.looperPlayMode),uint8_t(display.looperBounce),display.looperMute,display.looperSolo,display.drumFill,
    uint8_t(display.isTunerActive()),uint8_t(display.bypassEnabled)};
  if(force||!initialized||memcmp(values,controls,18)){
    memcpy(controls,values,18);uint8_t frame[19]={0x3e};memcpy(frame+1,values,18);btManager.sendBLEData(frame,19);
  }
  uint8_t bytes[MAX_BLOB_SIZE];size_t n=serializeStructToBlob(currentPreset,bytes);
  const uint16_t crc=JmWebSync::crc16(bytes,n);
  if(force||presetSelected||strcmp(previous.name,currentPreset.name)){
    btManager.sendBLEBlob(0x34,bytes,n);
  }else if(crc!=presetCrc){
    unsigned changes=0;
    for(uint8_t fx=0;fx<18;fx++){
      changes+=previous.effects[fx].enabled!=currentPreset.effects[fx].enabled;
      for(uint8_t k=0;k<FX_LAYOUT[fx][0];k++)changes+=previous.effects[fx].knobs[k]!=currentPreset.effects[fx].knobs[k];
      for(uint8_t d=0;d<FX_LAYOUT[fx][1];d++)changes+=previous.effects[fx].dropdowns[d]!=currentPreset.effects[fx].dropdowns[d];
    }
    if(changes>12)btManager.sendBLEBlob(0x34,bytes,n);
    else for(uint8_t fx=0;fx<18;fx++){
      const auto& now=currentPreset.effects[fx];const auto& old=previous.effects[fx];
      for(uint8_t flat=0;flat<=FX_LAYOUT[fx][0]+FX_LAYOUT[fx][1];flat++){
        uint8_t v=flat==0?now.enabled:flat<=FX_LAYOUT[fx][0]?now.knobs[flat-1]:now.dropdowns[flat-FX_LAYOUT[fx][0]-1];
        uint8_t before=flat==0?old.enabled:flat<=FX_LAYOUT[fx][0]?old.knobs[flat-1]:old.dropdowns[flat-FX_LAYOUT[fx][0]-1];
        if(v!=before){uint8_t frame[]={0x36,fx,flat,v};btManager.sendBLEData(frame,sizeof(frame));}
      }
    }
    for(uint8_t b=0;b<12;b++)if(memcmp(&previous.eqPoints[b],&currentPreset.eqPoints[b],sizeof(EQPoint))){
      const auto& point=currentPreset.eqPoints[b];uint8_t frame[]={0x22,b,uint8_t(point.enabled),0,0,uint8_t(point.gain),point.q};
      JmWebSync::put16(frame+3,point.freq);btManager.sendBLEData(frame,sizeof(frame));
    }
  }
  presetCrc=crc;previous=currentPreset;
  if(force&&s_webGridRevision)btManager.sendBLEBlob(0x57,s_webDrumGrid,144);
  initialized=true;
}
void serviceWebSync(){
  static uint32_t last=0,reconcile=0,catalog=0;static bool wasConnected=false;
  const bool connected=btManager.connected();
  if(!connected||s_webReadyEpoch!=btManager.session()){wasConnected=false;return;}
  if(millis()-last<200&&wasConnected)return;
  last=millis();const bool force=!wasConnected||millis()-reconcile>5000;
  sendWebSnapshot(force);if(force)reconcile=millis();wasConnected=true;
  if(millis()-catalog>30000){catalog=millis();sendWebCatalog();}
  // This phase is the same ESP display estimate, not a DSP sample playhead.
  const bool active=display.looperTrackState==3||display.looperTrackState==4;
  double phase=-1;
  if(active&&display.beatClock.Active(millis()))phase=display.looperBeatPhase.Fraction(display.beatClock,millis(),uint8_t(display.looperBars),display.looperTrackState==3);
  if(active&&phase<0){const uint32_t duration=display.loopLength?display.loopLength:2000;phase=double((millis()-display.loopStart)%duration)/duration;}
  uint8_t loop[]={0x3d,uint8_t(display.looperTrackState),uint8_t(display.loopLayerCount),
    uint8_t(phase>=0?std::max(0,std::min(100,int(phase*100))):255),0,0};
  JmWebSync::put16(loop+4,std::min(uint32_t(65535),uint32_t(display.loopLength)));
  btManager.sendBLEData(loop,sizeof(loop));
}
