#pragma once

#include "BluetoothA2DPSink.h"
#include "JmWebSyncProtocol.hpp"
#include <vector>
#include <algorithm>
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>
#include <BLEClient.h>
#include <BLEScan.h>

#include "esp_bt_main.h"
#include "esp_bt_device.h"
#include "esp_gap_ble_api.h"
#include "esp_gap_bt_api.h"
#include "driver/i2s.h"

// Set to 1 to enable BLE MIDI client (scan, connect, notify), 0 to disable
#define USE_MIDI 0

// UUIDs for WebApp Control
#define BLE_SERVICE_UUID "6e400001-b5a3-f393-e0a9-e50e24dcca9f"
#define BLE_CHARACTERISTIC_UUID "6e400002-b5a3-f393-e0a9-e50e24dcca9f"

#if USE_MIDI
// MIDI CONTROLLER CONFIG (M-VAVE Chocolate)
static BLEAddress midiTargetAddress("34:DE:45:D8:6B:A6");
static BLEUUID midiServiceUUID("03B80E5A-EDE8-4B33-A751-6CE34EC4C700");
static BLEUUID midiCharUUID("7772E5DB-3868-4112-A1A9-F2669D106BF3");
#endif

class BluetoothManager {
public:
  typedef void (*BLEDataCallback)(uint8_t* data, size_t len);
  typedef void (*MidiCallbackFunction)(uint8_t* data, size_t len);

#if USE_MIDI
  static MidiCallbackFunction onMidiReceive;
#endif

  BluetoothManager()
    : pServer(nullptr), pControlChar(nullptr), pAdvertising(nullptr),
      bleControlConnected(false), a2dpEnabled(false), bleDataCallback(nullptr),
      pCurrentPreset(nullptr), lastHeartbeatMs(0)
#if USE_MIDI
      , pMidiClient(nullptr), pRemoteMidiChar(nullptr), midiConnected(false)
#endif
      {}

  void begin(const char* deviceName = "JamMate", bool enableA2DP = true) {
    Serial.println("[BT] Initializing Hybrid Mode...");

    // 1. Start A2DP (Audio) FIRST
    if (enableA2DP) {
      setupA2DP("JamMate Audio");
      delay(10);
    }

    // 2. Initialize BLE Stack
    BLEDevice::init(deviceName);
    delay(10);
    BLEDevice::setMTU(517);
    BLEDevice::setPower(ESP_PWR_LVL_P9); // max TX power for range/stability

    // 3. Setup WebApp Server (GATT)
    setupBLEGATT();
    delay(10);
    // 4. Setup MIDI Client
#if USE_MIDI
    pMidiClient = BLEDevice::createClient();
    delay(10);
    pMidiClient->setClientCallbacks(new MidiClientCallbacks(this));
    delay(10);
#endif

    // 5. Force Classic Visibility
    esp_bt_gap_set_scan_mode(ESP_BT_CONNECTABLE, ESP_BT_GENERAL_DISCOVERABLE);

    Serial.println("[BT] ✓ Hybrid Mode Ready");

    // NOTE: We do NOT auto-connect here anymore.
    // We will trigger it in setup() to ensure callbacks are ready.
  }

  // --- Configuration ---
  void setA2DPPinConfig(const i2s_pin_config_t& pinConfig) {
    a2dp_sink.set_pin_config(pinConfig);
  }

  void setBLEDataCallback(BLEDataCallback callback) {
    bleDataCallback = callback;
  }
#if USE_MIDI
  void setMidiCallback(MidiCallbackFunction callback) {
    onMidiReceive = callback;
  }
#endif
  void setCurrentPreset(Preset* preset) {
    pCurrentPreset = preset;
  }

  // [UPDATED] Trigger MIDI Connection Task on Core 0
  void triggerMidiConnectionAttempt() {
#if USE_MIDI
    if (midiConnected) {
      Serial.println("[MIDI] Already connected.");
      return;
    }
    // Use Core 0 (Protocol Core) to reduce interference with Audio/UI
    xTaskCreatePinnedToCore(midiConnectTask, "MidiConn", 4096, this, 1, NULL, 0);
#else
    Serial.println("[MIDI] MIDI disabled (USE_MIDI=0).");
#endif
  }

  // --- A2DP Control ---
  void enableA2DP() {
    if (!a2dpEnabled) {
      setupA2DP("JamMate Audio");
    }
  }

  void disableA2DP() {
    if (a2dpEnabled) {
      a2dp_sink.end();
      a2dpEnabled = false;
    }
  }

  void setA2DPvolume(uint8_t volume) {
    if (a2dpEnabled) a2dp_sink.set_volume(volume);
  }

  // No-op: heartbeat removed — BLE notify every 4 s stole A2DP radio slots causing audio drops.
  // BLE link stays alive via the controller; webapp sends its own 0x01 keepalive every 10 s.
  void tick() { }

  bool isA2DPStreaming() const { return a2dpEnabled; }

  // --- Data Sending ---
  bool connected() const { return bleControlConnected; }
  uint32_t session() const { return generation; }
  void sendBLEData(const uint8_t* data,size_t len){
    if(!connected()||!txQueue||!len||len>JmWebSync::MAX_FRAME)return;
    Outgoing packet{(uint8_t*)malloc(len),len,generation};
    if(!packet.data)return;
    memcpy(packet.data,data,len);
    if(xQueueSend(txQueue,&packet,0)!=pdTRUE)free(packet.data);
  }
  void transmit(const uint8_t* data, size_t len,uint32_t epoch) {
    if (!pControlChar || !bleControlConnected || !len || len>JmWebSync::MAX_FRAME || !txMutex) return;
    xSemaphoreTake(txMutex, portMAX_DELAY);
    const uint16_t tx=++txSequence;
    const uint16_t crc=JmWebSync::crc16(data,len);
    const size_t mtu=pServer->getPeerMTU(pServer->getConnId());
    const size_t att=mtu>23?std::min(size_t(244),mtu-3):20;
    uint8_t fragment[244];
    for(size_t off=0;off<len&&bleControlConnected&&generation==epoch;){
      const size_t n=std::min(att-JmWebSync::FRAME_HEADER,len-off);
      fragment[0]=0x7e;fragment[1]=1;
      JmWebSync::put16(fragment+2,tx);JmWebSync::put16(fragment+4,off);
      JmWebSync::put16(fragment+6,len);JmWebSync::put16(fragment+8,crc);
      memcpy(fragment+10,data+off,n);
      // WRITE and NOTIFY share this characteristic. Do not use setValue/notify:
      // an incoming write can replace m_value between those two calls.
      esp_err_t result=ESP_FAIL;const uint32_t start=millis();
      do {
        if(webCongested){delay(20);continue;}
        result=esp_ble_gatts_send_indicate(webGattsIf,pServer->getConnId(),pControlChar->getHandle(),n+10,fragment,false);
        if(result==ESP_OK)break;
        delay(20);
      }while(bleControlConnected&&generation==epoch&&millis()-start<1000);
      if(result!=ESP_OK){Serial.printf("[WEB] Notify failed cmd=%02x offset=%u error=%d\n",data[0],unsigned(off),int(result));break;}
      off+=n;delay(8);
    }
    xSemaphoreGive(txMutex);
  }
  void sendBLEBlob(uint8_t cmd,const uint8_t* data,size_t len){
    if(len+3>JmWebSync::MAX_FRAME)return;
    std::vector<uint8_t> frame(len+3);
    frame[0]=cmd;JmWebSync::put16(frame.data()+1,len);
    if(len)memcpy(frame.data()+3,data,len);
    sendBLEData(frame.data(),frame.size());
  }

private:
  struct Outgoing {uint8_t* data;size_t size;uint32_t epoch;};
  QueueHandle_t txQueue=nullptr;
  uint32_t generation=0;
  bool peerKnown=false;
  inline static esp_gatt_if_t webGattsIf=ESP_GATT_IF_NONE;
  inline static volatile bool webCongested=false;
  static void observeGatts(esp_gatts_cb_event_t event,esp_gatt_if_t interface,esp_ble_gatts_cb_param_t* param){
    if(event==ESP_GATTS_CONNECT_EVT){webGattsIf=interface;webCongested=false;}
    if(event==ESP_GATTS_CONGEST_EVT)webCongested=param->congest.congested;
  }
  static void transmitTask(void* context){
    auto* self=(BluetoothManager*)context;Outgoing packet;
    for(;;)if(xQueueReceive(self->txQueue,&packet,portMAX_DELAY)==pdTRUE){
      if(self->connected()&&packet.epoch==self->generation)self->transmit(packet.data,packet.size,packet.epoch);
      free(packet.data);
    }
  }
  SemaphoreHandle_t txMutex=nullptr;
  uint16_t txSequence=0;
  JmWebSync::Receiver rx;
  private:
  BLEServer* pServer;
  BLECharacteristic* pControlChar;
  BLEAdvertising* pAdvertising;
  bool bleControlConnected;
  bool a2dpEnabled;
  BluetoothA2DPSink a2dp_sink;
  BLEDataCallback bleDataCallback;
  Preset* pCurrentPreset;
  uint32_t lastHeartbeatMs;
  uint8_t peerBDA[6];

#if USE_MIDI
  BLEClient* pMidiClient;
  BLERemoteCharacteristic* pRemoteMidiChar;
  bool midiConnected;
  bool midiScanInProgress = false;
#endif


#if USE_MIDI
  static void midiNotifyCallback(BLERemoteCharacteristic* pChar, uint8_t* data, size_t length, bool isNotify) {
    if (onMidiReceive) {
      onMidiReceive(data, length);
    }
  }
#endif

  /*static void midiConnectTask(void* param) {
    BluetoothManager* instance = (BluetoothManager*)param;

    // [FIX 1] WAIT for system to stabilize before scanning
    vTaskDelay(2000 / portTICK_PERIOD_MS);

    Serial.println("[MIDI] Starting One-Shot Scan...");

    BLEScan* pBLEScan = BLEDevice::getScan();
    //pBLEScan->setActiveScan(true);
    //pBLEScan->setInterval(100);
    //pBLEScan->setWindow(50);
    pBLEScan->setActiveScan(false);  // [FIX] Passive Scan (Less radio usage)
    pBLEScan->setInterval(200);      // [FIX] Longer Interval (200ms)
    pBLEScan->setWindow(20);         // [FIX] Shorter Window (20ms) = 10% Duty Cycle

    BLEScanResults foundDevices = pBLEScan->start(5, false);
    bool found = false;

    for (int i = 0; i < foundDevices.getCount(); i++) {
      BLEAdvertisedDevice device = foundDevices.getDevice(i);
      if (device.getAddress().equals(midiTargetAddress)) {
        Serial.println("[MIDI] Pedal Found! Connecting...");
        found = true;
        break;
      }
    }

    if (found) {
      if (instance->pMidiClient->connect(midiTargetAddress)) {
        Serial.println("[MIDI] Connected to Device.");

        // [FIX 2] Critical Delay to let MTU/Link settle before service discovery
        vTaskDelay(500 / portTICK_PERIOD_MS);

        BLERemoteService* pRemoteService = instance->pMidiClient->getService(midiServiceUUID);
        if (pRemoteService) {
          instance->pRemoteMidiChar = pRemoteService->getCharacteristic(midiCharUUID);
          if (instance->pRemoteMidiChar && instance->pRemoteMidiChar->canNotify()) {

            // [FIX 3] Register for notify and WAIT
            instance->pRemoteMidiChar->registerForNotify(midiNotifyCallback);
            vTaskDelay(100 / portTICK_PERIOD_MS);

            instance->midiConnected = true;
            Serial.println("[MIDI] ✓ Notifications Registered");
          }
        }
      } else {
        Serial.println("[MIDI] Connection Failed.");
      }
    } else {
      Serial.println("[MIDI] Pedal not found.");
    }

    pBLEScan->clearResults();
    if (instance->pAdvertising) instance->pAdvertising->start();
    vTaskDelete(NULL);
  }
*/

 /* static void midiConnectTask(void* param) {
    BluetoothManager* instance = (BluetoothManager*)param;

    vTaskDelay(2000 / portTICK_PERIOD_MS);

    Serial.println("[MIDI] Starting One-Shot Scan...");

    BLEScan* pBLEScan = BLEDevice::getScan();
    pBLEScan->setActiveScan(false);
    pBLEScan->setInterval(200);
    pBLEScan->setWindow(20);

    BLEScanResults foundDevices = pBLEScan->start(5, false);
    bool found = false;

    for (int i = 0; i < foundDevices.getCount(); i++) {
      BLEAdvertisedDevice device = foundDevices.getDevice(i);
      if (device.getAddress().equals(midiTargetAddress)) {
        Serial.println("[MIDI] Pedal Found! Connecting...");
        found = true;
        break;
      }
    }

    if (found) {
      if (instance->pMidiClient->connect(midiTargetAddress)) {
        Serial.println("[MIDI] Connected to Device.");

        // [CRITICAL] Set MTU first before service discovery
        instance->pMidiClient->setMTU(517);
        if (instance->pMidiClient->updateConnParams(120, 120, 4, 600)) {
          Serial.println("[MIDI] 150ms interval set");
        } else {
          Serial.println("[MIDI] Failed to update connection params");
        }
        vTaskDelay(500 / portTICK_PERIOD_MS);

        BLERemoteService* pRemoteService = instance->pMidiClient->getService(midiServiceUUID);
        if (pRemoteService) {
          instance->pRemoteMidiChar = pRemoteService->getCharacteristic(midiCharUUID);
          if (instance->pRemoteMidiChar && instance->pRemoteMidiChar->canNotify()) {

            // [CRITICAL FIX] Get the CCCD descriptor
            BLERemoteDescriptor* pDesc = instance->pRemoteMidiChar->getDescriptor(BLEUUID((uint16_t)0x2902));
            if (pDesc) {
              // Write 0x0001 (Little Endian: 0x01, 0x00) to enable notifications
              // Some devices need 0x01, 0x00, others might need 0x01 only
              uint8_t notifyOn[] = { 0x01, 0x00 };

              // Write with response (true) and wait
              pDesc->writeValue(notifyOn, 2, true);
              Serial.println("[MIDI] CCCD Descriptor written");

              // Give the device time to process
              vTaskDelay(200 / portTICK_PERIOD_MS);

              // Verify by reading back
              std::string descVal = pDesc->readValue();
              Serial.printf("[MIDI] CCCD Value after write: ");
              for (size_t i = 0; i < descVal.length(); i++) {
                Serial.printf("%02X ", (uint8_t)descVal[i]);
              }
              Serial.println();
            } else {
              Serial.println("[MIDI] WARNING: No CCCD descriptor found!");
            }

            // [CRITICAL] Register for notify AFTER CCCD write, with false for descriptorRequiresRegistration
            // This prevents the library from trying to write CCCD again (which might fail)
            instance->pRemoteMidiChar->registerForNotify(midiNotifyCallback, true, false);

            vTaskDelay(100 / portTICK_PERIOD_MS);

            instance->midiConnected = true;
            Serial.println("[MIDI] ✓ Notifications Registered");
          } else {
            Serial.println("[MIDI] ERROR: Characteristic not found or cannot notify");
          }
        } else {
          Serial.println("[MIDI] ERROR: MIDI Service not found");
        }
      } else {
        Serial.println("[MIDI] Connection Failed.");
      }
    } else {
      Serial.println("[MIDI] Pedal not found.");
    }

    pBLEScan->clearResults();
    if (instance->pAdvertising) instance->pAdvertising->start();
    vTaskDelete(NULL);
  }*/

#if USE_MIDI
  static void midiConnectTask(void* param) {
    BluetoothManager* instance = (BluetoothManager*)param;
    instance->midiScanInProgress = true;

    // Wait for system to stabilize
    vTaskDelay(2000 / portTICK_PERIOD_MS);

    Serial.println("[MIDI] Starting One-Shot Scan...");

    BLEScan* pBLEScan = BLEDevice::getScan();
    
    // REMOVED: isScanning() doesn't exist in ESP32 BLE library 2.0.17
    // Just clear results and proceed
    pBLEScan->clearResults();
    pBLEScan->setActiveScan(false);
    pBLEScan->setInterval(400);
    pBLEScan->setWindow(20);

    bool found = false;
    
    // Scan for 5 seconds
    BLEScanResults foundDevices = pBLEScan->start(5, false);
    
    for (int i = 0; i < foundDevices.getCount(); i++) {
        BLEAdvertisedDevice device = foundDevices.getDevice(i);
        if (device.getAddress().equals(midiTargetAddress)) {
            Serial.println("[MIDI] Pedal Found! Connecting...");
            found = true;
            break;
        }
    }

    if (found) {
        Serial.println("[MIDI] Attempting connection...");
        
        if (instance->pMidiClient->connect(midiTargetAddress)) {
            Serial.println("[MIDI] Connected to Device.");

            // FIX: Use ESP-IDF function to update connection parameters
            // 150ms interval (120 * 1.25ms), 4x latency, 6s timeout
            esp_ble_conn_update_params_t conn_params = {
                .bda = {0},
                .min_int = 120,    // 150ms min interval (120 * 1.25ms)
                .max_int = 120,    // 150ms max interval
                .latency = 4,      // Skip up to 4 connection events
                .timeout = 600     // 6 second timeout (600 * 10ms)
            };
            // Copy the address
            memcpy(conn_params.bda, midiTargetAddress.getNative(), 6);
            
            esp_err_t err = esp_ble_gap_update_conn_params(&conn_params);
            if (err == ESP_OK) {
                Serial.println("[MIDI] Connection params updated: 150ms interval, 4x latency");
            } else {
                Serial.printf("[MIDI] Failed to update connection params: %d\n", err);
            }
            
            vTaskDelay(300 / portTICK_PERIOD_MS);

            BLERemoteService* pRemoteService = instance->pMidiClient->getService(midiServiceUUID);
            
            if (pRemoteService) {
                instance->pRemoteMidiChar = pRemoteService->getCharacteristic(midiCharUUID);
                
                if (instance->pRemoteMidiChar && instance->pRemoteMidiChar->canNotify()) {
                    // Write to CCCD to enable notifications
                    BLERemoteDescriptor* pDesc = instance->pRemoteMidiChar->getDescriptor(
                        BLEUUID((uint16_t)0x2902)
                    );
                    
                    if (pDesc) {
                        uint8_t notifyOn[] = {0x01, 0x00};
                        pDesc->writeValue(notifyOn, 2, true);
                        Serial.println("[MIDI] CCCD written");
                        vTaskDelay(100 / portTICK_PERIOD_MS);
                    }

                    // Register for notify
                    instance->pRemoteMidiChar->registerForNotify(midiNotifyCallback);
                    Serial.println("[MIDI] ✓ Notifications Registered");
                    instance->midiConnected = true;
                } else {
                    Serial.println("[MIDI] ERROR: Characteristic not found or cannot notify");
                }
            } else {
                Serial.println("[MIDI] ERROR: MIDI Service not found");
            }
        } else {
            Serial.println("[MIDI] Connection Failed.");
        }
    } else {
        Serial.println("[MIDI] Pedal not found.");
    }

    pBLEScan->clearResults();
    if (instance->pAdvertising && !instance->bleControlConnected) {
        instance->pAdvertising->start();
    }
    
    instance->midiScanInProgress = false;
    vTaskDelete(NULL);
}

  class MidiClientCallbacks : public BLEClientCallbacks {
    BluetoothManager* mgr;
  public:
    MidiClientCallbacks(BluetoothManager* m)
      : mgr(m) {}
    void onConnect(BLEClient* client) override {}
    void onDisconnect(BLEClient* client) override {
      Serial.println("[MIDI] Disconnected");
      mgr->midiConnected = false;
    }
  };
#endif // USE_MIDI

  void setupBLEGATT() {
    BLEDevice::setCustomGattsHandler(observeGatts);
    txMutex=xSemaphoreCreateMutex();
    txQueue=xQueueCreate(24,sizeof(Outgoing));
    xTaskCreate(transmitTask,"WebNotify",4096,this,1,nullptr);
    pServer = BLEDevice::createServer();
    pServer->setCallbacks(new ServerCallbacks(this));

    BLEService* pService = pServer->createService(BLE_SERVICE_UUID);
    pControlChar = pService->createCharacteristic(
      BLE_CHARACTERISTIC_UUID,
      BLECharacteristic::PROPERTY_WRITE | BLECharacteristic::PROPERTY_READ | BLECharacteristic::PROPERTY_NOTIFY | BLECharacteristic::PROPERTY_WRITE_NR);
    pControlChar->setCallbacks(new CharacteristicCallbacks(this));
    pControlChar->addDescriptor(new BLE2902());
    const char* initMsg = "JamMate_Ready";
    pControlChar->setValue((uint8_t*)initMsg, strlen(initMsg));
    pService->start();

    pAdvertising = BLEDevice::getAdvertising();
    pAdvertising->addServiceUUID(BLE_SERVICE_UUID);
    pAdvertising->setScanResponse(true);
    pAdvertising->setMinPreferred(0x06);
    pAdvertising->setMaxPreferred(0x12);
    BLEDevice::startAdvertising();
  }

  static void a2dpConnectionCallback(esp_a2d_connection_state_t state, void* obj) {
    const char* stateStr[] = {"Disconnected", "Connecting", "Connected", "Disconnecting"};
    Serial.printf("[A2DP] Connection state: %s\n", stateStr[state]);
  }

  void setupA2DP(const char* name) {
    a2dp_sink.set_task_core(1);
    a2dp_sink.set_task_priority(10);
    a2dp_sink.set_on_connection_state_changed(a2dpConnectionCallback, this);
    i2s_config_t i2s_config = {
      .mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_TX),
      .sample_rate = 44100,
      .bits_per_sample = I2S_BITS_PER_SAMPLE_16BIT,
      .channel_format = I2S_CHANNEL_FMT_RIGHT_LEFT,
      .communication_format = I2S_COMM_FORMAT_STAND_I2S,
      .intr_alloc_flags = 0,
      .dma_buf_count = 16,
      .dma_buf_len = 128,
      .use_apll = false,
      .tx_desc_auto_clear = true
    };
    a2dp_sink.set_i2s_config(i2s_config);
    a2dp_sink.start(name);
    a2dpEnabled = true;
    esp_bt_cod_t cod;
    cod.major = 0b00100;
    cod.minor = 0b000100;
    cod.service = 0b0010000000;
    esp_bt_gap_set_cod(cod, ESP_BT_INIT_COD);
  }

  class ServerCallbacks : public BLEServerCallbacks {
  public:
    ServerCallbacks(BluetoothManager* mgr)
      : manager(mgr) {}
    void onConnect(BLEServer* pServer, esp_ble_gatts_cb_param_t* param) override {
      manager->generation++;
      manager->rx.reset();
      manager->peerKnown=false;
      manager->bleControlConnected = true;
      memcpy(manager->peerBDA, param->connect.remote_bda, 6);
      Serial.println("[BLE] WebApp connected");

      // Negotiate connection params: 50ms interval, no slave latency, 10s supervision timeout
      // This prevents PC from dropping idle BLE connections
      esp_ble_conn_update_params_t conn_params = {};
      memcpy(conn_params.bda, param->connect.remote_bda, 6);
      conn_params.min_int = 40;   // 50ms  (40 * 1.25ms)
      conn_params.max_int = 60;   // 75ms  (60 * 1.25ms)
      conn_params.latency = 0;    // no slave latency — always respond
      conn_params.timeout = 1000; // 10s   (1000 * 10ms)
      esp_ble_gap_update_conn_params(&conn_params);
    }
    void onDisconnect(BLEServer* pServer) override {
      manager->generation++;
      manager->rx.reset();
      manager->bleControlConnected = false;
      Serial.println("[BLE] WebApp disconnected");
      delay(100);
      manager->pAdvertising->start();
    }

  private:
    BluetoothManager* manager;
  };

  class CharacteristicCallbacks : public BLECharacteristicCallbacks {
  public:
    CharacteristicCallbacks(BluetoothManager* mgr)
      : manager(mgr) {}
    void onWrite(BLECharacteristic* characteristic,esp_ble_gatts_cb_param_t* event) override {
      // Framed web writes fit ATT MTU 23 and are not prepared/long writes.
      // Copy directly from the event; characteristic->getValue() can already
      // have been changed by another GATT operation.
      if(!event||!event->write.len||event->write.is_prep)return;
      const uint8_t* bytes=event->write.value;const size_t len=event->write.len;
      if(!manager->peerKnown){
        manager->peerKnown=true;
        Serial.printf("[WEB] Client transport: %s\n",bytes[0]==0x7e?"framed v1":"legacy raw; refresh repaired v7");
      }
      if(!manager->bleDataCallback)return;
      if(bytes[0]==0x7e){
        if(manager->rx.accept(bytes,len,millis()))manager->bleDataCallback(manager->rx.bytes,manager->rx.used);
      }else manager->bleDataCallback(const_cast<uint8_t*>(bytes),len);
    }
  private:
    BluetoothManager* manager;
  };
};

#if USE_MIDI
inline BluetoothManager::MidiCallbackFunction BluetoothManager::onMidiReceive = nullptr;
#endif