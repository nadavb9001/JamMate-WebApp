#pragma once
// JamMate 240x320 portrait FX parameter grid, two columns x six rows.
// DSP/control order is untouched: knobs first, followed by dropdowns.
// Tiles are individually repaintable; scrolling redraws only the tile area.
#include <TFT_eSPI.h>
#include <stdint.h>
#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include "DisplayComponents.h"

namespace JmFxPortrait {
static constexpr int COLUMNS=2;
static constexpr int VISIBLE_ROWS=6;
static constexpr int VISIBLE_ITEMS=COLUMNS*VISIBLE_ROWS;
static constexpr int TILE_TOP=59;
static constexpr int TILE_PITCH=38;
static constexpr int TILE_WIDTH=111;
static constexpr int TILE_HEIGHT=35;

struct Model {
    const FxLayout* layout=nullptr;
    const char* preset="";
    const char* effect="";
    const uint8_t* knobs=nullptr;
    const uint8_t* drops=nullptr;
    bool enabled=true;
    int selected=0;
    bool adjusting=false;
    int cpu=-1;
};
inline uint16_t c(TFT_eSPI& t,int r,int g,int b){return t.color565(r,g,b);}
inline uint16_t bg(TFT_eSPI& t){return c(t,3,9,21);}
inline uint16_t panel(TFT_eSPI& t){return c(t,8,20,33);}
inline uint16_t line(TFT_eSPI& t){return c(t,38,65,89);}
inline uint16_t cyan(TFT_eSPI& t){return c(t,0,220,242);}
inline uint16_t amber(TFT_eSPI& t){return c(t,255,195,66);}
inline int count(const Model& m){return m.layout?m.layout->knobCount+m.layout->dropCount:0;}

// Keep both tiles in a row on the same scrolling page. Start is always even.
inline int scrollStart(const Model& m){
    const int total=count(m);
    if(total<=VISIBLE_ITEMS)return 0;
    const int totalRows=(total+COLUMNS-1)/COLUMNS;
    const int selectedRow=(m.selected<0?0:m.selected)/COLUMNS;
    int firstRow=selectedRow-(VISIBLE_ROWS-1);
    if(firstRow<0)firstRow=0;
    if(firstRow>totalRows-VISIBLE_ROWS)firstRow=totalRows-VISIBLE_ROWS;
    return firstRow*COLUMNS;
}
inline void fit(TFT_eSPI& t,char* s,int maxWidth,size_t cap){
    if(t.textWidth(s,2)<=maxWidth)return;
    size_t n=strlen(s);
    while(n>1 && t.textWidth(s,2)>maxWidth-16){s[--n]=0;}
    if(n+2<cap){s[n++]='.';s[n++]='.';s[n]=0;}
}
inline void format(const char* name,char* dst,size_t cap){
    if(!name)name="";
    if(strncmp(name,"shift_",6)==0)name+=6;
    size_t i=0;
    while(*name && i+1<cap){char ch=*name++;dst[i++]=ch=='_'?' ':(char)toupper((unsigned char)ch);}
    dst[i]=0;
}
inline void cellRect(int index,int first,int& x,int& y){
    const int slot=index-first;
    x=7+(slot%2)*115;
    y=TILE_TOP+(slot/2)*TILE_PITCH;
}
inline void row(TFT_eSPI& t,const Model& m,int index,int first){
    if(!m.layout||index<first||index>=first+VISIBLE_ITEMS||index>=count(m))return;
    int x,y;cellRect(index,first,x,y);
    const bool chosen=index==m.selected;
    const uint16_t body=chosen?(m.adjusting?c(t,51,35,19):c(t,17,47,67)):panel(t);
    const uint16_t border=chosen?(m.adjusting?amber(t):cyan(t)):line(t);
    t.fillRect(x-1,y-1,TILE_WIDTH+2,TILE_HEIGHT+2,bg(t));
    t.fillRoundRect(x,y,TILE_WIDTH,TILE_HEIGHT,5,body);
    t.drawRoundRect(x,y,TILE_WIDTH,TILE_HEIGHT,5,border);
    if(chosen)t.drawFastVLine(x+3,y+5,25,border);
    const bool knob=index<m.layout->knobCount;
    const int paramIndex=knob?index:index-m.layout->knobCount;
    const char* raw=knob?m.layout->knobLabels[paramIndex]:m.layout->dropLabels[paramIndex];
    char name[50];format(raw,name,sizeof(name));
    t.setTextFont(2);fit(t,name,TILE_WIDTH-14,sizeof(name));
    t.setTextDatum(TL_DATUM);
    t.setTextColor(chosen?TFT_WHITE:c(t,178,203,222),body);
    t.drawString(name,x+7,y+1,2);
    if(knob){
        const uint8_t rawval=m.knobs?m.knobs[paramIndex]:0;
        const int v=rawval<=100?rawval:100;
        t.setTextColor(chosen&&m.adjusting?amber(t):cyan(t),body);
        t.drawRightString(String(rawval),x+TILE_WIDTH-7,y+16,2);
        t.fillRoundRect(x+7,y+29,TILE_WIDTH-14,3,1,c(t,36,53,72));
        if(v>0)t.fillRoundRect(x+7,y+29,((TILE_WIDTH-14)*v+50)/100,3,1,
                             chosen&&m.adjusting?amber(t):cyan(t));
    }else{
        const int v=m.drops?m.drops[paramIndex]:0;
        const char* option=nullptr;
        if(m.layout->dropOptions && m.layout->dropOptionCounts &&
           m.layout->dropOptions[paramIndex] && v<m.layout->dropOptionCounts[paramIndex])
            option=m.layout->dropOptions[paramIndex][v];
        char fallback[10];if(!option){snprintf(fallback,sizeof(fallback),"%d",v);option=fallback;}
        char formatted[80];format(option,formatted,sizeof(formatted));
        fit(t,formatted,TILE_WIDTH-14,sizeof(formatted));
        t.setTextColor(chosen&&m.adjusting?amber(t):c(t,0,237,145),body);
        t.drawString(formatted,x+7,y+17,2);
    }
}
inline void header(TFT_eSPI& t,const Model& m){
    const uint16_t h=c(t,9,25,40);
    t.fillRect(0,0,240,57,bg(t));t.fillRect(0,0,240,27,h);
    t.drawFastHLine(0,26,240,line(t));
    t.setTextDatum(TL_DATUM);t.setTextFont(2);
    t.setTextColor(cyan(t),h);t.drawString("FX PARAMS",9,4,2);
    t.setTextColor(c(t,172,195,217),h);
    char p[32];format(m.preset,p,sizeof(p));fit(t,p,100,sizeof(p));
    t.drawRightString(p,232,4,2);
    t.setTextFont(4);
    char title[40];format(m.effect,title,sizeof(title));
    while(strlen(title)>1 && t.textWidth(title,4)>155)title[strlen(title)-1]=0;
    t.setTextColor(TFT_WHITE,bg(t));t.drawString(title,9,27,4);
    uint16_t a=m.enabled?c(t,0,237,145):c(t,156,177,199);
    t.fillRoundRect(174,32,57,21,6,m.enabled?c(t,6,53,34):panel(t));
    t.drawRoundRect(174,32,57,21,6,a);
    t.setTextFont(2);t.setTextColor(a,m.enabled?c(t,6,53,34):panel(t));
    t.drawCentreString(m.enabled?"ON":"OFF",202,34,2);
    t.drawFastHLine(9,55,223,line(t));
}
inline void scrollbar(TFT_eSPI& t,const Model& m,int first){
    t.fillRect(235,58,5,232,bg(t));
    if(count(m)<=VISIBLE_ITEMS)return;
    const int nRows=(count(m)+1)/2;
    const int thumb=((VISIBLE_ROWS*227)/nRows)>17?(VISIBLE_ROWS*227)/nRows:17;
    t.fillRoundRect(237,59,2,227,1,line(t));
    t.fillRoundRect(237,59+(227-thumb)*(first/2)/(nRows-VISIBLE_ROWS),2,thumb,1,cyan(t));
}
inline void footer(TFT_eSPI& t,int cpu){
    const uint16_t body=c(t,8,24,39);
    t.fillRect(0,294,240,26,body);t.drawFastHLine(0,294,240,line(t));
    t.setTextDatum(TL_DATUM);t.setTextFont(2);t.setTextColor(TFT_WHITE,body);
    t.drawString(cpu<0?"CPU --":String("CPU ")+String(cpu>100?100:cpu)+"%",9,299,2);
    t.fillRoundRect(101,304,91,6,2,c(t,29,54,77));
    if(cpu>0)t.fillRoundRect(101,304,(91*(cpu>100?100:cpu))/100,6,2,cyan(t));
    // Beat LED at (223,304) is painted by DisplayManager.
}
inline void draw(TFT_eSPI& t,const Model& m){
    t.fillScreen(bg(t));header(t,m);
    const int first=scrollStart(m);
    for(int i=first;i<count(m)&&i<first+VISIBLE_ITEMS;i++)row(t,m,i,first);
    scrollbar(t,m,first);footer(t,m.cpu);
}
}
