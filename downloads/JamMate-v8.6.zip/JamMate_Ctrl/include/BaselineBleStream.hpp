#pragma once
#include <stdint.h>
#include <stddef.h>
#include <string.h>
// Baseline records: command byte + little-endian payload length + payload.
// Writes may split a record at the minimum ATT payload; no extra wire envelope.
struct BaselineBleStream {
 static constexpr size_t MAX=2051;
 uint8_t bytes[MAX];size_t used=0,expected=0;uint32_t lastByte=0;
 void reset(){used=expected=0;}
 template<class Receive>void accept(const uint8_t* p,size_t n,uint32_t now,Receive receive){
  if(used&&uint32_t(now-lastByte)>2000)reset();lastByte=now;
  for(size_t i=0;i<n;i++){
   bytes[used++]=p[i];
   if(used==3){expected=3+size_t(bytes[1])+(size_t(bytes[2])<<8);if(expected>MAX){reset();return;}}
   if(expected&&used==expected){receive(bytes,expected);reset();}
  }
 }
};
