#pragma once
#include <Arduino.h>

// --- Pin Definitions ---
#define ENCODER1_PIN_A 19
#define ENCODER1_PIN_B 18
#define ENCODER1_BTN 5
#define ENCODER2_PIN_A 34
#define ENCODER2_PIN_B 22
#define ENCODER2_BTN 23
#define SWITCH1_PIN 26
#define SWITCH2_PIN 2
#define DSP_TX_PIN 33
#define DSP_RX_PIN 25
#define DAISY_READY_PIN 27

// --- UI Constants ---
constexpr int SCREEN_WIDTH = 240;
constexpr int SCREEN_HEIGHT = 320;
constexpr int TOTAL_FX = 18; 
constexpr int TOTAL_EXTRA_BUTTONS = 3; 
constexpr int TOTAL_MAIN_MENU_RECTS = 24; 
constexpr int HIGHLIGHT_BORDER_THICKNESS = 3;
constexpr int TOTAL_BANKS = 7;

// --- Enums ---
enum RectButtonType { RECT_BUTTON, RECT_SELECTION, RECT_PROGRESS };
// Added STATE_SETUP
enum DisplayState { STATE_MAIN_MENU, STATE_LOOPER, STATE_TUNER, STATE_FX_EDIT, STATE_DRUM, STATE_SETUP, STATE_FX_GRID };