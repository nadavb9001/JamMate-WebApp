// MyRotaryEncoder.cpp

#include "MyRotaryEncoder.h"

// ============================================================
//  PushSwitch
// ============================================================

PushSwitch::PushSwitch(int pinSw)
  : pinSw(pinSw),
    lastDebounceTime(0),
    buttonState(HIGH), lastButtonState(HIGH),
    btnPressTime(0), lastButtonPress(0), pendingSingleTime(0),
    btnPressed(false), doubleClick(false), longClick(false), pendingSingle(false) {}

void PushSwitch::begin() {
  pinMode(pinSw, INPUT_PULLUP);
  buttonState = digitalRead(pinSw);
  lastButtonState = buttonState;
}

void PushSwitch::update() {
  checkButton();
}

// Consumed on read – caller sees each event exactly once
bool PushSwitch::isButtonPressed() {
  bool v = btnPressed;
  btnPressed = false;
  return v;
}
bool PushSwitch::isDoubleClick() {
  bool v = doubleClick;
  doubleClick = false;
  return v;
}
bool PushSwitch::isLongClick() {
  bool v = longClick;
  longClick = false;
  return v;
}

bool PushSwitch::isHeld() const {
  return buttonState == LOW;
}

void PushSwitch::resetButton() {
  btnPressed = false;
  doubleClick = false;
  longClick = false;
  pendingSingle = false;
  lastButtonState = HIGH;
}

void PushSwitch::checkButton() {
  unsigned long now = millis();
  int readState = digitalRead(pinSw);

  // Promote pending single click once the double-click window expires
  if (pendingSingle && (now - pendingSingleTime) > 350) {
    btnPressed = true;
    pendingSingle = false;
    lastButtonPress = 0;
  }

  // Reset debounce timer whenever the raw reading changes
  if (readState != lastButtonState) {
    lastDebounceTime = now;
  }

  if ((now - lastDebounceTime) > debounceDelay) {
    if (readState != buttonState) {
      buttonState = readState;

      if (buttonState == LOW) {
        // ── Falling edge: button pressed ──────────────────────
        btnPressTime = now;

      } else {
        // ── Rising edge: button released ──────────────────────
        unsigned long pressDur = now - btnPressTime;

        if (pressDur > 600) {
          // Long press – does NOT also fire as a single click
          longClick = true;
          pendingSingle = false;
        } else {
          // Short press – check for double click
          if (pendingSingle && (now - pendingSingleTime) < 350) {
            // Second tap within window → double click
            doubleClick = true;
            pendingSingle = false;
            lastButtonPress = 0;
          } else {
            // First tap – defer until window expires
            pendingSingle = true;
            pendingSingleTime = now;
            lastButtonPress = now;
          }
        }
      }
    }
  }

  lastButtonState = readState;
}


// ============================================================
//  RotaryEncoder
// ============================================================

RotaryEncoder::RotaryEncoder(int pinA, int pinB, int pinSw)
  : pinA(pinA), pinB(pinB), pinSw(pinSw),
    encoderPos(0), lastStateA(0),
    lastDebounceTime(0),
    buttonState(HIGH), lastButtonState(HIGH),
    buttonPressStart(0), lastButtonPress(0),
    btnPressed(false), doubleClick(false), longClick(false) {}

void RotaryEncoder::begin() {
  pinMode(pinA, INPUT_PULLUP);
  pinMode(pinB, INPUT_PULLUP);
  pinMode(pinSw, INPUT_PULLUP);

  // Capture initial A pin state for edge detection
  lastStateA = digitalRead(pinA);

  buttonState = digitalRead(pinSw);
  lastButtonState = buttonState;
}

// ── Edge-on-A encoder ────────────────────────────────────────────────────
//
//  Count only when A changes.  Direction is determined by whether A and B
//  agree at that moment.  One detent = one A edge = one count.
//
void RotaryEncoder::calcEncoder() {
  int stateA = digitalRead(pinA);
  int stateB = digitalRead(pinB);

  if (stateA != lastStateA) {
    if (stateA == stateB) encoderPos--;
    else encoderPos++;
    lastStateA = stateA;
  }
}

// ── Button with debounce, long-press, and double-click ───────────────────
void RotaryEncoder::checkButton() {
  int readState = digitalRead(pinSw);

  if (readState != lastButtonState) {
    lastDebounceTime = millis();
  }

  if ((millis() - lastDebounceTime) > debounceDelay) {
    if (readState != buttonState) {
      buttonState = readState;

      if (buttonState == LOW) {
        // ── Falling edge ──────────────────────────────────────
        buttonPressStart = millis();

      } else {
        // ── Rising edge ───────────────────────────────────────
        unsigned long now = millis();
        unsigned long pressDur = now - buttonPressStart;

        if (pressDur > 800) {
          // Long press
          longClick = true;
          btnPressed = false;
        } else {
          // Short press – suppress if within bounce window (150 ms), otherwise fire
          if (lastButtonPress != 0 && (now - lastButtonPress) < 150) {
            // Likely post-release bounce: absorb silently, reset so next press is clean
            lastButtonPress = 0;
          } else {
            btnPressed = true;
            lastButtonPress = now;
          }
        }
      }
    }
  }

  lastButtonState = readState;
}

void RotaryEncoder::update() {
  calcEncoder();
  checkButton();
}

void RotaryEncoder::setPosition(int position) {
  encoderPos = position;
}
int RotaryEncoder::getPosition() const {
  return encoderPos;
}

// Software injection helpers
void RotaryEncoder::injectRotation(int delta) {
  encoderPos += delta;
}
void RotaryEncoder::injectButtonPress() {
  btnPressed = true;
}
void RotaryEncoder::injectLongPress() {
  longClick = true;
}

bool RotaryEncoder::isButtonPressed() {
  bool v = btnPressed;
  btnPressed = false;
  return v;
}
bool RotaryEncoder::isDoubleClick() {
  bool v = doubleClick;
  doubleClick = false;
  return v;
}
bool RotaryEncoder::isLongClick() {
  bool v = longClick;
  longClick = false;
  return v;
}

void RotaryEncoder::resetButton() {
  btnPressed = false;
  doubleClick = false;
  longClick = false;
  lastButtonState = HIGH;  // idle state for INPUT_PULLUP
}