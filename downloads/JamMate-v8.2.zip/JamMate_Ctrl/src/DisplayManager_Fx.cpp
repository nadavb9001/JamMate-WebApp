#include "DisplayManager.h"
#include "JmFxGridPortrait.hpp"
#include "JmFxParamsPortrait.hpp"
#include "BluetoothManager_binary.hpp"

extern BluetoothManager btManager;
extern void sendEffectChangeToDSP(uint8_t idx, uint8_t en, const uint8_t* k, const uint8_t* d);

void DisplayManager::drawFxGridScreen(){
  lastEncoder1Pos=encoder1.getPosition();
  bool states[18];
  for(int i=0;i<18;i++)states[i]=currentPreset.effects[i].enabled;
  JmFxGrid::draw(tft,states,fxGridIndex,lastDspCpuPercent);
  beatLedLastAppearance=-1;drawBeatLed(true);
}

void DisplayManager::refreshFxTile(int cell){
  if(cell<0||cell>=18)return;
  JmFxGrid::tile(tft,cell,currentPreset.effects[JmFxGrid::dsp(cell)].enabled,cell==fxGridIndex);
}

void DisplayManager::refreshFxEffect(int dspIndex){
  if(currentState==STATE_FX_GRID)
    for(int i=0;i<18;++i)if(JmFxGrid::dsp(i)==dspIndex){refreshFxTile(i);break;}
}

void DisplayManager::handleFxGridMode(){
  // ENC1 long-click is the dedicated Back/Home shortcut on the FX grid.
  // ENC2 rotation remains globally assigned to master volume.
  if(encoder1.isLongClick() || encoder1.isDoubleClick()){
    currentState=STATE_MAIN_MENU;drawMainScreen();return;
  }
  // ENC2 SHORT click opens the currently highlighted effect's parameters.
  // Read exactly once, in this screen's handler (not in main input handler).
  if(encoder2.isButtonPressed()){
    fxEditIndex=JmFxGrid::dsp(fxGridIndex);
    fxParamIndex=0;fxParamAdjusting=false;fxRenderedScroll=-1;
    lastEncoder1Pos=encoder1.getPosition();
    currentState=STATE_FX_EDIT;drawFxEditScreen();return;
  }
  const int pos=encoder1.getPosition();
  const int delta=pos-lastEncoder1Pos;
  lastEncoder1Pos=pos;
  if(delta){
    const int previous=fxGridIndex;
    fxGridIndex=(fxGridIndex+(delta%18)+18)%18;
    refreshFxTile(previous);refreshFxTile(fxGridIndex);
  }
  if(encoder1.isButtonPressed()){
    const int id=JmFxGrid::dsp(fxGridIndex);
    currentPreset.effects[id].enabled=!currentPreset.effects[id].enabled;
    sendEffectChangeToDSP(id,currentPreset.effects[id].enabled,
                         currentPreset.effects[id].knobs,currentPreset.effects[id].dropdowns);
    uint8_t ble[4]={0x36,(uint8_t)id,0,(uint8_t)currentPreset.effects[id].enabled};
    btManager.sendBLEData(ble,4);
    refreshFxTile(fxGridIndex);
  }
}

static JmFxPortrait::Model buildFxModel(DisplayManager& d){
  JmFxPortrait::Model m;
  m.layout=&fxLayouts[d.fxEditIndex];
  static char safePreset[PRESET_NAME_LENGTH+1];
  memcpy(safePreset,currentPreset.name,PRESET_NAME_LENGTH);
  safePreset[PRESET_NAME_LENGTH]=0;
  m.preset=safePreset;
  m.effect=fxLabels[d.fxEditIndex];
  m.knobs=currentPreset.effects[d.fxEditIndex].knobs;
  m.drops=currentPreset.effects[d.fxEditIndex].dropdowns;
  m.enabled=currentPreset.effects[d.fxEditIndex].enabled;
  m.selected=d.fxParamIndex;
  m.adjusting=d.fxParamAdjusting;
  m.cpu=d.lastDspCpuPercent;
  return m;
}

void DisplayManager::drawFxEditScreen(bool fullRedraw,int previous){
  const auto m=buildFxModel(*this);
  if(!JmFxPortrait::count(m))return;
  const int first=JmFxPortrait::scrollStart(m);
  if(fullRedraw || fxRenderedScroll<0){
    JmFxPortrait::draw(tft,m);fxRenderedScroll=first;
    beatLedLastAppearance=-1;drawBeatLed(true);return;
  }
  if(first!=fxRenderedScroll){
    // Scroll only the 2x6 cell area; header/footer never flash.
    tft.fillRect(6,58,232,232,JmFxPortrait::bg(tft));
    for(int i=first;i<JmFxPortrait::count(m)&&i<first+JmFxPortrait::VISIBLE_ITEMS;i++)
      JmFxPortrait::row(tft,m,i,first);
    JmFxPortrait::scrollbar(tft,m,first);
    fxRenderedScroll=first;
  } else {
    if(previous>=0 && previous!=fxParamIndex)
      JmFxPortrait::row(tft,m,previous,first);
    JmFxPortrait::row(tft,m,fxParamIndex,first);
  }
}

void DisplayManager::drawFxParamSlider(int index,const char*,uint8_t,bool,bool,bool){
  const auto m=buildFxModel(*this);
  JmFxPortrait::row(tft,m,index,JmFxPortrait::scrollStart(m));
}
void DisplayManager::drawFxParamDropdown(int index,const char*,uint8_t,bool,bool,bool){
  const auto m=buildFxModel(*this);
  JmFxPortrait::row(tft,m,index,JmFxPortrait::scrollStart(m));
}

void DisplayManager::handleFxEditMode(){
  // ENC2 switch only enters parameters from the FX grid. Discard any click
  // while editing so a stale event cannot reopen the page after Back.
  encoder2.isButtonPressed();
  if(encoder1.isLongClick()){
    fxParamAdjusting=false;
    currentState=STATE_FX_GRID;
    drawFxGridScreen();return;
  }
  const auto m=buildFxModel(*this);
  const int total=JmFxPortrait::count(m);
  if(total==0)return;
  const int pos=encoder1.getPosition();
  const int delta=pos-lastEncoder1Pos;
  lastEncoder1Pos=pos;
  if(!fxParamAdjusting){
    if(delta){
      const int old=fxParamIndex;
      fxParamIndex=(fxParamIndex+delta%total+total)%total;
      drawFxEditScreen(false,old);
    }
    if(encoder1.isButtonPressed()){
      fxParamAdjusting=true;
      drawFxEditScreen(false,fxParamIndex);
    }
  } else {
    if(delta){
      const FxLayout& layout=fxLayouts[fxEditIndex];
      int value=0,limit=100;
      bool isKnob=fxParamIndex<layout.knobCount;
      const int sub=isKnob?fxParamIndex:fxParamIndex-layout.knobCount;
      if(isKnob)value=currentPreset.effects[fxEditIndex].knobs[sub];
      else{
        value=currentPreset.effects[fxEditIndex].dropdowns[sub];
        limit=(layout.dropOptionCounts&&layout.dropOptionCounts[sub])?
              layout.dropOptionCounts[sub]-1:0;
      }
      const int v=value+delta<0?0:value+delta>limit?limit:value+delta;
      if(v!=value){
        if(isKnob)currentPreset.effects[fxEditIndex].knobs[sub]=v;
        else currentPreset.effects[fxEditIndex].dropdowns[sub]=v;
        sendEffectChangeToDSP(fxEditIndex,currentPreset.effects[fxEditIndex].enabled,
           currentPreset.effects[fxEditIndex].knobs,currentPreset.effects[fxEditIndex].dropdowns);
        const uint8_t pid=(uint8_t)(1+fxParamIndex);
        uint8_t ble[4]={0x36,(uint8_t)fxEditIndex,pid,(uint8_t)v};
        btManager.sendBLEData(ble,4);
        drawFxEditScreen(false,fxParamIndex);
      }
    }
    if(encoder1.isButtonPressed()){
      fxParamAdjusting=false;
      drawFxEditScreen(false,fxParamIndex);
    }
  }
}
