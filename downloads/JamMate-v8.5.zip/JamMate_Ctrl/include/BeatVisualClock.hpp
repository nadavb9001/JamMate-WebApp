#pragma once
#include <stdint.h>
#include <stddef.h>
#include <math.h>

// ESP-side display estimator. The Daisy's framed 16-byte BEAT message is
// authoritative; millis() is used only to interpolate the position *between*
// packets. No UART transmission or TFT calls occur here.
class BeatVisualClock
{
public:
    bool Accept(const uint8_t* d, size_t len, uint32_t received_ms)
    {
        if (!d || len != 16 || d[0] != 1 || !(d[1] & 0x01)) return false;
        const uint8_t beats = d[3];
        const uint16_t bpm10 = Read16(d + 12);
        if (beats == 0 || beats > 32 || d[2] >= beats || bpm10 < 200 || bpm10 > 3000)
            return false;
        const uint16_t seq = Read16(d + 14);
        const uint32_t new_sample = Read32(d + 8);
        const uint32_t new_bar = Read32(d + 4);
        // A falling sample index usually denotes transport restart. Ordinary
        // 32-bit wrap after ~24.9 hours at 48k is not a restart.
        restarted_ = valid_ && new_sample < sample_index_ &&
                     sample_index_ < 0xF0000000u &&
                     new_bar <= bar_ && d[2] == 0 &&
                     (new_bar < bar_ || !Active(received_ms));
        // Repeated/out-of-order packets must not move the animation back.
        // After a DSP reboot the sequence counter itself may also restart.
        uint16_t advance = 0;
        if (valid_) {
            advance = static_cast<uint16_t>(seq - sequence_);
            if ((advance == 0 || advance >= 0x8000u) && !restarted_) return false;
        }
        // Derive actual felt-beat duration from DSP sample deltas rather than
        // assuming every BEAT is a quarter note (6/8 has dotted-quarter beats).
        const double nominal_period = 600000.0 / static_cast<double>(bpm10);
        if (valid_ && !restarted_ && advance <= 16 && new_sample > sample_index_) {
            const double measured = double(new_sample - sample_index_) / (48.0 * advance);
            if (measured > 60.0 && measured < 3000.0)
                period_ms_ = measured;
            else
                period_ms_ = nominal_period;
        } else {
            period_ms_ = nominal_period;
        }
        sequence_ = seq;
        sample_index_ = new_sample;
        bar_ = new_bar;
        beat_ = d[2];
        beats_per_bar_ = beats;
        arrival_ms_ = received_ms;
        downbeat_ = (d[1] & 0x02u) != 0;
        auto_start_ = (d[1] & 0x04u) != 0;
        valid_ = true;
        return true;
    }

    bool HasBeat() const { return valid_; }
    bool WasAutoStart() const { return auto_start_; }
    bool LastWasDownbeat() const { return downbeat_; }
    bool WasRestarted() const { return restarted_; }
    uint8_t BeatIndex() const { return beat_; }
    uint8_t BeatsPerBar() const { return beats_per_bar_; }
    uint32_t BarIndex() const { return bar_; }
    uint32_t SampleIndex() const { return sample_index_; }
    uint16_t Sequence() const { return sequence_; }
    double BeatPeriodMs() const { return period_ms_; }
    uint32_t AgeMs(uint32_t now_ms) const { return now_ms - arrival_ms_; }
    double BeatAtPacket() const
    {
        return static_cast<double>(bar_) * beats_per_bar_ + beat_;
    }
    bool Active(uint32_t now_ms) const
    {
        // No free running if messages cease (DSP stopped or UART broken).
        return valid_ && AgeMs(now_ms) <= static_cast<uint32_t>(period_ms_ * 2.5 + 100.0);
    }
    bool Lit(uint32_t now_ms) const
    {
        return Active(now_ms) && AgeMs(now_ms) < 105u;
    }
    double BeatPosition(uint32_t now_ms) const
    {
        if (!valid_) return 0.0;
        // Clamp extrapolation during packet loss, no infinite synthetic clock.
        double progress = static_cast<double>(AgeMs(now_ms)) / period_ms_;
        if (progress > 2.5) progress = 2.5;
        return BeatAtPacket() + progress;
    }
    void Invalidate() { valid_ = false; auto_start_ = false; restarted_ = false; }

private:
    static uint16_t Read16(const uint8_t* p)
    { return static_cast<uint16_t>(p[0]) | (static_cast<uint16_t>(p[1]) << 8); }
    static uint32_t Read32(const uint8_t* p)
    { return uint32_t(Read16(p)) | (uint32_t(Read16(p+2)) << 16); }
    bool valid_ = false;
    bool downbeat_ = false;
    bool auto_start_ = false;
    bool restarted_ = false;
    uint8_t beat_ = 0, beats_per_bar_ = 4;
    uint16_t sequence_ = 0;
    uint32_t sample_index_ = 0, bar_ = 0, arrival_ms_ = 0;
    double period_ms_ = 500.0;
};

// The musical anchor for the *first* recorded layer. The UI can't recover
// the position of an arbitrary pre-existing loop from per-beat packets alone;
// that needs a separate DSP playhead/status message.
class LooperBeatPhase
{
public:
    void Reset()
    { anchored_ = false; pending_ = false; period_beats_ = 0.0; }

    void OnRecordingStart(const BeatVisualClock& clk, uint32_t now_ms,
                          uint8_t sync_mode)
    {
        pending_ = true;
        anchored_ = false;
        record_start_ms_ = now_ms;
        sync_mode_ = sync_mode;
        // The LOOP status may arrive a few ms *after* the first BEAT event.
        TryAnchor(clk, now_ms);
    }

    void OnBeat(const BeatVisualClock& clk, uint32_t now_ms)
    {
        if (pending_) TryAnchor(clk, now_ms);
    }

    void OnLoopClosed(const BeatVisualClock& clk, uint32_t loop_ms,
                      uint8_t configured_bars)
    {
        // Free-length loops use their actual duration. For a grid-quantized
        // N-bar take, use an integer musical length if close to measured audio.
        if (clk.HasBeat() && clk.BeatPeriodMs() > 0.0 && loop_ms > 0) {
            period_beats_ = loop_ms / clk.BeatPeriodMs();
            const double grid = double(configured_bars) * clk.BeatsPerBar();
            if (configured_bars > 0 && fabs(period_beats_ - grid) < 0.25)
                period_beats_ = grid;
        }
        pending_ = false;
    }

    bool Anchored() const { return anchored_; }
    bool Pending() const { return pending_; }
    void SetLengthBars(uint8_t bars, uint8_t beats_per_bar)
    {
        if (bars > 0 && period_beats_ <= 0.0)
            period_beats_ = static_cast<double>(bars) * beats_per_bar;
    }
    double Fraction(const BeatVisualClock& clk, uint32_t now_ms,
                    uint8_t configured_bars, bool recording) const
    {
        if (!anchored_ || !clk.Active(now_ms)) return -1.0;
        double length = period_beats_;
        if (length <= 0.0 && recording && configured_bars)
            length = static_cast<double>(configured_bars) * clk.BeatsPerBar();
        if (length <= 0.0) length = clk.BeatsPerBar(); // free-record: 1 bar indicator
        double elapsed = clk.BeatPosition(now_ms) - origin_;
        if (elapsed < 0.0) elapsed = 0.0;
        double remainder = fmod(elapsed, length);
        if (remainder < 0.0) remainder += length;
        return remainder / length;
    }
    double OriginBeat() const { return origin_; }
private:
    void TryAnchor(const BeatVisualClock& clk, uint32_t now_ms)
    {
        if (!pending_ || !clk.Active(now_ms)) return;
        // On a grid mode the first layer starts at a beat or bar boundary.
        // The beat event and LOOP status can be reordered by main-loop drains.
        // Accept a packet near the start time; otherwise continue waiting for
        // a matching beat. For DRUM_START the first downbeat is always anchor.
        const uint32_t age = clk.AgeMs(now_ms);
        const uint32_t from_start = now_ms - record_start_ms_;
        const bool near_start = age < static_cast<uint32_t>(clk.BeatPeriodMs() * 0.45 + 20.0);
        const bool needs_bar = (sync_mode_ == 2 || sync_mode_ == 3);
        if (near_start && from_start < static_cast<uint32_t>(clk.BeatPeriodMs() + 80.0) &&
            (!needs_bar || clk.BeatIndex() == 0)) {
            origin_ = clk.BeatAtPacket();
            anchored_ = true;
            pending_ = false;
        } else if (near_start && from_start < 12000u && clk.BeatPeriodMs() > 0.0) {
            // BEAT #0 could be lost or processed before LOOP status. Infer
            // how many DSP beats elapsed since the recording notification.
            // For BAR/DRUM_START, align origin to a bar boundary, never an
            // arbitrary beat. If UART queue latency is large, this is only
            // an estimate; precise DSP playhead metadata would be better.
            const double elapsed = double(from_start) / clk.BeatPeriodMs();
            if (needs_bar) {
                const double units = (elapsed - clk.BeatIndex()) / clk.BeatsPerBar();
                const long bars = units > 0.0 ? static_cast<long>(floor(units + 0.5)) : 0;
                const double expected = bars * clk.BeatsPerBar() + clk.BeatIndex();
                if (fabs(expected - elapsed) < 0.60) {
                    origin_ = clk.BeatAtPacket() - expected;
                    anchored_ = true;
                    pending_ = false;
                }
            } else {
                const double beats = floor(elapsed + 0.5);
                if (fabs(beats - elapsed) < 0.60) {
                    origin_ = clk.BeatAtPacket() - beats;
                    anchored_ = true;
                    pending_ = false;
                }
            }
        }
    }
    bool anchored_ = false, pending_ = false;
    uint8_t sync_mode_ = 0;
    uint32_t record_start_ms_ = 0;
    double origin_ = 0.0;
    double period_beats_ = 0.0;
};
