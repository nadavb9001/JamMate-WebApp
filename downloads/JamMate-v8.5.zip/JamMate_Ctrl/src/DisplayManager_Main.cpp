#include "DisplayManager.h"
#include "MainHomeLogic.hpp"
#include "PresetSwitchCursor.hpp"
#include "BluetoothManager_binary.hpp"
#include <string.h>

extern BluetoothManager btManager;
extern void updateDSPFromPreset();
extern void syncPresetSelectionFromDisplay(uint8_t bank, uint8_t number);
extern bool loadPreset(uint8_t bank, uint8_t number, Preset& preset);
extern void sendToDSP(const char cmd[4], uint8_t* payload, size_t len);

namespace {
    // TFT_eSPI's built-in fonts keep the 240 x 320 display readable without
    // requiring large extra font assets. No small decorative status icons.
    // 16-bit RGB565 palette: punchy colors designed for a 240x320 TFT.
    // All accents are raster primitives; no JPGs, sprites or large buffers.
    constexpr uint16_t kBg        = 0x000A; // very dark navy
    constexpr uint16_t kPanel     = 0x0845; // blue-black
    constexpr uint16_t kPanelHi   = 0x10CA;
    constexpr uint16_t kSlate     = 0x4A70;
    constexpr uint16_t kCyan      = 0x07FF; // electric cyan
    constexpr uint16_t kAmber     = 0xFD20; // bright orange / edit mode
    constexpr uint16_t kViolet    = 0xE11F; // FX magenta
    constexpr uint16_t kGreen     = 0x07E8; // looper neon green
    constexpr uint16_t kCoral     = 0xFA49; // drums red/coral
    constexpr uint16_t kBlue      = 0x35FF; // tuner azure
    constexpr uint16_t kWhite     = TFT_WHITE;
    constexpr uint16_t kMuted     = 0xC65A; // legible silvery blue

    uint16_t navAccent(int item) {
        switch(item) {
            case MainHome::FX: return kViolet;
            case MainHome::LOOPER: return kGreen;
            case MainHome::DRUMS: return kCoral;
            case MainHome::TUNER: return kBlue;
            default: return kCyan;
        }
    }


    inline bool isValueItem(int index) {
        return index == MainHome::BPM || index == MainHome::VOLUME;
    }

    // Display the original preset family and slot, regardless of any stale or
    // custom text in the saved preset blob. Preset files themselves are unchanged.
    String displayPresetName(const Preset& p) {
        static const char* const bankNames[TOTAL_BANKS] = {
            "Clean", "Crunch", "OvrDrv", "Dist", "Modul",
            "Custm1", "Custm2"
        };
        const String family = (p.bank < TOTAL_BANKS)
                            ? String(bankNames[p.bank]) : String("Preset");
        return family + " " + String(int(p.number) + 1);
    }

    // All stock families are abbreviated to fit the same large bold 24pt
    // font inside the 224x79px banner; retain a defensive fallback for unknown names.
    void drawLargePresetName(TFT_eSPI& tft, const String& name) {
        constexpr int cx = 120, cy = 46, maxWidth = 210;
        tft.setTextDatum(MC_DATUM);
        tft.setTextSize(1);
        tft.setFreeFont(&FONT_LOOPER_BIG);  // FreeSansBold24pt7b (already bundled)
        tft.setTextColor(kWhite, kPanelHi);
        if (tft.textWidth(name) <= maxWidth) {
            tft.drawString(name, cx, cy);
        } else {
            tft.setTextFont(4);  // TFT_eSPI's built-in bold RLE font
            uint8_t size = 2;
            tft.setTextSize(size);
            if (tft.textWidth(name, 4) > maxWidth) {
                size = 1;
                tft.setTextSize(size);
            }
            if (tft.textWidth(name, 4) <= maxWidth) {
                tft.drawString(name, cx, cy, 4);
            } else {
                // Defensive fallback for unexpectedly long future family names.
                tft.setTextFont(2);
                tft.setTextSize(1);
                tft.drawString(name, cx, cy, 2);
            }
        }
        // Other widgets use the standard, unscaled built-in fonts.
        tft.setTextSize(1);
        tft.setTextFont(2);
    }

    // Keep all text inside the real 240px LCD bounds, never draw a tiny font.
    void drawFitted(TFT_eSPI& tft, String text, int cx, int cy,
                    int maxWidth, int preferredFont, uint16_t color,
                    uint16_t background) {
        tft.setTextDatum(MC_DATUM);
        int font = preferredFont;
        if (font == 4 && tft.textWidth(text, 4) > maxWidth) font = 2;
        while (text.length() && tft.textWidth(text, font) > maxWidth)
            text.remove(text.length() - 1);
        tft.setTextColor(color, background);
        tft.drawString(text, cx, cy, font);
    }

    void drawIcon(TFT_eSPI& tft, int item, int cx, int cy, uint16_t color) {
        // Icons appear ONLY on the five navigation buttons.
        switch (item) {
            case MainHome::FX:
                for (int dx = -16; dx <= 16; dx += 16) {
                    tft.drawRoundRect(cx + dx - 6, cy - 11, 12, 22, 2, color);
                    tft.fillCircle(cx + dx, cy - 4, 2, color);
                    tft.drawCircle(cx + dx, cy + 5, 3, color);
                }
                break;
            case MainHome::LOOPER:
                tft.drawCircle(cx, cy, 12, color);
                tft.drawCircle(cx, cy, 11, color);
                tft.fillTriangle(cx + 13, cy - 6, cx + 18, cy - 6,
                                 cx + 13, cy + 1, color);
                tft.fillTriangle(cx - 13, cy + 6, cx - 18, cy + 6,
                                 cx - 13, cy - 1, color);
                break;
            case MainHome::DRUMS:
                tft.drawRoundRect(cx - 12, cy - 6, 24, 14, 2, color);
                tft.drawLine(cx - 10, cy - 11, cx + 5, cy - 4, color);
                tft.drawLine(cx + 10, cy - 11, cx - 5, cy - 4, color);
                tft.drawLine(cx - 8, cy + 8, cx - 11, cy + 14, color);
                tft.drawLine(cx + 8, cy + 8, cx + 11, cy + 14, color);
                break;
            case MainHome::TUNER:
                tft.drawLine(cx - 9, cy - 11, cx - 9, cy + 1, color);
                tft.drawLine(cx + 9, cy - 11, cx + 9, cy + 1, color);
                tft.drawLine(cx - 9, cy + 1, cx, cy + 8, color);
                tft.drawLine(cx + 9, cy + 1, cx, cy + 8, color);
                tft.drawLine(cx, cy + 8, cx, cy + 14, color);
                break;
            case MainHome::SETUP:
                tft.drawCircle(cx, cy, 9, color);
                tft.drawCircle(cx, cy, 3, color);
                for (int i = -1; i <= 1; ++i) {
                    tft.drawLine(cx - 15, cy + i, cx - 9, cy + i, color);
                    tft.drawLine(cx + 9, cy + i, cx + 15, cy + i, color);
                    tft.drawLine(cx + i, cy - 15, cx + i, cy - 9, color);
                    tft.drawLine(cx + i, cy + 9, cx + i, cy + 15, color);
                }
                break;
        }
    }

    void drawValueTile(TFT_eSPI& tft, int item, bool selected,
                       bool editing, int value) {
        const int x = (item == MainHome::BPM) ? 7 : 122;
        constexpr int y = 95, w = 111, h = 65;
        const bool tempo = item == MainHome::BPM;
        const uint16_t baseAccent = tempo ? kCyan : kAmber;
        const uint16_t edge = editing ? kWhite : baseAccent;
        tft.fillRoundRect(x, y, w, h, 7, kPanel);
        tft.drawRoundRect(x, y, w, h, 7, edge);
        // Inexpensive faux neon: two extra border strokes only when focused.
        if(selected) {
            tft.drawRoundRect(x + 1, y + 1, w - 2, h - 2, 6, edge);
            tft.drawRoundRect(x + 3, y + 3, w - 6, h - 6, 5, kPanelHi);
        }
        // Small color wash above the panel label (not a bitmap).
        tft.fillRect(x + 12, y + 5, w - 24, 2, baseAccent);
        drawFitted(tft, tempo ? "BPM" : "VOLUME",
                   x + w / 2, y + 18, w - 8, 2, baseAccent, kPanel);
        const String val = tempo ? String(value) : String(value) + "%";
        drawFitted(tft, val, x + w / 2, y + 44, w - 6, 4, kWhite, kPanel);
        // Meter lives underneath the value. Visible at LCD native resolution.
        const int filled = tempo ? 7 : ((value + 14) / 15);
        for(int i = 0; i < 7; ++i)
            tft.fillRect(x + 13 + i * 13, y + 59, 9, 3,
                         i < filled ? baseAccent : kSlate);
    }

    void drawNavTile(TFT_eSPI& tft, int item, bool selected) {
        int x = 0, y = 0, w = 0, h = 0;
        const char* label = "";
        switch (item) {
            case MainHome::FX:     x = 7;   y = 169; w = 72;  h = 69; label = "FX"; break;
            case MainHome::LOOPER: x = 84;  y = 169; w = 72;  h = 69; label = "LOOPER"; break;
            case MainHome::DRUMS:  x = 161; y = 169; w = 72;  h = 69; label = "DRUMS"; break;
            case MainHome::TUNER:  x = 7;   y = 243; w = 111; h = 46; label = "TUNER"; break;
            case MainHome::SETUP:  x = 122; y = 243; w = 111; h = 46; label = "SETUP"; break;
        }
        const uint16_t accent = navAccent(item);
        const uint16_t bg = selected ? kPanelHi : kPanel;
        tft.fillRoundRect(x, y, w, h, 7, bg);
        tft.drawRoundRect(x, y, w, h, 7, accent);
        if(selected) {
            tft.drawRoundRect(x + 1, y + 1, w - 2, h - 2, 6, accent);
            tft.drawRoundRect(x + 3, y + 3, w - 6, h - 6, 5, accent);
        }
        const int cx = x + w / 2;
        const int iconY = (item <= MainHome::DRUMS) ? y + 25 : y + 16;
        drawIcon(tft, item, cx, iconY, accent);
        const int textY = (item <= MainHome::DRUMS) ? y + 56 : y + 36;
        drawFitted(tft, label, cx, textY, w - 6, 2, selected ? accent : kWhite, bg);
    }

}

void DisplayManager::checkExternalChanges() {
    if (currentState != STATE_MAIN_MENU) return;
    if (currentPreset.bank != currentPresetTypeIndex ||
        int(currentPreset.number) + 1 != currentPresetNumber) {
        refresh();
        return;
    }
    // The header now uses the bank+slot label rather than the stored name;
    // sync the cache without redrawing if only custom name metadata changes.
    if (memcmp(mainPresetNameCache, currentPreset.name, PRESET_NAME_LENGTH) != 0) {
        memcpy(mainPresetNameCache, currentPreset.name, PRESET_NAME_LENGTH);
        mainPresetNameCache[PRESET_NAME_LENGTH] = '\0';
    }
    if (currentPreset.masterVolume != volumeValue) {
        volumeValue = currentPreset.masterVolume;
        highlightRect(MainHome::VOLUME, currentRectIndex == MainHome::VOLUME);
    }
    if (currentPreset.bpm != bpmValue) {
        bpmValue = currentPreset.bpm;
        highlightRect(MainHome::BPM, currentRectIndex == MainHome::BPM);
    }
}

void DisplayManager::handleMainMenu() {
    checkExternalChanges();
    const int position = encoder1.getPosition();
    const int delta = position - lastEncoder1Pos;
    lastEncoder1Pos = position;

    if (delta != 0) {
        if (mainMenuAdjusting && isValueItem(currentRectIndex)) {
            if (currentRectIndex == MainHome::BPM) {
                const uint8_t next = MainHome::ClampBpm(int(currentPreset.bpm) + delta);
                if (next != currentPreset.bpm) {
                    setTempo(next);
                    bpmValue = next;
                }
            } else {
                const uint8_t next = MainHome::ClampVolume(int(currentPreset.masterVolume) + delta * 2);
                if (next != currentPreset.masterVolume) setVolume(next);
            }
            highlightRect(currentRectIndex, true);
        } else {
            const int oldIndex = currentRectIndex;
            currentRectIndex = MainHome::Wrap(currentRectIndex, delta);
            if (oldIndex != currentRectIndex) {
                highlightRect(oldIndex, false);
                highlightRect(currentRectIndex, true);
            }
        }
    }

    if (encoder1.isButtonPressed()) {
        if (isValueItem(currentRectIndex)) {
            mainMenuAdjusting = !mainMenuAdjusting;
            highlightRect(currentRectIndex, true);
        } else {
            mainMenuAdjusting = false;
            switch (currentRectIndex) {
                case MainHome::FX:
                    currentState = STATE_FX_GRID;
                    fxGridIndex = 0;
                    drawFxGridScreen();
                    break;
                case MainHome::LOOPER:
                    currentState = STATE_LOOPER;
                    looperRectIndex = 0;
                    looperAdjusting = false;
                    drawLooperScreen();
                    break;
                case MainHome::DRUMS:
                    currentState = STATE_DRUM;
                    drumRectIndex = 0;
                    drumAdjusting = false;
                    drawDrumScreen();
                    break;
                case MainHome::TUNER: {
                    uint8_t payload[5] = {2, 1, 0, 0, 0};
                    sendToDSP("UTIL", payload, sizeof(payload));
                    toggleTuner(true);
                    break;
                }
                case MainHome::SETUP:
                    currentState = STATE_SETUP;
                    setupRectIndex = 0;
                    setupFirstVisible = 0;
                    setupConfirmIndex = -1;
                    setupAdjusting = false;
                    drawSetupScreen();
                    break;
            }
        }
    }

    // Consume the right encoder's switch; only rotation is dedicated to volume.
    // Its existing long-press diagnostic UART action is preserved below.
    encoder2.isButtonPressed();
    if (encoder1.isLongClick()) {
        if (mainMenuAdjusting) {
            mainMenuAdjusting = false;
            highlightRect(currentRectIndex, true);
        }
    }
    if (encoder2.isLongClick()) {
        if (dspSerialOn) {
            dspSerial.end(); dspSerialOn = false;
            showMessage("UART Off");
        } else {
            dspSerial.begin(1000000, SERIAL_8N1, DSP_RX_PIN, DSP_TX_PIN);
            dspSerialOn = true;
            showMessage("UART On");
        }
    }

    // Preserve the project button scheme: SW1 changes preset, SW2 changes bank.
    // These never enter the left encoder's focus order.
    const bool presetNext = switch1.isButtonPressed();
    const bool presetPrev = switch1.isDoubleClick();
    const bool bankNext = switch2.isButtonPressed();
    const bool bankPrev = switch2.isDoubleClick();
    const unsigned long now = millis();
    if (now - lastSwitchTime >= 100 &&
        (presetNext || presetPrev || bankNext || bankPrev)) {
        static PresetSwitchCursor cursor;
        cursor.move(currentPreset.bank,currentPreset.number,bankNext?1:bankPrev?-1:0,presetNext?1:presetPrev?-1:0);
        const int bank=cursor.bank,number=cursor.slot;
        if (loadPreset(bank, number, currentPreset)) {
            currentPreset.bank = bank;
            currentPreset.number = number;
            syncPresetSelectionFromDisplay(bank, number);
            cursor.loaded();
            mainMenuAdjusting = false;
            refresh();
            updateDSPFromPreset();
        }else showMessage("Preset read error");
        lastSwitchTime = now;
    }
}

void DisplayManager::drawPresetInfo() {
    // Display-only, no Bank header and no "1 / 5" counter. The switches still
    // change bank and preset; the entire available top area shows the name.
    tft.fillRect(0, 0, SCREEN_WIDTH, 90, kBg);
    tft.fillRoundRect(7, 6, 226, 80, 8, kPanelHi);
    tft.drawRoundRect(7, 6, 226, 80, 8, kCyan);
    tft.drawFastHLine(17, 83, 206, kBlue);
    drawLargePresetName(tft, displayPresetName(currentPreset));
}

void DisplayManager::drawMainScreen() {
    // Re-anchor on return from another page so its encoder rotations cannot
    // unexpectedly move the Main focus on the next display.loop() iteration.
    lastEncoder1Pos = encoder1.getPosition();
    currentRectIndex = MainHome::Wrap(currentRectIndex, 0);
    tft.fillScreen(kBg);
    drawPresetInfo();
    for (int i = 0; i < MainHome::ITEM_COUNT; ++i)
        highlightRect(i, i == currentRectIndex);
    drawStatusLine();
}

void DisplayManager::highlightRect(int index, bool highlight) {
    if (currentState != STATE_MAIN_MENU) return;
    if (index == MainHome::BPM)
        drawValueTile(tft, index, highlight, highlight && mainMenuAdjusting, currentPreset.bpm);
    else if (index == MainHome::VOLUME)
        drawValueTile(tft, index, highlight, highlight && mainMenuAdjusting, currentPreset.masterVolume);
    else if (index >= MainHome::FX && index < MainHome::ITEM_COUNT)
        drawNavTile(tft, index, highlight);
}
