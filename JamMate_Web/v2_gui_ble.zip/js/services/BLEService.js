export const BLEService = {
    // UUIDs matched from your ESP32 Firmware
    SERVICE_UUID: "6e400001-b5a3-f393-e0a9-e50e24dcca9f",
    CHARACTERISTIC_UUID: "6e400002-b5a3-f393-e0a9-e50e24dcca9f",

    device: null,
    server: null,
    characteristic: null,
    isConnected: false,

    // Callbacks
    onStatusChange: null, // (status: 'disconnected' | 'connecting' | 'connected')
    onDataReceived: null, // (data: DataView)

    async connect() {
        if (!navigator.bluetooth) {
            alert("Web Bluetooth is not supported in this browser/device.");
            return;
        }

        try {
            this._setStatus('connecting');

            // 1. Request Device
            this.device = await navigator.bluetooth.requestDevice({
                filters: [{ namePrefix: 'JamMate' }],
                optionalServices: [this.SERVICE_UUID]
            });

            this.device.addEventListener('gattserverdisconnected', this._handleDisconnect.bind(this));

            // 2. Connect to Server
            this.server = await this.device.gatt.connect();

            // 3. Get Service
            const service = await this.server.getPrimaryService(this.SERVICE_UUID);

            // 4. Get Characteristic
            this.characteristic = await service.getCharacteristic(this.CHARACTERISTIC_UUID);

            // 5. Start Notifications (Listen for ESP32 data)
            await this.characteristic.startNotifications();
            this.characteristic.addEventListener('characteristicvaluechanged', this._handleData.bind(this));

            this.isConnected = true;
            this._setStatus('connected');
            console.log("BLE Connected");

        } catch (error) {
            console.error("BLE Connection Failed:", error);
            this._handleDisconnect(); 
        }
    },

    async disconnect() {
        if (this.device && this.device.gatt.connected) {
            this.device.gatt.disconnect();
        } else {
            // Force cleanup if already technically disconnected
            this._handleDisconnect();
        }
    },

    async send(data) {
        if (!this.characteristic || !this.isConnected) {
            console.warn("BLE not connected, cannot send data");
            return;
        }
        try {
            await this.characteristic.writeValue(data);
        } catch (error) {
            console.error("BLE Write Failed:", error);
        }
    },

    _handleDisconnect() {
        this.device = null;
        this.server = null;
        this.characteristic = null;
        this.isConnected = false;
        this._setStatus('disconnected');
        console.log("BLE Disconnected");
    },

    _handleData(event) {
        const value = event.target.value;
        if (this.onDataReceived) {
            this.onDataReceived(value);
        }
    },

    _setStatus(status) {
        if (this.onStatusChange) {
            this.onStatusChange(status);
        }
    }
};