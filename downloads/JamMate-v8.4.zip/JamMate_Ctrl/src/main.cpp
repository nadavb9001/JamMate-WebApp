// ===================================================================
// JamMate Multi-Effect Controller - Firmware v8.0 (LittleFS)
// Converted from Arduino .ino to PlatformIO main.cpp
// Web protocol: v8 binary BLE; existing DSP UART protocol preserved.
// Storage: Hybrid (Factory=Structs, Custom=Blobs on LittleFS)
// ===================================================================

#include <esp_system.h>
#include <esp_heap_caps.h>
#include <Arduino.h> // ← Required in PlatformIO (implicit in .ino)

#include "PresetBinary_v2.hpp"
#include "PresetBlobReader.hpp"
#include "PresetSerialText.hpp"
#include "BluetoothManager_binary.hpp"
#include "MyRotaryEncoder.h"
#include <LittleFS.h>
#include "DisplayManager.h"
#include "CpuTelemetry.hpp"
static JmCpuTelemetry s_cpuTelemetry;
#include "Protocol.hpp"

#ifndef JM2_STREAM_REASON_CODES_V1
// Compatibility with the original v6 Protocol.hpp. The wire layout already
// had a 16-bit reserved field in Jm2StreamAckPayload; v6.1 assigns reason
// codes to that field without changing the packet layout.
enum Jm2StreamError : uint16_t
{
    JM2_STREAM_OK              = 0u,
    JM2_STREAM_BAD_SEQUENCE    = 1u,
    JM2_STREAM_BAD_OFFSET      = 2u,
    JM2_STREAM_BAD_LENGTH      = 3u,
    JM2_STREAM_OVERFLOW        = 4u,
    JM2_STREAM_BAD_DATA        = 5u,
    JM2_STREAM_BAD_TRANSACTION = 6u,
    JM2_STREAM_BAD_METADATA    = 7u,
    JM2_STREAM_BAD_CRC         = 8u,
    JM2_STREAM_INCOMPLETE      = 9u,
    JM2_STREAM_LOAD_FAILED     = 10u,
    JM2_STREAM_BUSY            = 11u,
};
#endif

// ============================================================================
// CONFIGURATION
// ============================================================================


#define SAVE_INTERVAL 30000
#define CHECK_UART_INTERVAL 2500
#define MAX_BLOB_SIZE 1024

const int FRAME_COUNT = 45;
const int FPS_DELAY = 0;

// ============================================================================
// FORWARD DECLARATIONS
// ← In a .ino the IDE reorders functions automatically; in PlatformIO you must
//   declare anything called before its definition.
// ============================================================================
void sendToDSP(const char cmd[4], uint8_t *payload, size_t len);
void sendDataRobust(const char *header, const uint8_t *payload, size_t len);
void sendEffectChangeToDSP(uint8_t idx, uint8_t en, const uint8_t *k, const uint8_t *d);
void sendEffectChangeLegacyToDSP(uint8_t idx, uint8_t en, const uint8_t *k, const uint8_t *d);
void serviceJm2ReliableEffects();
void serviceJm2PresetTransaction();
void serviceJm2NamStream();
bool loadFxLayoutFromConfig();
void sendEQBandToDSP(uint8_t b, uint8_t enabled, uint16_t f, int8_t g, uint8_t q);
void sendDrumPatternToDSP(uint8_t rowIdx, uint8_t *velocities);
void updateDSPFromPreset();
void saveSystemState();
void loadSystemState();
bool loadPreset(uint8_t bank, uint8_t number, Preset &preset);
#if USE_MIDI
void processMidiFromPedal(uint8_t *data, size_t len);
#endif
bool onBLEDataReceived(uint8_t *data, size_t len);
void processBLEData(uint8_t *data,size_t len);
void initializeFactoryPresets();
size_t serializeStructToBlob(const Preset &p, uint8_t *buf);
void parseBlobToStruct(const uint8_t *buf, size_t len, Preset &p);
void processDSPPacket(const char *header, uint8_t *data, uint32_t len);
void sendPacket(const char *header_str, const uint8_t *payload, size_t len);
void sendJm2Hello();
void processJm2Packet(const uint8_t* data, size_t len);
void performEncoder1Action(int delta, int clickState);
void performEncoder2Action(int delta, int clickState);
void handleEncoders();
void handleSwitches();
void checkDSPIncoming();
void setupSwitches();
void sendSwitchStateToDSP(int switchIndex, bool switchState);
void playBootAnimation();
void servicePresetSerial();
void sendWebSnapshot(bool force=false);
void serviceWebSync();
static void sendWebCatalog();

// ============================================================================
// TJpg_Decoder callback
// ============================================================================
bool tft_output(int16_t x, int16_t y, uint16_t w, uint16_t h, uint16_t *bitmap)
{
  if (y >= display.tft.height())
    return 0;
  display.tft.pushImage(x, y, w, h, bitmap);
  return 1;
}

// ============================================================================
// FX LAYOUT TABLE  [knobCount, dropCount]  — matches config.js order
// ============================================================================
uint8_t FX_LAYOUT[18][2] = {
    {5, 0},  // 0:  Gate
    {8, 0},  // 1:  Comp
    {15, 6}, // 2:  Awah
    {10, 2}, // 3:  Ovrd
    {10, 2}, // 4:  Dist
    {10, 2}, // 5:  Equl
    {7, 10}, // 6:  Harm  (7 knobs: Level/Dry/Wet1/Wet2/ArpegRate/Gate/Glide, 10 dropdowns; canonical labels come from JmDefaultConfig.hpp)
    {3, 0},  // 7:  Vibr
    {7, 0},  // 8:  Chor
    {3, 3},  // 9:  Octv
    {5, 0},  // 10: Flng
    {7, 1},  // 11: Phas
    {4, 2},  // 12: Trem
    {7, 5},  // 13: FIR   (7 knobs: level/treble/mid/bass/presence/gain/gain1)
    {9, 3},  // 14: Dely
    {2, 1},  // 15: NAM
    {12, 2}, // 16: Rvrb
    {10, 2}, // 17: Gnrc
};

// ============================================================================
// GLOBALS
// ============================================================================
bool presetsLocked = false;

BluetoothManager btManager;
RotaryEncoder encoder2(ENCODER1_PIN_A, ENCODER1_PIN_B, ENCODER1_BTN);
RotaryEncoder encoder1(ENCODER2_PIN_A, ENCODER2_PIN_B, ENCODER2_BTN);
PushSwitch switch1(SWITCH1_PIN);
PushSwitch switch2(SWITCH2_PIN);
HardwareSerial dspSerial(2);
bool dspSerialOn = false;

#define MAX_DSP_PAYLOAD 10240
uint8_t dspBuffer_static[MAX_DSP_PAYLOAD];
uint32_t dspBytesRead = 0;
uint32_t dspTimeout = 0;

struct SystemState
{
  uint8_t currentBank;
  uint8_t currentPresetNum;
  uint8_t volume;
  bool a2dpEnabled;
  bool switchStates[4];
} state;

Preset currentPreset;

// Keep the persistent bank/preset selection consistent with physical Main UI
// controls. The UI must never mutate the SystemState layout directly.
void syncPresetSelectionFromDisplay(uint8_t bank, uint8_t number) {
  state.currentBank = bank;
  state.currentPresetNum = number;
}

// This is the sole runtime master-volume state. Preset data is not an authority.
static constexpr uint8_t kBootMasterVolume = 20;
void syncMasterVolumeFromDisplay(uint8_t volume) {
  state.volume = volume <= 100 ? volume : 100;
  currentPreset.masterVolume = state.volume;
}

void syncSetupA2DPEnabledFromDisplay(bool enabled) {
  state.a2dpEnabled = enabled;
  saveSystemState();
}
uint8_t blobBuffer[MAX_BLOB_SIZE];

// Serial preset console: line-oriented, bounded, never writes until the full
// dump (including CRC16 and END marker) has been validated.
static JmSerialPreset::Importer s_serialImport;
static bool s_serialImportActive = false;
static char s_serialLine[JmSerialPreset::kMaxLine];
static size_t s_serialLineLen = 0;
static bool s_serialLineOverflow = false;
static uint32_t s_serialLastByteMs = 0;

static const char* presetParamLabel(uint8_t fx, bool dropdown, uint8_t index) {
  if (fx >= TOTAL_FX) return nullptr;
  const FxLayout& layout = fxLayouts[fx];
  if (dropdown) return layout.dropLabels && index < layout.dropCount
       ? layout.dropLabels[index] : nullptr;
  return layout.knobLabels && index < layout.knobCount
       ? layout.knobLabels[index] : nullptr;
}

static void emitPresetSerialLine(const char* line, void*) { Serial.println(line); }

static void printPresetDump() {
  // Copy once; the output remains consistent even if the UI changes later.
  Preset snapshot = currentPreset;
  Serial.println();
  JmSerialPreset::dump(snapshot, FX_LAYOUT, presetParamLabel, emitPresetSerialLine, nullptr);
  Serial.println();
}

static void resetPresetImport() {
  s_serialImport.reset();
  s_serialImportActive = false;
}

static bool commitImportedPreset(const Preset& imported) {
  if (imported.bank > 6 || imported.number > 4 || (presetsLocked && imported.bank < 5)) {
    Serial.println("[LOAD] Refused: invalid location or locked factory bank");
    return false;
  }
  // Serial backups include a historic volume byte for format compatibility,
  // but importing never alters the independent live master setting.
  Preset normalized = imported;
  normalized.masterVolume = state.volume;
  uint8_t bytes[MAX_BLOB_SIZE];
  const size_t size = serializeStructToBlob(normalized, bytes);
  if (size < 4 || size > sizeof(bytes)) {
    Serial.println("[LOAD] Refused: serialized preset too large");
    return false;
  }
  if (!LittleFS.exists("/presets")) LittleFS.mkdir("/presets");
  char dest[48];
  if (imported.bank < 5)
    snprintf(dest, sizeof(dest), "/presets/f_%u_%u.bin", imported.bank, imported.number);
  else
    snprintf(dest, sizeof(dest), "/presets/c_%u_%u.bin", imported.bank - 5, imported.number);

  const char* temp = "/presets/.serial_import.tmp";
  File f = LittleFS.open(temp, "w");
  if (!f) { Serial.println("[LOAD] Cannot open temporary file"); return false; }
  size_t written = f.write(bytes, size);
  f.close();
  if (written != size) {
    LittleFS.remove(temp);
    Serial.println("[LOAD] Flash write incomplete; original slot preserved");
    return false;
  }
  File verify = LittleFS.open(temp, "r");
  bool ok = bool(verify) && verify.size() == size;
  if (ok) {
    uint8_t check[96];
    size_t offset = 0;
    while (offset < size) {
      size_t n = size - offset;
      if (n > sizeof(check)) n = sizeof(check);
      if (verify.read(check, n) != n || memcmp(check, bytes + offset, n)) { ok = false; break; }
      offset += n;
    }
  }
  if (verify) verify.close();
  if (!ok || !LittleFS.rename(temp, dest)) {
    LittleFS.remove(temp);
    Serial.println("[LOAD] Flash verify/rename failed; original slot preserved");
    return false;
  }

  currentPreset = normalized;
  state.currentBank = normalized.bank;
  state.currentPresetNum = normalized.number;
  saveSystemState();
  updateDSPFromPreset();
  display.refresh();
  // Inform a connected webapp using the same response format as BLE load.
  uint8_t header[3] = {0x34, (uint8_t)(size & 0xFF), (uint8_t)(size >> 8)};
  btManager.sendBLEBlob(header[0], bytes, size);
  if(btManager.connected())sendWebCatalog();
  Serial.printf("[LOAD] Saved and selected bank %u slot %u (%s)\n",
                (unsigned)imported.bank, (unsigned)imported.number + 1u, imported.name);
  return true;
}

static void processPresetSerialLine(const char* line) {
  if (!s_serialImportActive) {
    if (!strcmp(line, "dump-")) { printPresetDump(); return; }
    if (!strcmp(line, "load-")) {
      // The normal format uses load- on its own line, followed by the dump.
      s_serialImport.reset();
      s_serialImportActive = true;
      s_serialLastByteMs = millis();
      Serial.println("[LOAD] Paste JAMMATE_PRESET_V1 through END_JAMMATE_PRESET");
      return;
    }
    if (!strncmp(line, "load-", 5)) {
      s_serialImport.reset();
      s_serialImportActive = true;
      s_serialLastByteMs = millis();
      line += 5;
      if (!*line) return;
    } else if (*line) {
      Serial.println("[SERIAL] Commands: dump- | load- (then paste dump) | cancel-");
      return;
    } else return;
  }
  if (!strcmp(line, "cancel-")) {
    resetPresetImport(); Serial.println("[LOAD] Cancelled"); return;
  }
  // The dump has blank framing lines for easy reading/copying.
  if (!*line && s_serialImport.stage == JmSerialPreset::Importer::Stage::Header) return;
  const auto result = s_serialImport.consume(line, FX_LAYOUT);
  if (result == JmSerialPreset::Importer::Result::Error) {
    Serial.printf("[LOAD] REJECTED: %s (nothing written)\n", s_serialImport.error);
    resetPresetImport();
  } else if (result == JmSerialPreset::Importer::Result::Complete) {
    Preset imported = s_serialImport.candidate;
    resetPresetImport();
    commitImportedPreset(imported);
  }
}

void servicePresetSerial() {
  // ESP32 USB-serial ingress must be serviced even while waiting for Daisy UART.
  // No String growth or blocking readStringUntil() in the audio/UI loop.
  size_t budget = 1024;
  while (budget-- && Serial.available()) {
    const char c = (char)Serial.read();
    s_serialLastByteMs = millis();
    if (c == '\r') continue;
    if (c != '\n') {
      if (s_serialLineLen + 1 < sizeof(s_serialLine))
        s_serialLine[s_serialLineLen++] = c;
      else s_serialLineOverflow = true;
      continue;
    }
    s_serialLine[s_serialLineLen] = '\0';
    if (s_serialLineOverflow) {
      Serial.println("[LOAD] REJECTED: serial line too long");
      resetPresetImport();
    } else processPresetSerialLine(s_serialLine);
    s_serialLineLen = 0;
    s_serialLineOverflow = false;
  }
  if (s_serialImportActive && millis() - s_serialLastByteMs > 120000u) {
    resetPresetImport();
    Serial.println("[LOAD] Timed out; nothing written");
  }
}


int lastEncoder1Pos = 0;
int lastEncoder2Pos = 0;
unsigned long lastEncoder1BtnTime = 0;
unsigned long lastEncoder2BtnTime = 0;
const unsigned long DEBOUNCE_TIME = 200;
unsigned long lastSaveTime = 0;
unsigned long bothSwitchesHeldSince = 0;
unsigned long lastHeartbeatTime = 0;

// DSP receive buffers
uint8_t rx_raw_buffer[512];
size_t rx_idx = 0;
uint8_t rx_decoded[512];

// Deferred tuner activation — set from BLE callback, executed in loop()
// Avoids brownout from simultaneous BLE + UART + TFT SPI activity
static volatile int8_t pendingTunerState = -1; // -1=none, 0=disable, 1=enable
static uint32_t tunerPendingAt = 0;

// Mutex protecting sendPacket() / dspSerial.write() from concurrent BLE + main loop access.
// Both tasks run simultaneously on ESP32 dual-core; unprotected UART write causes FreeRTOS assert.
static SemaphoreHandle_t s_dspMutex = nullptr;

// Deferred BLE looper command (0x42) — copy payload here from BLE task,
// execute display update and state change in loop() to avoid TFT SPI contention.
static volatile bool     s_pendingLoopCmd    = false;
static volatile int8_t   s_pendingLooperEnable = -1; // BLE task -> UI task
static volatile bool     s_pendingDrumCmd    = false;
// Deferred preset display refresh — set by 0x32/0x33 handlers in BLE task;
// display.refresh() must run on the main task to avoid TFT SPI contention.
static volatile bool     s_pendingPresetRefresh = false;
static volatile bool     s_pendingFxParamRefresh = false;
static volatile int8_t   s_pendingFxEnableRefresh = -1;
static uint8_t           s_pendingFxParamPid = 0; // 0-based combined param index (knob0=0, drop0=knobCount)
static uint8_t           s_loopCmdPayload[16];
static uint8_t           s_drumCmdPayload[16]; // 16 bytes: 4-tag + 12 data

// Show DSP load in overlay on next LOAD packet after an effect toggle
bool pendingLoadDisplay = false;

// NAM upload state. The webapp parses the .nam JSON and sends only the
// weights[] array as raw little-endian float32 bytes. Metadata is
// weightCount + CRC32(weight bytes) + UTF-8 filename.
static bool     s_namTransferActive = false;
static uint32_t s_namExpectedWeights = 0;
static uint32_t s_namExpectedBytes  = 0;
static uint32_t s_namReceivedBytes  = 0;
static uint32_t s_namExpectedCrc    = 0;
static uint32_t s_namRunningCrc     = 0xFFFFFFFF;
static uint16_t s_namExpectedChunk  = 0;
static uint16_t s_namDspChunkIndex  = 0;
static char     s_namModelName[65]  = {0};
// Buffer the full model on ESP32 so the DSP gets one continuous UART burst
// after BLE transfer completes, avoiding DSP stream-timeout from BLE gaps.
static uint8_t  s_namWeightBuffer[1871 * 4] = {0};
static uint32_t s_namWeightOffset = 0;
// Snapshot of the raw NAMH metadata payload to re-send at DSP blast time
static uint8_t  s_namMetaSnapshot[74] = {0};
static size_t   s_namMetaSnapshotLen = 0;

// DSP-side NAM transport ACK state (NMAK packets).
static volatile uint32_t s_namDspAckSerial = 0;
static volatile uint8_t  s_namDspAckStage  = 0xFF;
static volatile uint8_t  s_namDspAckStatus = 0xFF;
static volatile uint16_t s_namDspAckNext   = 0;

// MIDI file upload state (0x80/0x81/0x82 from webapp).
// Raw .mid bytes are buffered on the ESP then forwarded to the DSP via UART
// (MBEG / MDAT / MEND packets) so the DSP can load to SDRAM and optionally
// write the file to its SD card.
static bool     s_midiTransferActive  = false;
static uint32_t s_midiExpectedBytes   = 0;
static uint32_t s_midiReceivedBytes   = 0;
static uint16_t s_midiExpectedChunk   = 0;
static uint16_t s_midiSubIndex        = 0; // global sub-packet counter for MSUB
static char     s_midiFileName[65]    = {0};
static uint8_t *s_midiBuffer          = nullptr; // heap-allocated on START
static size_t   s_midiBufferCapacity  = 0;
static constexpr uint32_t MIDI_MAX_FILE_BYTES = 131072u; // 128 KB hard cap

// UART auto-connect state (referenced from both loop() and onBLEDataReceived())
uint32_t lastUartAttempt = 0;
const uint32_t UART_RETRY_INTERVAL = 500;
const uint32_t UART_RETRY_TIMEOUT = 10000;
uint32_t uartStartTime = 0;
bool checkUART = true;

// JamMate Protocol V2 foundation state. Legacy traffic remains active while V2
// is proven with a non-blocking HELO/HELA handshake.
static bool s_v8Applying=false,s_v8StreamFile=false;
static uint8_t s_v8ApplyError=0;
static uint32_t s_jm2PeerCaps=0;
static void v8Applied(uint8_t status);
static bool     s_jm2Connected        = false;
static bool     s_jm2EverConnected    = false;
static bool     s_jm2HelloSent        = false;
static uint16_t s_jm2NextTransaction  = 1;
static uint16_t s_jm2HelloTransaction = 0;
static uint32_t s_jm2LastHelloMs      = 0;
static uint32_t s_jm2RxPackets        = 0;
static uint32_t s_jm2BadPackets       = 0;

// JMP2 v4 reliable single-effect transport. BLE/UI writers only update a
// per-effect mailbox. loop() is the sole reliable UART sender/retry owner.
static constexpr uint32_t JM2_EFFECT_ACK_TIMEOUT_MS = 250u;
static constexpr uint8_t  JM2_EFFECT_MAX_RETRIES    = 3u;
static constexpr size_t   JM2_EFFECT_MAX_BYTES      = 4u + 32u;

struct Jm2EffectMailbox { bool pending; uint16_t len; uint8_t bytes[JM2_EFFECT_MAX_BYTES]; };
struct Jm2EffectFlight {
  bool active; bool acked; bool nacked;
  uint16_t transaction; uint16_t sequence; uint16_t len;
  uint8_t bytes[JM2_EFFECT_MAX_BYTES];
  uint8_t retries; uint32_t sent_ms;
};

static Jm2EffectMailbox s_jm2EffectMailbox[MAX_EFFECTS] = {};
static Jm2EffectFlight  s_jm2EffectFlight = {};
static uint8_t          s_jm2EffectScan = 0;
static portMUX_TYPE     s_jm2EffectMux = portMUX_INITIALIZER_UNLOCKED;


// JMP2 v5 atomic preset transport. updateDSPFromPreset() only snapshots the
// requested preset; loop() owns the transaction and sends one reliable item at
// a time. DSP stages all items and commits only after PEND validates.
static constexpr uint16_t JM2_PRESET_ITEM_COUNT = MAX_EFFECTS + 12u;
static constexpr uint32_t JM2_PRESET_ACK_TIMEOUT_MS = 250u;
static constexpr uint8_t  JM2_PRESET_MAX_RETRIES = 3u;
static constexpr size_t   JM2_PRESET_ITEM_MAX_BYTES = 40u;

enum Jm2PresetPhase : uint8_t
{
  JM2_PRESET_IDLE = 0,
  JM2_PRESET_BEGIN,
  JM2_PRESET_DATA,
  JM2_PRESET_END,
};

struct Jm2PresetFlight
{
  bool active;
  bool waiting;
  bool acked;
  bool nacked;
  uint16_t transaction;
  uint16_t sequence;
  uint16_t item_index;
  uint8_t retries;
  uint32_t sent_ms;
  Jm2PresetPhase phase;
  Preset preset;
};

static volatile bool s_jm2PresetPending = false;
static Preset         s_jm2PresetPendingSnapshot{};
static Jm2PresetFlight s_jm2PresetFlight{};
static portMUX_TYPE    s_jm2PresetMux = portMUX_INITIALIZER_UNLOCKED;

// JMP2 v6 generic NAM stream. Browser->ESP upload remains unchanged; after the
// complete model is CRC-validated on ESP, loop() owns SBEG/SDAT/SEND.
static constexpr uint32_t JM2_STREAM_ACK_TIMEOUT_MS = 500u;
static constexpr uint8_t  JM2_STREAM_MAX_RETRIES    = 3u;

enum Jm2NamStreamPhase : uint8_t
{
  JM2_NAM_STREAM_IDLE = 0,
  JM2_NAM_STREAM_BEGIN,
  JM2_NAM_STREAM_DATA,
  JM2_NAM_STREAM_END,
};

struct Jm2NamStreamFlight
{
  bool active;
  bool waiting;
  bool acked;
  bool nacked;
  bool reply_valid;
  uint16_t transaction;
  uint16_t sequence;
  uint32_t offset;
  uint16_t last_data_len;
  uint16_t reply_next_sequence;
  uint16_t reply_reason;
  uint32_t reply_received_bytes;
  uint8_t retries;
  uint32_t sent_ms;
  Jm2NamStreamPhase phase;
};

static volatile bool      s_jm2NamPending = false;
static Jm2NamStreamFlight s_jm2NamFlight{};


// ============================================================================
// BLOB SERIALIZATION
// ============================================================================
size_t serializeStructToBlob(const Preset& in, uint8_t* out) {
    size_t off = 0;
    uint8_t nameLen = (uint8_t)strnlen(in.name, PRESET_NAME_LENGTH - 1);

    out[off++] = 0x03;          // version
    out[off++] = in.bpm;
    out[off++] = in.masterVolume; // preserve actual master level in saved preset
    out[off++] = nameLen;
    memcpy(&out[off], in.name, nameLen); off += nameLen;

    for (int i = 0; i < MAX_EFFECTS; i++) {
        uint8_t kCount    = FX_LAYOUT[i][0];
        uint8_t dCount    = FX_LAYOUT[i][1];
        uint8_t flatCount = 1 + kCount + dCount;

        out[off++] = i;
        out[off++] = flatCount;
        out[off++] = in.effects[i].enabled ? 1 : 0;
        for (int k = 0; k < kCount; k++) out[off++] = in.effects[i].knobs[k];
        for (int d = 0; d < dCount; d++) out[off++] = in.effects[i].dropdowns[d];
    }

    // EQ
    out[off++] = 0xFE;
    out[off++] = 12;
    for (int i = 0; i < 12; i++) {
        out[off++] = in.eqPoints[i].freq & 0xFF;
        out[off++] = (in.eqPoints[i].freq >> 8) & 0xFF;
        out[off++] = (int8_t)in.eqPoints[i].gain;
        out[off++] = in.eqPoints[i].q;
        out[off++] = in.eqPoints[i].enabled ? 1 : 0;
    }
    return off;
}
void parseBlobToStruct(const uint8_t* blob, size_t size, Preset& out) {
    if (size < 4) return;
    size_t off = 0;

    /* ver */    off++;
    out.bpm    = blob[off++];
    out.masterVolume = blob[off++];
    const uint8_t rawNameLen = blob[off++];
    const size_t available = (rawNameLen <= size - off) ? rawNameLen : size - off;
    const size_t copyLen = (available < PRESET_NAME_LENGTH) ? available : PRESET_NAME_LENGTH - 1;
    memcpy(out.name, &blob[off], copyLen);
    out.name[copyLen] = '\0';
    off += available;

    while (off + 2 <= size) {
        uint8_t id = blob[off++];

        // EQ sentinel
        if (id == 0xFE) {
            if (off >= size) break;
            uint8_t count = blob[off++];
            for (int i = 0; i < count && i < 12 && off + 5 <= size; i++) {
                out.eqPoints[i].freq    = blob[off] | (blob[off+1] << 8);
                out.eqPoints[i].gain    = (int8_t)blob[off+2];
                out.eqPoints[i].q       = blob[off+3];
                out.eqPoints[i].enabled = blob[off+4];
                off += 5;
            }
            break;
        }

        if (id >= MAX_EFFECTS || off >= size) { break; }
        uint8_t flatCount = blob[off++];
        if (off + flatCount > size) break;

        uint8_t kCount = FX_LAYOUT[id][0];
        uint8_t dCount = FX_LAYOUT[id][1];

        // flat[0] = enable
        if (flatCount >= 1)
            out.effects[id].enabled = blob[off] != 0;

        // flat[1..K] = knobs
        for (int k = 0; k < kCount && (1 + k) < flatCount; k++)
            out.effects[id].knobs[k] = blob[off + 1 + k];

        // flat[K+1..] = dropdowns
        for (int d = 0; d < dCount && (1 + kCount + d) < flatCount; d++)
            out.effects[id].dropdowns[d] = blob[off + 1 + kCount + d];

        off += flatCount;
    }
}
// ============================================================================
// DSP PACKET PROCESSING
// ============================================================================
void processDSPPacket(const char *header, uint8_t *data, uint32_t len)
{
  if (strncmp(header, "FREQ", 4) == 0 && len == 4)
  {
    float freq;
    memcpy(&freq, data, 4);
    Serial.println(freq);
    static uint32_t lastFreqBLESend = 0;
    if (millis() - lastFreqBLESend >= 500) {
      lastFreqBLESend = millis();
      uint8_t packet[7];
      packet[0] = 0x35;
      packet[1] = 4;
      packet[2] = 0;
      memcpy(&packet[3], data, 4);
      btManager.sendBLEData(packet, 7);
    }
    if (display.isTunerActive())
      display.updateTuner(freq);
  }
  else if (strncmp(header, "LOAD", 4) == 0 && len == 4)
  {
    float load;
    memcpy(&load, data, 4);
    s_cpuTelemetry.sample(load);
    Serial.printf("[DSP] Load: %.1f%%\n", load * 1.0f);
    char statusMsg[32];
    snprintf(statusMsg, sizeof(statusMsg), "CPU: %.1f%%", load * 1.0f);
    display.updateStatusLine(statusMsg);
    if (pendingLoadDisplay) {
      pendingLoadDisplay = false;
      display.showMessage(statusMsg);
    }
  }
  else if (strncmp(header, "STAT", 4) == 0)
  {
    // Null-terminate and push to status line
    char statusMsg[64];
    size_t copyLen = (len < (int)(sizeof(statusMsg) - 1)) ? len : sizeof(statusMsg) - 1;
    memcpy(statusMsg, data, copyLen);
    statusMsg[copyLen] = '\0';
    Serial.printf("[DSP] STAT: %s\n", statusMsg);
    display.updateStatusLine(statusMsg);
  }
  else if (strncmp(header, "JMP2", 4) == 0)
  {
    processJm2Packet(data, len);
  }
  else if (strncmp(header, "NMAK", 4) == 0 && len >= 4)
  {
    s_namDspAckStage  = data[0];
    s_namDspAckStatus = data[1];
    s_namDspAckNext   = (uint16_t)data[2] | ((uint16_t)data[3] << 8);
    __sync_synchronize();
    s_namDspAckSerial++;
  }
  else if (strncmp(header, "LOOP", 4) == 0)
  {
    // Daisy → ESP: looper status notification
    // data[0] = 1: any state→TS_RECORDING (armed threshold or sync fired)
    // data[0] = 2: TS_RECORDING→TS_PLAYING (first loop closed; data[1..2] = loop_ms)
    if (len >= 1 && data[0] == 1)
    {
      Serial.println("[DSP] LOOP: recording started");
      display.applyLooperStateChange(1);
      // The display loop paints state and progress independently; do not
      // redraw the live ring inside the UART packet handler.
    }
    else if (len >= 3 && data[0] == 2)
    {
      uint32_t loopMs = (uint32_t)data[1] | ((uint32_t)data[2] << 8);
      Serial.printf("[DSP] LOOP: first loop closed, length=%ums\n", loopMs);
      display.applyLooperStateChange(4, loopMs);
      // The display loop paints state and progress independently; do not
      // redraw the live ring inside the UART packet handler.
    }
  }
  else if (strncmp(header, "BEAT", 4) == 0)
  {
    // The DSP transport is master. Decode beat/bar/BPM/sequence once, then
    // defer all TFT work to display.loop().
    const bool wasRunning = display.drumEnabled;
    display.onDspBeat(data, len);
    if (!wasRunning && display.drumEnabled)
      Serial.println("[DSP] Drums auto-started with looper recording");
  }
  else if (strncmp(header, "DRUM", 4) == 0)
  {
    // Daisy → ESP: 4-bar drum sync notification
    // data[0] = cyclic 8-bit bar-sync counter
    // data[1..3] reserved
    if (len >= 1)
      Serial.printf("[DSP] DRUM sync: count=%d\n", data[0]);
  }
  else if (strncmp(header, "NAML", 4) == 0)
  {
    uint8_t packet[len + 2];
    packet[0] = 0x45;
    memcpy(&packet[1], data, len);
    btManager.sendBLEData(packet, len + 1);
  }
  else if (strncmp(header, "IRFL", 4) == 0)
  {
    uint8_t packet[len + 2];
    packet[0] = 0x46;
    memcpy(&packet[1], data, len);
    btManager.sendBLEData(packet, len + 1);
  }
  else
  {
    Serial.printf("[DSP] Unknown Packet: %.4s (%d bytes)\n", header, len);
  }
}

// ============================================================================
// DYNAMIC LABEL POOL
// Populated by loadFxLayoutFromConfig() from /config.json (pipe-delimited).
// The display code (fxLayouts[], fxLabels[]) is updated to point here at runtime.
// ============================================================================
#define CFG_POOL_SIZE    6144
#define MAX_DROP_OPTIONS   28  // max options per dropdown (NAM has 25)

static char     g_cfgPool[CFG_POOL_SIZE];
static int      g_cfgPoolUsed = 0;

static const char*  g_knobPtrs  [MAX_EFFECTS][MAX_EFFECT_KNOBS];
static const char*  g_dropLblPtrs[MAX_EFFECTS][MAX_EFFECT_DROPDOWNS];
static const char*  g_optStrPtrs [MAX_EFFECTS][MAX_EFFECT_DROPDOWNS][MAX_DROP_OPTIONS];
static const char** g_optArrPtrs [MAX_EFFECTS][MAX_EFFECT_DROPDOWNS];
static uint8_t      g_optCounts  [MAX_EFFECTS][MAX_EFFECT_DROPDOWNS];
static char         g_fxNameBufs [MAX_EFFECTS][12];

// ============================================================================
// CONFIG LOADER
// Tries /config.json (new pipe-delimited full-name format) first.
// Falls back to /config.js (legacy [[k,d],...] counts-only format).
// Call once after LittleFS.begin(), and again after a 0x52/0x50 BLE upload.
// ============================================================================
#include "FxConfigApply.hpp"

bool loadFxLayoutFromConfig()
{
  // ---- NEW FORMAT: /config.json (pipe-delimited with labels) ----
  if (LittleFS.exists("/config.json"))
  {
    File f = LittleFS.open("/config.json", "r");
    if (!f) { Serial.println("[CFG] Cannot open /config.json"); return false; }

    if(f.size()>4096){f.close();Serial.println("[CFG] Configuration too large");return false;}
    String text=f.readString();f.close();
    const bool loaded=applyFxConfigText(text.c_str(),text.length());
    if(!loaded)Serial.println("[CFG] Invalid configuration; upload a matching config");
    return loaded;
  }

  // ---- LEGACY FORMAT: /config.js  [[k,d], ...] — counts only ----
  if (!LittleFS.exists("/config.js"))
  {
    Serial.println("[CFG] No config found, using compiled defaults");
    return false;
  }
  File f = LittleFS.open("/config.js", "r");
  if (!f) return false;
  String js = f.readString();
  f.close();
  Serial.printf("[CFG] Loaded legacy config.js (%d bytes)\n", js.length());

  int effectIdx = 0;
  int pos = js.indexOf('[');
  if (pos < 0) { Serial.println("[CFG] ERROR: no '[' in config.js"); return false; }
  pos++;

  while (effectIdx < MAX_EFFECTS)
  {
    int subOpen  = js.indexOf('[', pos);
    if (subOpen  < 0) break;
    int subClose = js.indexOf(']', subOpen + 1);
    if (subClose < 0) break;
    String inner = js.substring(subOpen + 1, subClose);
    inner.trim();
    int comma = inner.indexOf(',');
    if (comma < 0) break;
    int kCount = constrain(inner.substring(0, comma).toInt(), 0, MAX_EFFECT_KNOBS);
    int dCount = constrain(inner.substring(comma + 1).toInt(), 0, MAX_EFFECT_DROPDOWNS);
    FX_LAYOUT[effectIdx][0] = kCount;
    FX_LAYOUT[effectIdx][1] = dCount;
    Serial.printf("[CFG]  FX[%2d] knobs=%d drops=%d\n", effectIdx, kCount, dCount);
    effectIdx++;
    pos = subClose + 1;
  }
  Serial.printf("[CFG] Loaded %d effect layouts (legacy)\n", effectIdx);
  return effectIdx==MAX_EFFECTS;
}
// ============================================================================
// NAM UPLOAD HELPERS
// ============================================================================
static uint32_t crc32_update_byte(uint32_t crc, uint8_t b)
{
  crc ^= b;
  for (uint8_t i = 0; i < 8; i++)
    crc = (crc & 1) ? (0xEDB88320UL ^ (crc >> 1)) : (crc >> 1);
  return crc;
}

static uint32_t crc32_update_buffer(uint32_t crc, const uint8_t *buf, size_t len)
{
  for (size_t i = 0; i < len; i++)
    crc = crc32_update_byte(crc, buf[i]);
  return crc;
}

static void sendNamAck(uint8_t ackCmd, uint8_t status, uint16_t index = 0xFFFF)
{
  if(!s_v8Applying)return;
  if(status)s_v8ApplyError=status;
  if(ackCmd==0x76)v8Applied(status);
}

// Keep ESP->DSP NAMW packets small enough for DSP-side UART/COBS receive buffers.
// Payload is [uint16 chunkIndex][uint16 chunkLen][bytes], so 48 data bytes gives
// a 52-byte payload before the packet header and remains safely under 64 bytes.
#define NAM_DSP_WEIGHT_CHUNK_BYTES 48u

static bool waitForNamDspAck(uint32_t priorSerial, uint8_t stage, uint16_t expectedNext, uint32_t timeoutMs)
{
  const unsigned long t0 = millis();
  while (millis() - t0 < timeoutMs)
  {
    // DSP UART is parsed only by loop(). The BLE callback must not re-enter
    // processDSPPacket()/display code from a second task.
    if (s_namDspAckSerial != priorSerial)
    {
      __sync_synchronize();
      if (s_namDspAckStage != stage)
      {
        // Unrelated/stale NAM ACK; keep waiting for the requested stage.
        priorSerial = s_namDspAckSerial;
        continue;
      }
      if (s_namDspAckStatus != 0)
      {
        Serial.printf("[NAM] DSP NACK stage=%u status=%u next=%u\n",
                      s_namDspAckStage, s_namDspAckStatus, s_namDspAckNext);
        return false;
      }
      if (expectedNext != 0xFFFF && s_namDspAckNext != expectedNext)
      {
        Serial.printf("[NAM] DSP ACK mismatch stage=%u next=%u expected=%u\n",
                      stage, s_namDspAckNext, expectedNext);
        return false;
      }
      return true;
    }
    delay(1);
  }
  Serial.printf("[NAM] DSP ACK timeout stage=%u expectedNext=%u\n", stage, expectedNext);
  return false;
}

static bool sendNamPacketAndWait(const char *header, const uint8_t *payload, size_t len,
                                 uint8_t stage, uint16_t expectedNext, uint32_t timeoutMs = 2000)
{
  const uint32_t prior = s_namDspAckSerial;
  sendDataRobust(header, payload, len);
  // HardwareSerial::write() may return after queuing bytes. For ACK-gated NAM
  // traffic, make sure the complete frame is physically on the wire first.
  dspSerial.flush();
  const bool ok = waitForNamDspAck(prior, stage, expectedNext, timeoutMs);
  if(ok) delay(10); // deliberate RX idle gap after each DSP ACK
  return ok;
}

static bool forwardNamWeightsToDsp(const uint8_t *chunkData, size_t chunkLen)
{
  Serial.printf("[NAM] FWD: ACK-gated %u bytes to DSP\n", (unsigned)chunkLen);
  unsigned long blastStart = millis();
  size_t off = 0;
  while (off < chunkLen) {
    size_t partLen = chunkLen - off;
    if (partLen > NAM_DSP_WEIGHT_CHUNK_BYTES) partLen = NAM_DSP_WEIGHT_CHUNK_BYTES;

    partLen &= ~((size_t)3u);
    if (partLen == 0) return false;

    const uint16_t thisChunk = s_namDspChunkIndex;
    const size_t dspPayloadLen = 4 + partLen;
    uint8_t dspPayload[4 + NAM_DSP_WEIGHT_CHUNK_BYTES];
    dspPayload[0] = (uint8_t)(thisChunk & 0xFF);
    dspPayload[1] = (uint8_t)((thisChunk >> 8) & 0xFF);
    dspPayload[2] = (uint8_t)(partLen & 0xFF);
    dspPayload[3] = (uint8_t)((partLen >> 8) & 0xFF);
    memcpy(dspPayload + 4, chunkData + off, partLen);

    unsigned long readyWait = millis();
    while (!digitalRead(DAISY_READY_PIN)) {
      if (millis() - readyWait > 2000) {
        Serial.printf("[NAM] FWD: READY timeout at chunk %u\n", thisChunk);
        return false;
      }
      delay(1);
    }

    if (!sendNamPacketAndWait("NAMW", dspPayload, dspPayloadLen, 1, (uint16_t)(thisChunk + 1)))
      return false;

    s_namDspChunkIndex = (uint16_t)(thisChunk + 1);
    off += partLen;
  }
  Serial.printf("[NAM] FWD: done — %u DSP chunks in %lums\n",
                (unsigned)s_namDspChunkIndex, millis() - blastStart);
  return true;
}

// ============================================================================
// BLE RECEIVE HANDLER
// ============================================================================
#include "WebSyncRuntime.hpp"
#include "V8Resources.hpp"

bool onBLEDataReceived(uint8_t *data, size_t len) {
  if(!s_bleCommands || !len || len>JmWebSync::MAX_FRAME)return false;
  uint8_t slot=0xff;
  for(uint8_t i=0;i<5;i++){
    if(i<4&&len>sizeof(s_commandSmall[0]))continue;
    bool expected=false;if(s_commandBusy[i].compare_exchange_strong(expected,true)){slot=i;break;}
  }
  if(slot==0xff)return false;
  uint8_t* bytes=slot<4?s_commandSmall[slot]:s_commandLarge;
  memcpy(bytes,data,len);BleCommand command{bytes,len,btManager.session(),slot};
  if(xQueueSend(s_bleCommands,&command,0)!=pdTRUE){s_commandBusy[slot]=false;return false;}
  return true;
}
void processBLEData(uint8_t *data, size_t len)
{
  if (len < 1)
    return;

  uint8_t cmd = data[0];
  uint16_t payloadLen = 0;
  uint8_t *payload = nullptr;

  if (len >= 3)
  {
    payloadLen = data[1] | (data[2] << 8);
    if (len >= payloadLen + 3)
      payload = &data[3];
  }

  if(len<3 || payloadLen+3!=len)return;
  const size_t minimum = cmd==0x20?3:cmd==0x22?6:cmd==0x23?5:
     cmd==0x24||cmd==0x26||cmd==0x43||cmd==0x44||cmd==0x47?1:
     cmd==0x25?3:cmd==0x32||cmd==0x33||cmd==0x39?2:cmd==0x40?144:
     cmd==0x41?12:cmd==0x42?16:cmd==0x52?3:0;
  if(payloadLen<minimum)return;
  switch (cmd)
  {
  case 0x90: case 0x91: case 0x92: case 0x93: case 0x95: handleV8Resource(cmd,payload,payloadLen);break;
  case 0x37: Serial.printf("[WEB] Catalog read heap=%u stackMin=%u\n",ESP.getFreeHeap(),unsigned(uxTaskGetStackHighWaterMark(nullptr)));sendWebCatalog(); break;
  case 0x39: sendWebSlot(payload[0],payload[1]); break;
  case 0x54: Serial.printf("[WEB] Config read heap=%u largest=%u stackMin=%u\n",ESP.getFreeHeap(),heap_caps_get_largest_free_block(MALLOC_CAP_8BIT),unsigned(uxTaskGetStackHighWaterMark(nullptr)));
    if(payloadLen==4)sendWebConfigPage(JmWebSync::get16(payload),JmWebSync::get16(payload+2)); break;
  case 0x01: // BLE keep-alive ping — no response needed
    break;
  case 0x20:
  {
    if (!payload)
      break;
    uint8_t fx = payload[0];  // ← back to original
    uint8_t pid = payload[1]; // ← back to original
    uint8_t val = payload[2]; // ← back to original

    Serial.printf("[BLE] 0x20 fx=%d pid=%d val=%d\n", fx, pid, val);

    if (fx < MAX_EFFECTS)
    {
      if(pid>FX_LAYOUT[fx][0]+FX_LAYOUT[fx][1])break;
      // pid=0 is the enable/disable checkbox (flat index 0)
      if (pid == 0)
      {
        currentPreset.effects[fx].enabled = (val != 0);
        Serial.printf("[BLE] Enable FX %d -> %d\n", fx, val);
        pendingLoadDisplay = true;
        s_pendingFxEnableRefresh = fx;
      }
      else
      {
        uint8_t actualKnobs = FX_LAYOUT[fx][0];
        uint8_t paramPid = pid - 1; // shift by 1 since flat 0 = checkbox
        if (paramPid >= actualKnobs)
        {
          uint8_t dropdownIdx = paramPid - actualKnobs;
          uint8_t dIdx = dropdownIdx;
          if (dIdx < MAX_EFFECT_DROPDOWNS)
            currentPreset.effects[fx].dropdowns[dIdx] = val;
          Serial.printf("[BLE] Drop FX %d drop[%d] -> %d\n", fx, dIdx, val);
        }
        else
        {
          currentPreset.effects[fx].knobs[paramPid] = val;
        }
      }
      sendEffectChangeToDSP(fx, currentPreset.effects[fx].enabled,
                            currentPreset.effects[fx].knobs,
                            currentPreset.effects[fx].dropdowns);
      if (pid >= 1 && display.currentState == STATE_FX_EDIT && display.fxEditIndex == (int)fx) {
        s_pendingFxParamPid     = pid - 1; // shift: flat 0=enable not shown in edit screen
        s_pendingFxParamRefresh = true;
      }
    }
    break;
  }
  case 0x27: {
    if(payloadLen<3)break;const uint8_t fx=payload[0],count=payload[1];
    if(fx>=18||count!=1+FX_LAYOUT[fx][0]+FX_LAYOUT[fx][1]||payloadLen!=size_t(count)+2)break;
    auto& effect=currentPreset.effects[fx];effect.enabled=!!payload[2];
    memcpy(effect.knobs,payload+3,FX_LAYOUT[fx][0]);memcpy(effect.dropdowns,payload+3+FX_LAYOUT[fx][0],FX_LAYOUT[fx][1]);
    sendEffectChangeToDSP(fx,effect.enabled,effect.knobs,effect.dropdowns);s_pendingPresetRefresh=true;break;
  }
  case 0x22:
  { // EQ band
    if (!payload)
      break;
    uint8_t bandIdx = payload[0];
    uint8_t enabled = payload[1];
    uint16_t freq = payload[2] | (payload[3] << 8);
    int8_t gain = (int8_t)payload[4];
    uint8_t q = payload[5];
    if (bandIdx < 12)
    {
      currentPreset.eqPoints[bandIdx].freq = freq;
      currentPreset.eqPoints[bandIdx].gain = gain;
      currentPreset.eqPoints[bandIdx].q = q;
      currentPreset.eqPoints[bandIdx].enabled = (enabled != 0);
    }
    if(bandIdx>=12)break;
    delay(10);
    sendEQBandToDSP(bandIdx, enabled, freq, gain, q);
    uint8_t eqFrame[7]={0x22};memcpy(eqFrame+1,payload,6);btManager.sendBLEData(eqFrame,sizeof(eqFrame));
    break;
  }
  case 0x23:
  { // Util
    if (!payload)
      break;
    uint8_t t = payload[0];
    uint8_t en = payload[1];
    uint8_t lv = payload[2];
    uint16_t f = payload[3] | (payload[4] << 8);
    if(t==0){display.noiseEnabled=!!en;display.noiseLevel=lv;}
    if(t==1){display.toneEnabled=!!en;display.toneLevel=lv;display.toneFreq=f;}
    uint8_t p[5] = {t, en, lv, (uint8_t)(f >> 8), (uint8_t)(f & 0xFF)};
    delay(10);
    sendToDSP("UTIL", p, 5);
    if (t == 2) {
      // Defer toggleTuner to loop() — avoids brownout from BLE+UART+TFT firing together
      pendingTunerState = (en > 0) ? 1 : 0;
      tunerPendingAt = millis();
    }
    break;
  }
  case 0x24:
  { // Bypass
    if (!payload) break;
    bool enable = (payload[0] != 0);
    display.toggleBypass(enable);
    break;
  }
  case 0x25:
  { // Global
    if (!payload || payloadLen < 3)
      break;
    uint8_t btVol = payload[0];
    uint8_t bpm = payload[1];
    uint8_t flags = payload[2];
    // Record the previous value before updating the displayed preset.
    // ESP Drum-page edits already use TCTL op 1; BLE SET_GLOBAL previously
    // only sent GEN, which does not update the audio-thread transport clock.
    currentPreset.masterVolume = state.volume;
    currentPreset.bpm = bpm;
    bool a2dpReq = (flags & 0x01);
    if (state.a2dpEnabled != a2dpReq)
    {
      state.a2dpEnabled = a2dpReq;
      if (state.a2dpEnabled)
        btManager.enableA2DP();
      else
        btManager.disableA2DP();
    }
    uint8_t dspPayload[13] = {0};
    dspPayload[0] = state.volume;
    dspPayload[1] = btVol;
    dspPayload[2] = bpm;
    dspPayload[3] = flags;
    display.btAudioEnabled=a2dpReq;display.btAudioVol=btVol;
    btManager.setA2DPvolume(btVol);
    delay(10);
    sendToDSP("GEN ", dspPayload, 4);
    // Send even when the requested value equals the cached preset BPM: a
    // previous command may have been lost while DSP was resetting/busy.
    display.setTempo(bpm);
    break;
  }
  case 0x26:
  { // Explicit master-volume adjustment, independent of presets and BPM.
    if (!payload || payloadLen < 1 || payload[0] > 100) break;
    syncMasterVolumeFromDisplay(payload[0]);
    const uint8_t dspPayload[4] = {state.volume, 0, currentPreset.bpm, 0};
    sendDataRobust("GEN ", dspPayload, sizeof(dspPayload));
    Serial.printf("[BLE] Master volume set to %u%%\n", (unsigned)state.volume);
    break;
  }
  case 0x30:
  { // Handshake
    Serial.printf("[WEB] State read heap=%u stackMin=%u\n",ESP.getFreeHeap(),unsigned(uxTaskGetStackHighWaterMark(nullptr)));
    s_webReadyEpoch=btManager.session();
    size_t size = serializeStructToBlob(currentPreset, blobBuffer);
    uint8_t head[3] = {0x31, (uint8_t)(size & 0xFF), (uint8_t)(size >> 8)};
    btManager.sendBLEBlob(head[0], blobBuffer, size);
    sendWebSnapshot(true);
    Serial.printf("[WEB] State sent bank=%u slot=%u bpm=%u volume=%u\n",currentPreset.bank,currentPreset.number,currentPreset.bpm,state.volume);
    break;
  }
  case 0x32: {
    const uint8_t bank=payload[0],slot=payload[1];
    if(!JmWebSync::validSlot(bank,slot)||!validWebPreset(payload+2,payloadLen-2)){
      presetAck(cmd,1,bank,slot);break;
    }
    if(presetsLocked&&bank<5){presetAck(cmd,2,bank,slot);break;}
    static Preset saved;saved={};parseBlobToStruct(payload+2,payloadLen-2,saved);
    saved.bank=bank;saved.number=slot;saved.masterVolume=state.volume;
    uint8_t* const bytes=blobBuffer;size_t n=serializeStructToBlob(saved,bytes);
    char path[40];webSlotPath(bank,slot,path,sizeof(path));
    if(!writeVerifiedFile(path,bytes,n)){presetAck(cmd,3,bank,slot);break;}
    currentPreset=saved;state.currentBank=bank;state.currentPresetNum=slot;
    saveSystemState();updateDSPFromPreset();s_pendingPresetRefresh=true;
    presetAck(cmd,0,bank,slot);sendWebSnapshot(true);sendWebCatalog();break;
  }
  case 0x33: {
    const uint8_t bank=payload[0],slot=payload[1];
    if(!JmWebSync::validSlot(bank,slot)){presetAck(cmd,1,bank,slot);break;}
    static Preset loaded;loaded={};
    if(!loadPreset(bank,slot,loaded)){presetAck(cmd,3,bank,slot);break;}
    currentPreset=loaded;state.currentBank=bank;state.currentPresetNum=slot;
    saveSystemState();updateDSPFromPreset();s_pendingPresetRefresh=true;
    size_t n=serializeStructToBlob(currentPreset,blobBuffer);
    btManager.sendBLEBlob(0x34,blobBuffer,n);
    presetAck(cmd,0,bank,slot);sendWebSnapshot(true);break;
  }
  case 0x40:
  { // Drum pattern — full 9×16 grid (144 bytes, no row index prefix)
    if (payloadLen < 144)
      break;
    memcpy(s_webDrumGrid,payload,144);s_webGridRevision++;
    btManager.sendBLEBlob(0x57,s_webDrumGrid,144);
    for (uint8_t row = 0; row < 9; row++) {
      sendDrumPatternToDSP(row, &payload[row * 16]);
      delay(3); // small gap between rows so DSP UART buffer doesn't overflow
    }
    break;
  }
  case 0x41:
  { // Drum + Looper config (DRUM packet — 12 bytes to DSP)
    if (payloadLen != 12)break;
    uint8_t dspP[12];memcpy(dspP,payload,sizeof(dspP));
    Serial.printf("[BLE] 0x41 DRUM: en=%d lvl=%d bpm=%d style=%d fill=%d num=%d"
                  " | LOOP: en=%d lvl=%d sync=%d arm=%d bars=%d track=%d\n",
                  dspP[0], dspP[1], dspP[2], dspP[3], dspP[4], dspP[5],
                  dspP[6], dspP[7], dspP[8], dspP[9], dspP[10], dspP[11]);
    // UART send is mutex-protected — safe from BLE task
    sendDataRobust("DRUM", dspP, 12);
    // Defer display state update + screen switch to loop() to avoid TFT SPI contention
    memcpy(s_drumCmdPayload,"DRUM",4);memcpy(s_drumCmdPayload+4,payload,12);
    s_pendingDrumCmd = true;
    break;
  }
  case 0x42:
  { // Looper button/config → "LOOP" packet (new update_param byte map, 16 bytes)
    if (payloadLen < 16)
      break;
    Serial.printf("[BLE] 0x42 LOOP: track=%d rec=%d stop=%d clear=%d undo=%d"
                  " sync=%d play=%d bars=%d arm=%d bounce=%d mute=%d solo=%d lvl=%d\n",
                  payload[0], payload[1], payload[2], payload[3], payload[4],
                  payload[8], payload[9], payload[10], payload[11],
                  payload[12], payload[13], payload[14], payload[15]);
    // Safety for an older webapp: enable DSP looper before the REC frame
    // without overwriting drum enable, BPM, or sequencer phase.
    if (payload[1])
    {
      // Idempotent; avoids reading or mutating display state on the BLE task.
      const uint8_t ctl[4] = {1, 9, 1, 0};
      sendDataRobust("TCTL", ctl, sizeof(ctl));
    }
    // UART send is mutex-protected — safe from BLE task
    sendDataRobust("LOOP", payload, 16);
    // Release one-shot button bits explicitly (same semantics as local UI).
    // Do not overwrite payload: it is needed below for the display update.
    bool oneShot = false;
    for (int i = 1; i <= 7; ++i) oneShot |= payload[i] != 0;
    if (oneShot)
    {
      uint8_t released[16];
      memcpy(released, payload, 16);
      memset(released + 1, 0, 7);
      sendDataRobust("LOOP", released, 16);
    }
    // Defer display state update + screen redraw to loop() to avoid TFT SPI contention
    // with updateLooperVisuals() running concurrently on the main task.
    memcpy(s_loopCmdPayload, payload, 16);
    s_pendingLoopCmd = true;
    break;
  }
  case 0x47:
  { // Independent Looper Enable from webapp; does NOT restart/disable drums.
    if (payloadLen < 1) break;
    const bool enabled = payload[0] != 0;
    const uint8_t ctl[4] = {1, 9, static_cast<uint8_t>(enabled), 0};
    sendDataRobust("TCTL", ctl, sizeof(ctl));
    s_pendingLooperEnable = enabled ? 1 : 0;
    Serial.printf("[BLE] Looper enable %u\n", (unsigned)enabled);
    break;
  }
  case 0x43:
  { // USB mode → "USBM" packet to DSP
    // payload[0]: 0=off  1=serial(default)  2=audio  3=MIDI-host(reserved)
    if (payloadLen < 1)
      break;
    Serial.printf("[BLE] 0x43 USBM: mode=%d\n", payload[0]);
    {
      static const char *usbNames[] = {"USB Off", "USB Serial", "USB Audio", "USB MIDI"};
      display.showMessage(payload[0] < 4 ? usbNames[payload[0]] : "USB ???");
    }
    s_webUsbMode=payload[0];
    sendDataRobust("USBM", payload, 1);
    break;
  }
  case 0x44:
  { // UART on/off — enable or disable the DSP serial link
    // payload[0]: 0=off  1=on
    if (payloadLen < 1)
      break;
    bool enable = payload[0] > 0;
    if (enable && !dspSerialOn)
    {
      dspSerial.begin(1000000, SERIAL_8N1, DSP_RX_PIN, DSP_TX_PIN);
      dspSerialOn = true;
      display.showMessage("UART On");
      Serial.println("[BLE] 0x44 UART re-enabled");
    }
    else if (!enable && dspSerialOn)
    {
      dspSerial.end();
      dspSerialOn = false;
      display.showMessage("UART Off");
      Serial.println("[BLE] 0x44 UART disabled");
    }
    break;
  }
  case 0x60:
  { // Flash DSP — enter bootloader, UART stays closed until power cycle
    Serial.println("[BLE] Processing FLASH command...");
    display.showMessage("Flashing DSP...");
    uint8_t dummy = 0;
    sendToDSP("FLSH", &dummy, 0);
    delay(200);
    dspSerial.end();
    dspSerialOn = false;
    break;
  }
  case 0x61:
  { // Reset DSP — close UART and re-trigger auto-detection so preset is resent on reconnect
    Serial.println("[BLE] Processing RESET command...");
    display.showMessage("DSP Reset...");
    uint8_t dummy = 0;
    sendToDSP("RSTD", &dummy, 0);
    delay(200);
    dspSerial.end();
    dspSerialOn = false;
    checkUART = true;
    uartStartTime = 0;
    lastUartAttempt = 0;
    break;
  }
  case 0x62:
  { // Scan MIDI BLE
    Serial.println("[BLE] Received MIDI Scan Request.");
    btManager.triggerMidiConnectionAttempt();
    break;
  }
  case 0x63:
  { // Read SD
    Serial.println("[BLE] Processing ReadSD command...");
    char header[] = "REQL";
    uint8_t dummy = 0;
    sendToDSP(header, &dummy, 0);
    btManager.triggerMidiConnectionAttempt();
    break;
  }
  case 0x52: receiveWebConfig(payload,payloadLen); break;
  case 0x70:
  { // NAM START — metadata for browser-parsed float32 NAM weights.
    if (s_jm2NamPending || s_jm2NamFlight.active)
    {
      Serial.println("[NAM] START rejected: DSP stream busy");
      sendNamAck(0x71, 6);
      break;
    }

    // Standard webapp format after [cmd][payloadLen16LE]:
    //   uint32 weightCount, uint32 crc32(weight bytes), uint16 nameLen, uint8[nameLen] name
    const uint8_t *meta = payload;
    size_t metaLen = payloadLen;

    if (!meta || metaLen < 10) { sendNamAck(0x71, 1); break; }

    uint32_t weightCount = 0;
    uint32_t expectedCrc = 0;
    memcpy(&weightCount, meta + 0, 4);
    memcpy(&expectedCrc, meta + 4, 4);

    if (weightCount != 1871u) {
      Serial.printf("[NAM] START rejected weightCount=%u (expected 1871 for NAM A2 Lite)\n", weightCount);
      sendNamAck(0x71, 3);
      break;
    }

    uint32_t expectedBytes = weightCount * 4UL;

    uint16_t nameLen = 0;
    size_t nameOffset = 0;
    if (metaLen >= 10) {
      nameLen = (uint16_t)meta[8] | ((uint16_t)meta[9] << 8);
      nameOffset = 10;
      if (nameOffset + nameLen > metaLen) {
        Serial.printf("[NAM] START bad nameLen=%u metaLen=%u\n", nameLen, (unsigned)metaLen);
        sendNamAck(0x71, 2);
        break;
      }
    } else {
      nameOffset = 8;
      nameLen = (uint16_t)(metaLen - nameOffset);
    }

    memset(s_namModelName, 0, sizeof(s_namModelName));
    size_t copyLen = nameLen;
    if (copyLen >= sizeof(s_namModelName)) copyLen = sizeof(s_namModelName) - 1;
    if (copyLen > 0) memcpy(s_namModelName, meta + nameOffset, copyLen);

    s_namTransferActive = true;
    s_namExpectedWeights = weightCount;
    s_namExpectedBytes = expectedBytes;
    s_namReceivedBytes = 0;
    s_namExpectedCrc = expectedCrc;
    s_namRunningCrc = 0xFFFFFFFF;
    s_namExpectedChunk = 0;
    s_namDspChunkIndex = 0;
    s_namWeightOffset  = 0;

    // Build a canonical DSP NAMH: count + CRC + capped nameLen + name.
    // Never snapshot/truncate raw metadata while keeping an incompatible nameLen.
    const uint16_t dspNameLen = (uint16_t)copyLen;
    s_namMetaSnapshot[0] = (uint8_t)(weightCount & 0xFF);
    s_namMetaSnapshot[1] = (uint8_t)((weightCount >> 8) & 0xFF);
    s_namMetaSnapshot[2] = (uint8_t)((weightCount >> 16) & 0xFF);
    s_namMetaSnapshot[3] = (uint8_t)((weightCount >> 24) & 0xFF);
    s_namMetaSnapshot[4] = (uint8_t)(expectedCrc & 0xFF);
    s_namMetaSnapshot[5] = (uint8_t)((expectedCrc >> 8) & 0xFF);
    s_namMetaSnapshot[6] = (uint8_t)((expectedCrc >> 16) & 0xFF);
    s_namMetaSnapshot[7] = (uint8_t)((expectedCrc >> 24) & 0xFF);
    s_namMetaSnapshot[8] = (uint8_t)(dspNameLen & 0xFF);
    s_namMetaSnapshot[9] = (uint8_t)(dspNameLen >> 8);
    if (dspNameLen) memcpy(s_namMetaSnapshot + 10, s_namModelName, dspNameLen);
    s_namMetaSnapshotLen = 10u + dspNameLen;

    Serial.printf("[NAM] START name=%s weights=%u bytes=%u crc=%08X\n",
                  s_namModelName, s_namExpectedWeights, s_namExpectedBytes, s_namExpectedCrc);

    sendNamAck(0x71, 0);
    break;
  }
  case 0x72:
  { // NAM DATA — chunked raw little-endian float32 weight bytes.
    const uint8_t *chunkData = nullptr;
    size_t chunkLen = 0;
    uint16_t chunkIndex = s_namExpectedChunk;

    if (!s_namTransferActive) {
      Serial.println("[NAM] CHUNK received before START");
      sendNamAck(0x73, 1, chunkIndex);
      break;
    }

    if (payload) {
      // Standard webapp format after [cmd][payloadLen16LE]:
      //   uint16 chunkIndex, uint8[N] raw float32 weight bytes
      if (payloadLen < 2) {
        Serial.printf("[NAM] CHUNK invalid payloadLen=%u\n", (unsigned)payloadLen);
        sendNamAck(0x73, 2, chunkIndex);
        break;
      }
      chunkIndex = (uint16_t)payload[0] | ((uint16_t)payload[1] << 8);
      chunkData = payload + 2;
      chunkLen = payloadLen - 2;
    }

    // Duplicate retry: webapp may resend a chunk if the previous ACK was lost.
    // Re-ACK it but do not count/CRC/forward the data twice.
    if (s_namExpectedChunk > 0 && chunkIndex == (uint16_t)(s_namExpectedChunk - 1)) {
      Serial.printf("[NAM] CHUNK duplicate %u re-ACK\n", chunkIndex);
      sendNamAck(0x73, 0, chunkIndex);
      break;
    }

    if (chunkIndex != s_namExpectedChunk) {
      Serial.printf("[NAM] CHUNK index mismatch got=%u expected=%u\n", chunkIndex, s_namExpectedChunk);
      sendNamAck(0x73, 3, s_namExpectedChunk);
      break;
    }

    if (s_namReceivedBytes + chunkLen > s_namExpectedBytes) {
      Serial.printf("[NAM] CHUNK overflow received=%u chunk=%u expected=%u\n",
                    s_namReceivedBytes, (unsigned)chunkLen, s_namExpectedBytes);
      sendNamAck(0x73, 4, chunkIndex);
      break;
    }

    s_namRunningCrc = crc32_update_buffer(s_namRunningCrc, chunkData, chunkLen);
    s_namReceivedBytes += chunkLen;
    s_namExpectedChunk++;

    Serial.printf("[NAM] CHUNK %u bytes=%u total=%u/%u\n",
                  chunkIndex, (unsigned)chunkLen, s_namReceivedBytes, s_namExpectedBytes);

    // ACK before UART forwarding so DSP/UART backpressure cannot block BLE flow control.
    sendNamAck(0x73, 0, chunkIndex);

    // Accumulate into buffer — DSP blast happens all at once in the END handler
    // to avoid multi-second BLE gaps causing the DSP stream timeout.
    if (chunkLen > 0 && s_namWeightOffset + chunkLen <= sizeof(s_namWeightBuffer)) {
      memcpy(s_namWeightBuffer + s_namWeightOffset, chunkData, chunkLen);
      s_namWeightOffset += chunkLen;
    }
    break;
  }
  case 0x74:
  { // NAM END — verify byte count and CRC, then ACK the webapp.
    if (!s_namTransferActive) {
      Serial.println("[NAM] END received without active transfer");
      sendNamAck(0x76, 1);
      break;
    }

    uint32_t finalCrc = s_namRunningCrc ^ 0xFFFFFFFFUL;
    uint8_t status = 0;
    char statusMsg[64];

    if (s_namReceivedBytes != s_namExpectedBytes) {
      Serial.printf("[NAM] END byte mismatch received=%u expected=%u\n",
                    s_namReceivedBytes, s_namExpectedBytes);
      status = 2;
      snprintf(statusMsg, sizeof(statusMsg), "NAM Error (Size): %s", s_namModelName);
    } else if (finalCrc != s_namExpectedCrc) {
      Serial.printf("[NAM] END CRC mismatch got=%08X expected=%08X\n", finalCrc, s_namExpectedCrc);
      status = 3;
      snprintf(statusMsg, sizeof(statusMsg), "NAM Error (CRC): %s", s_namModelName);
    } else {
      Serial.printf("[NAM] END OK name=%s weights=%u bytes=%u crc=%08X\n",
                    s_namModelName, s_namExpectedWeights, s_namReceivedBytes, finalCrc);

      // Once this peer has demonstrated JMP2, bulk NAM transfer is always
      // deferred to loop() and sent through the generic SBEG/SDAT/SEND layer.
      // Keep the existing BLE END ACK pending until DSP SEND commits.
      if (s_jm2Connected || s_jm2EverConnected)
      {
        if (s_jm2NamPending || s_jm2NamFlight.active)
        {
          status = 6;
          snprintf(statusMsg, sizeof(statusMsg), "NAM DSP busy: %s", s_namModelName);
        }
        else
        {
          s_namTransferActive = false;
          __sync_synchronize();
          s_jm2NamPending = true;
          Serial.printf("[JM2] NAM queued name=%s bytes=%u\n",
                        s_namModelName, s_namExpectedBytes);
          display.showMessage("NAM Sending...");
          break; // final BLE 0x76 ACK is sent after JMP2 SEND commit
        }
      }
      else
      {
        // Backward-compatible fallback for a DSP that has never negotiated JMP2.
        // Send NAMH → all NAMW chunks → NAME using the legacy ACK-gated path.
        s_namDspChunkIndex = 0;
        bool dspOk = sendNamPacketAndWait("NAMH", s_namMetaSnapshot, s_namMetaSnapshotLen, 0, 0);
      if (dspOk)
        dspOk = forwardNamWeightsToDsp(s_namWeightBuffer, s_namWeightOffset);

      uint8_t endMeta[12];
      memcpy(endMeta + 0, &s_namExpectedWeights, 4);
      memcpy(endMeta + 4, &s_namReceivedBytes, 4);
      memcpy(endMeta + 8, &finalCrc, 4);
      if (dspOk)
        dspOk = sendNamPacketAndWait("NAME", endMeta, sizeof(endMeta), 2, 0xFFFF, 1500);

      if (dspOk)
        snprintf(statusMsg, sizeof(statusMsg), "NAM Loaded: %s", s_namModelName);
      else
      {
        status = 5;
        snprintf(statusMsg, sizeof(statusMsg), "NAM DSP transfer failed: %s", s_namModelName);
        Serial.println("[NAM] DSP transfer aborted; retry full model");
      }
      } // legacy fallback
    }

    display.showMessage(statusMsg);
    s_namTransferActive = false;
    sendNamAck(0x76, status);
    break;
  }
  case 0x75:
  { // NAM EJECT
    Serial.println("[NAM] EJECT");
    s_namTransferActive = false;
    sendDataRobust("NMEJ", nullptr, 0);
    break;
  }

  // ------------------------------------------------------------------
  // 0x80  MIDI_UPLOAD_START  [fileSize32LE][nameLen8][name]
  // ------------------------------------------------------------------
  case 0x80:
  {
    if (!payload || payloadLen < 5) {
      Serial.printf("[MIDI] START invalid payloadLen=%u\n", (unsigned)payloadLen);
      break;
    }

    uint32_t fileSize = 0;
    memcpy(&fileSize, payload, 4);
    uint8_t nameLen = payload[4];
    if ((size_t)(5 + nameLen) > payloadLen) {
      Serial.printf("[MIDI] START bad nameLen=%u\n", nameLen);
      break;
    }

    if (fileSize == 0 || fileSize > MIDI_MAX_FILE_BYTES) {
      Serial.printf("[MIDI] START rejected fileSize=%u (max %u)\n",
                    (unsigned)fileSize, (unsigned)MIDI_MAX_FILE_BYTES);
      break;
    }

    // Abort any previous transfer and free its buffer.
    if (s_midiBuffer) { free(s_midiBuffer); s_midiBuffer = nullptr; }
    s_midiTransferActive = false;

    s_midiBufferCapacity = fileSize;

    memset(s_midiFileName, 0, sizeof(s_midiFileName));
    size_t cp = (nameLen < sizeof(s_midiFileName) - 1) ? nameLen : sizeof(s_midiFileName) - 1;
    if (cp) memcpy(s_midiFileName, payload + 5, cp);

    s_midiExpectedBytes  = fileSize;
    s_midiReceivedBytes  = 0;
    s_midiExpectedChunk  = 0;
    s_midiSubIndex       = 0;
    s_midiTransferActive = true;

    Serial.printf("[MIDI] START name=%s size=%u\n", s_midiFileName, (unsigned)fileSize);

    // Forward metadata to DSP so it can pre-allocate SDRAM.
    // MBEG payload: [fileSize32LE][nameLen8][name]
    uint8_t mbeg[5 + 64];
    memcpy(mbeg, &fileSize, 4);
    mbeg[4] = (uint8_t)cp;
    if (cp) memcpy(mbeg + 5, s_midiFileName, cp);
    sendDataRobust("MBEG", mbeg, 5 + cp);
    break;
  }

  // ------------------------------------------------------------------
  // 0x81  MIDI_UPLOAD_CHUNK  [chunkIdx16LE][data...]
  // ------------------------------------------------------------------
  case 0x81:
  {
    if (!s_midiTransferActive) {
      Serial.println("[MIDI] CHUNK received before START");
      break;
    }
    if (!payload || payloadLen < 3) {
      Serial.printf("[MIDI] CHUNK invalid payloadLen=%u\n", (unsigned)payloadLen);
      break;
    }

    uint16_t chunkIdx = (uint16_t)payload[0] | ((uint16_t)payload[1] << 8);
    const uint8_t *chunkData = payload + 2;
    size_t chunkLen = payloadLen - 2;

    // Tolerate duplicate (re-sent by webapp after no ACK).
    if (s_midiExpectedChunk > 0 && chunkIdx == (uint16_t)(s_midiExpectedChunk - 1)) {
      Serial.printf("[MIDI] CHUNK duplicate %u — re-ACK only\n", chunkIdx);
      break;
    }
    if (chunkIdx != s_midiExpectedChunk) {
      Serial.printf("[MIDI] CHUNK index mismatch got=%u expected=%u\n",
                    chunkIdx, s_midiExpectedChunk);
      break;
    }
    if (s_midiReceivedBytes + chunkLen > s_midiBufferCapacity) {
      Serial.printf("[MIDI] CHUNK overflow received=%u chunk=%u cap=%u\n",
                    s_midiReceivedBytes, (unsigned)chunkLen,
                    (unsigned)s_midiBufferCapacity);
      break;
    }

    s_midiReceivedBytes += chunkLen;
    s_midiExpectedChunk++;

    Serial.printf("[MIDI] CHUNK %u len=%u total=%u/%u\n",
                  chunkIdx, (unsigned)chunkLen,
                  s_midiReceivedBytes, s_midiExpectedBytes);

    // Sub-chunk into MSUB packets the DSP reassembles into SDRAM.
    // MSUB payload: [subIdx u16 LE][12 data bytes] = 14 bytes.
    static constexpr size_t MSUB_DATA = 12;
    uint8_t msub[14]; // 2 (subIdx) + 12 (data) = 14 bytes payload
    size_t sent = 0;
    while (sent < chunkLen) {
      size_t n = (chunkLen - sent < MSUB_DATA) ? (chunkLen - sent) : MSUB_DATA;
      msub[0] = s_midiSubIndex & 0xFF;
      msub[1] = (s_midiSubIndex >> 8) & 0xFF;
      memcpy(msub + 2, chunkData + sent, n);
      if (n < MSUB_DATA) memset(msub + 2 + n, 0, MSUB_DATA - n); // zero-pad last sub-pkt
      sendDataRobust("MSUB", msub, sizeof(msub));
      s_midiSubIndex++;
      sent += n;
    }
    break;
  }

  // ------------------------------------------------------------------
  // 0x82  MIDI_UPLOAD_END
  // ------------------------------------------------------------------
  case 0x82:
  {
    if (!s_midiTransferActive) {
      Serial.println("[MIDI] END received without active transfer");
      break;
    }

    Serial.printf("[MIDI] END name=%s bytes=%u/%u\n",
                  s_midiFileName, s_midiReceivedBytes, s_midiExpectedBytes);

    // Signal DSP to commit SDRAM buffer and optionally write to SD.
    // MEND payload: [totalBytes32LE]
    uint8_t mend[4];
    memcpy(mend, &s_midiReceivedBytes, 4);
    sendDataRobust("MEND", mend, sizeof(mend));

    display.showMessage(s_midiFileName[0] ? s_midiFileName : "MIDI loaded");

    // Release heap buffer — DSP now owns the data.
    if (s_midiBuffer) { free(s_midiBuffer); s_midiBuffer = nullptr; }
    s_midiBufferCapacity = 0;
    s_midiTransferActive = false;
    break;
  }

  }
}


// ============================================================================
// JAMMATE PROTOCOL V2 FOUNDATION
// ============================================================================
static bool sendJm2(uint32_t       type,
                    uint8_t        flags,
                    uint16_t       transaction,
                    uint16_t       sequence,
                    const uint8_t* payload,
                    uint16_t       payload_len)
{
  // v6 supports a 128-byte stream chunk plus its 8-byte SDAT header.
  // All calls still originate from loop() for reliable traffic, so this local
  // frame has a well-defined lifetime through synchronous sendPacket().
  static constexpr size_t JM2_MAX_APP_PAYLOAD
      = sizeof(Jm2StreamDataHeader) + JM2_STREAM_CHUNK_BYTES;
  uint8_t envelope[sizeof(Jm2Header) + JM2_MAX_APP_PAYLOAD];
  if (payload_len > JM2_MAX_APP_PAYLOAD)
    return false;

  size_t n = jm2_build(envelope,
                       sizeof(envelope),
                       type,
                       flags,
                       transaction,
                       sequence,
                       payload,
                       payload_len);
  if (n == 0)
    return false;

  sendPacket("JMP2", envelope, n);
  return true;
}

void sendJm2Hello()
{
  Jm2HelloPayload hello{};
  hello.max_payload   = 512;
  hello.stream_chunk  = JM2_STREAM_CHUNK_BYTES;
  hello.stream_window = 1;
  hello.capabilities  = JM2_CAP_EFFECTS | JM2_CAP_PRESETS
                      | JM2_CAP_NAM | JM2_CAP_IR | JM2_CAP_TUNER;

  s_jm2HelloTransaction = s_jm2NextTransaction++;
  if (s_jm2NextTransaction == 0)
    s_jm2NextTransaction = 1;

  if (sendJm2(JM2_HELO,
              JM2_F_RELIABLE,
              s_jm2HelloTransaction,
              0,
              (const uint8_t*)&hello,
              sizeof(hello)))
  {
    s_jm2HelloSent   = true;
    s_jm2LastHelloMs = millis();
    Serial.printf("[JM2] HELO tx=%u\n", s_jm2HelloTransaction);
  }
}

void processJm2Packet(const uint8_t* data, size_t len)
{
  Jm2PacketView pkt{};
  if (!jm2_parse(data, len, &pkt))
  {
    s_jm2BadPackets++;
    Serial.println("[JM2] malformed packet");
    return;
  }

  s_jm2RxPackets++;

  if (pkt.header->type == JM2_HELA)
  {
    if (pkt.header->transaction != s_jm2HelloTransaction)
    {
      Serial.printf("[JM2] stale HELA tx=%u expected=%u\n",
                    pkt.header->transaction,
                    s_jm2HelloTransaction);
      return;
    }

    s_jm2Connected = true;
    s_jm2EverConnected = true;
    if (pkt.header->payload_len == sizeof(Jm2HelloPayload))
    {
      Jm2HelloPayload peer{};
      memcpy(&peer, pkt.payload, sizeof(peer));
      s_jm2PeerCaps=peer.capabilities;
      Serial.printf("[JM2] connected max=%u chunk=%u window=%u caps=0x%08lX\n",
                    peer.max_payload,
                    peer.stream_chunk,
                    peer.stream_window,
                    (unsigned long)peer.capabilities);
    }
    else
    {
      Serial.println("[JM2] connected");
    }
  }
  else if (pkt.header->type == JM2_PONG)
  {
    Serial.printf("[JM2] PONG tx=%u seq=%u\n",
                  pkt.header->transaction,
                  pkt.header->sequence);
  }
  else if (pkt.header->type == JM2_FREQ && pkt.header->payload_len == sizeof(float))
  {
    float freq;
    memcpy(&freq, pkt.payload, sizeof(freq));
    Serial.println(freq);

    static uint32_t lastFreqBLESend = 0;
    if (millis() - lastFreqBLESend >= 500)
    {
      lastFreqBLESend = millis();
      uint8_t packet[7];
      packet[0] = 0x35;
      packet[1] = 4;
      packet[2] = 0;
      memcpy(&packet[3], pkt.payload, 4);
      btManager.sendBLEData(packet, 7);
    }

    if (display.isTunerActive())
      display.updateTuner(freq);
  }
  else if (pkt.header->type == JM2_LOAD && pkt.header->payload_len == sizeof(float))
  {
    float load;
    memcpy(&load, pkt.payload, sizeof(load));
    s_cpuTelemetry.sample(load);
    Serial.printf("[JM2] DSP Load: %.1f%%\n", load);

    char statusMsg[32];
    snprintf(statusMsg, sizeof(statusMsg), "CPU: %.1f%%", load);
    display.updateStatusLine(statusMsg);
    if (pendingLoadDisplay)
    {
      pendingLoadDisplay = false;
      display.showMessage(statusMsg);
    }
  }
  else if (pkt.header->type == JM2_ACK)
  {
    if (s_jm2NamFlight.active
        && pkt.header->transaction == s_jm2NamFlight.transaction
        && pkt.header->sequence == s_jm2NamFlight.sequence)
    {
      s_jm2NamFlight.acked = true;
      if (pkt.header->payload_len == sizeof(Jm2StreamAckPayload))
      {
        Jm2StreamAckPayload ack{};
        memcpy(&ack, pkt.payload, sizeof(ack));
        s_jm2NamFlight.reply_valid = true;
        s_jm2NamFlight.reply_next_sequence = ack.next_sequence;
        s_jm2NamFlight.reply_received_bytes = ack.received_bytes;
        s_jm2NamFlight.reply_reason = ack.reserved;
        Serial.printf("[JM2] STREAM ACK tx=%u seq=%u next=%u bytes=%lu\n",
                      pkt.header->transaction, pkt.header->sequence,
                      ack.next_sequence, (unsigned long)ack.received_bytes);
      }
    }
    else if (s_jm2PresetFlight.active
        && pkt.header->transaction == s_jm2PresetFlight.transaction
        && pkt.header->sequence == s_jm2PresetFlight.sequence)
    {
      s_jm2PresetFlight.acked = true;
      Serial.printf("[JM2] PRESET ACK tx=%u seq=%u\n",
                    pkt.header->transaction, pkt.header->sequence);
    }
    else if (s_jm2EffectFlight.active
        && pkt.header->transaction == s_jm2EffectFlight.transaction
        && pkt.header->sequence == s_jm2EffectFlight.sequence)
      s_jm2EffectFlight.acked = true;
  }
  else if (pkt.header->type == JM2_NACK)
  {
    if (s_jm2NamFlight.active
        && pkt.header->transaction == s_jm2NamFlight.transaction
        && pkt.header->sequence == s_jm2NamFlight.sequence)
    {
      s_jm2NamFlight.nacked = true;
      if (pkt.header->payload_len == sizeof(Jm2StreamAckPayload))
      {
        Jm2StreamAckPayload nack{};
        memcpy(&nack, pkt.payload, sizeof(nack));
        s_jm2NamFlight.reply_valid = true;
        s_jm2NamFlight.reply_next_sequence = nack.next_sequence;
        s_jm2NamFlight.reply_received_bytes = nack.received_bytes;
        s_jm2NamFlight.reply_reason = nack.reserved;
        Serial.printf("[JM2] STREAM NACK tx=%u seq=%u reason=%u next=%u bytes=%lu\n",
                      pkt.header->transaction, pkt.header->sequence,
                      nack.reserved, nack.next_sequence,
                      (unsigned long)nack.received_bytes);
      }
      else
      {
        Serial.printf("[JM2] NACK tx=%u seq=%u\n",
                      pkt.header->transaction, pkt.header->sequence);
      }
    }
    else if (s_jm2PresetFlight.active
        && pkt.header->transaction == s_jm2PresetFlight.transaction
        && pkt.header->sequence == s_jm2PresetFlight.sequence)
      s_jm2PresetFlight.nacked = true;
    else if (s_jm2EffectFlight.active
        && pkt.header->transaction == s_jm2EffectFlight.transaction
        && pkt.header->sequence == s_jm2EffectFlight.sequence)
      s_jm2EffectFlight.nacked = true;
  }
}

// ============================================================================
// PACKET / PROTOCOL LAYER
// ============================================================================
void sendPacket(const char *header_str, const uint8_t *payload, size_t len)
{
  if (s_dspMutex) xSemaphoreTake(s_dspMutex, portMAX_DELAY);

  uint32_t type = 0;
  memcpy(&type, header_str, 4);

  size_t raw_len = sizeof(PacketHeader) + len;
  uint8_t raw_buf[raw_len];
  prepare_packet(raw_buf, type, payload, len);

  size_t max_encoded_len = raw_len + (raw_len / 254) + 2;
  uint8_t encoded_buf[max_encoded_len];
  size_t encoded_len = cobs_encode(raw_buf, raw_len, encoded_buf);

  // Wait for DSP READY. During NAM blast the DSP may briefly de-assert READY
  // (reset/brownout). Allow up to 5 s and log so we know it happened.
  unsigned long start = millis();
  bool ready_warned = false;
  while (digitalRead(DAISY_READY_PIN) == LOW)
  {
    unsigned long waited = millis() - start;
    if (!ready_warned && waited > 50)
    {
      ready_warned = true;
      Serial.printf("[ESP] READY pin LOW for %s — waiting (DSP reset?)\n", header_str);
    }
    if (waited > 5000)
    {
      Serial.printf("[ESP] READY timeout after 5s for %s — dropping packet\n", header_str);
      if (s_dspMutex) xSemaphoreGive(s_dspMutex);
      return;
    }
    delay(1);
  }

  dspSerial.write(COBS_DELIMITER);
  dspSerial.write(encoded_buf, encoded_len);
  dspSerial.write(COBS_DELIMITER);
  // Ensure the complete frame has physically left UART before another task/frame
  // can reuse transport state. Existing inter-packet delays now represent real idle time.
  dspSerial.flush();

  Serial.printf("[ESP] Sent packet: %s (%d bytes)\n", header_str, encoded_len);

  if (s_dspMutex) xSemaphoreGive(s_dspMutex);
}

void sendToDSP(const char cmd[4], uint8_t *payload, size_t len)
{
  sendPacket(cmd, payload, len);
}

void sendDataRobust(const char *header, const uint8_t *payload, size_t len)
{
  sendPacket(header, payload, len);
}

void sendEffectChangeLegacyToDSP(uint8_t idx, uint8_t en, const uint8_t *k, const uint8_t *d)
{
  const char *name = (idx < MAX_EFFECTS) ? EFFECT_NAMES[idx] : "GEN ";
  uint8_t kCount = (idx < MAX_EFFECTS) ? FX_LAYOUT[idx][0] : 0;
  uint8_t dCount = (idx < MAX_EFFECTS) ? FX_LAYOUT[idx][1] : 0;

  uint8_t payload[32];
  if (1u + kCount + dCount > sizeof(payload)) {
    Serial.printf("[DSP] FX[%d] layout overflow k=%d d=%d — skipping\n", idx, kCount, dCount);
    return;
  }
  int offset = 0;
  payload[offset++] = en ? 1 : 0;
  if (k)
    for (int i = 0; i < kCount; i++)
      payload[offset++] = k[i];
  if (d)
    for (int i = 0; i < dCount; i++)
      payload[offset++] = d[i];

  {
    char dbg[256];
    int n = snprintf(dbg, sizeof(dbg), "EFFT %.4s,%d", name, en ? 1 : 0);
    if (k)
      for (int i = 0; i < kCount && n < (int)sizeof(dbg) - 6; i++)
        n += snprintf(dbg + n, sizeof(dbg) - n, ",%d", k[i]);
    if (d)
      for (int i = 0; i < dCount && n < (int)sizeof(dbg) - 6; i++)
        n += snprintf(dbg + n, sizeof(dbg) - n, ",%d", d[i]);
    Serial.println(dbg);
  }

  sendPacket(name, payload, offset);
}


void sendEffectChangeToDSP(uint8_t idx, uint8_t en, const uint8_t *k, const uint8_t *d)
{
  if (!s_jm2Connected || idx >= MAX_EFFECTS)
  {
    sendEffectChangeLegacyToDSP(idx, en, k, d);
    return;
  }

  const char *name = EFFECT_NAMES[idx];
  const uint8_t kCount = FX_LAYOUT[idx][0];
  const uint8_t dCount = FX_LAYOUT[idx][1];
  const size_t total = 4u + 1u + kCount + dCount;
  if (total > JM2_EFFECT_MAX_BYTES)
  {
    Serial.printf("[JM2] FX[%u] payload too large: %u\n", idx, (unsigned)total);
    return;
  }

  uint8_t frame[JM2_EFFECT_MAX_BYTES];
  memcpy(frame, name, 4);
  size_t offset = 4;
  frame[offset++] = en ? 1 : 0;
  if (k) for (uint8_t i = 0; i < kCount; ++i) frame[offset++] = k[i];
  if (d) for (uint8_t i = 0; i < dCount; ++i) frame[offset++] = d[i];

  {
    char dbg[256];
    int n = snprintf(dbg, sizeof(dbg), "EFFT %.4s,%d", name, en ? 1 : 0);
    if (k)
      for (uint8_t i = 0; i < kCount && n < (int)sizeof(dbg) - 6; ++i)
        n += snprintf(dbg + n, sizeof(dbg) - n, ",%d", k[i]);
    if (d)
      for (uint8_t i = 0; i < dCount && n < (int)sizeof(dbg) - 6; ++i)
        n += snprintf(dbg + n, sizeof(dbg) - n, ",%d", d[i]);
    Serial.println(dbg);
  }

  // Mailbox semantics: while an effect is waiting to transmit, keep only its
  // newest complete state. This bounds knob-drag traffic without losing final state.
  portENTER_CRITICAL(&s_jm2EffectMux);
  s_jm2EffectMailbox[idx].len = (uint16_t)offset;
  memcpy(s_jm2EffectMailbox[idx].bytes, frame, offset);
  s_jm2EffectMailbox[idx].pending = true;
  portEXIT_CRITICAL(&s_jm2EffectMux);
}

void serviceJm2ReliableEffects()
{
  if (!s_jm2Connected) return;
  const uint32_t now = millis();

  if (s_jm2EffectFlight.active)
  {
    if (s_jm2EffectFlight.acked)
    {
      Serial.printf("[JM2] EFFT ACK tx=%u retries=%u\n",
                    s_jm2EffectFlight.transaction, s_jm2EffectFlight.retries);
      s_jm2EffectFlight = {};
    }
    else
    {
      const bool retryNow = s_jm2EffectFlight.nacked
                         || (uint32_t)(now - s_jm2EffectFlight.sent_ms) >= JM2_EFFECT_ACK_TIMEOUT_MS;
      if (!retryNow) return;

      if (s_jm2EffectFlight.retries >= JM2_EFFECT_MAX_RETRIES)
      {
        Serial.printf("[JM2] EFFT failed tx=%u; reconnecting protocol\n",
                      s_jm2EffectFlight.transaction);
        s_jm2EffectFlight = {};
        s_jm2Connected = false;
        s_jm2HelloSent = false;
        return;
      }

      s_jm2EffectFlight.retries++;
      s_jm2EffectFlight.nacked = false;
      if (sendJm2(JM2_EFFT, JM2_F_RELIABLE,
                  s_jm2EffectFlight.transaction, s_jm2EffectFlight.sequence,
                  s_jm2EffectFlight.bytes, s_jm2EffectFlight.len))
      {
        s_jm2EffectFlight.sent_ms = millis();
        Serial.printf("[JM2] EFFT retry tx=%u attempt=%u\n",
                      s_jm2EffectFlight.transaction, s_jm2EffectFlight.retries);
      }
      return;
    }
  }

  // Finish an already in-flight effect before yielding to a newly queued
  // preset/NAM transaction. Do not start a new effect while either is pending.
  if (s_jm2PresetFlight.active || s_jm2PresetPending
      || s_jm2NamFlight.active || s_jm2NamPending) return;

  uint8_t chosen = 0xFF;
  uint16_t len = 0;
  uint8_t bytes[JM2_EFFECT_MAX_BYTES];
  portENTER_CRITICAL(&s_jm2EffectMux);
  for (uint8_t n = 0; n < MAX_EFFECTS; ++n)
  {
    const uint8_t idx = (uint8_t)((s_jm2EffectScan + n) % MAX_EFFECTS);
    if (s_jm2EffectMailbox[idx].pending)
    {
      chosen = idx;
      len = s_jm2EffectMailbox[idx].len;
      memcpy(bytes, s_jm2EffectMailbox[idx].bytes, len);
      s_jm2EffectMailbox[idx].pending = false;
      s_jm2EffectScan = (uint8_t)((idx + 1) % MAX_EFFECTS);
      break;
    }
  }
  portEXIT_CRITICAL(&s_jm2EffectMux);
  if (chosen == 0xFF) return;

  uint16_t tx = s_jm2NextTransaction++;
  if (s_jm2NextTransaction == 0) s_jm2NextTransaction = 1;

  s_jm2EffectFlight = {};
  s_jm2EffectFlight.active = true;
  s_jm2EffectFlight.transaction = tx;
  s_jm2EffectFlight.sequence = 0;
  s_jm2EffectFlight.len = len;
  memcpy(s_jm2EffectFlight.bytes, bytes, len);

  if (sendJm2(JM2_EFFT, JM2_F_RELIABLE, tx, 0, bytes, len))
  {
    s_jm2EffectFlight.sent_ms = millis();
    Serial.printf("[JM2] EFFT fx=%u tx=%u\n", chosen, tx);
  }
  else
  {
    Serial.printf("[JM2] EFFT send failed fx=%u tx=%u\n", chosen, tx);
    s_jm2EffectFlight = {};
  }
}

void sendEQBandToDSP(uint8_t b, uint8_t enabled, uint16_t f, int8_t g, uint8_t q)
{
  char h[5];
  if (b == 0)
    strcpy(h, "EQHP");
  else if (b == 11)
    strcpy(h, "EQLP");
  else
    snprintf(h, 5, "EQ%02d", b);
  uint8_t p[5] = {enabled, (uint8_t)(f >> 8), (uint8_t)(f & 0xFF), (uint8_t)g, q};
  sendPacket(h, p, 5);
}

void sendDrumPatternToDSP(uint8_t rowIdx, uint8_t *velocities)
{
  uint8_t p1[11];
  p1[0] = rowIdx;
  memcpy(&p1[1], &velocities[0], 10);
  sendPacket("DRM1", p1, 11);
  delay(2);
  uint8_t p2[7];
  p2[0] = rowIdx;
  memcpy(&p2[1], &velocities[10], 6);
  sendPacket("DRM2", p2, 7);
}

// ============================================================================
// DSP RECEIVE (COBS)
// ============================================================================
void checkDSPIncoming()
{
  // Called only from loop(); do not call this from BLE callbacks. Keeping a
  // single RX parser owner prevents rx_idx and display/state re-entrancy bugs.
  while (dspSerial.available())
  {
    uint8_t b = dspSerial.read();
    if (b == COBS_DELIMITER)
    {
      if (rx_idx > 0)
      {
        size_t len = cobs_decode(rx_raw_buffer, rx_idx, rx_decoded);
        if (len >= sizeof(PacketHeader))
        {
          PacketHeader *hdr = (PacketHeader *)rx_decoded;
          uint8_t *payload = rx_decoded + sizeof(PacketHeader);
          if (crc32(payload, hdr->len) == hdr->crc)
          {
            char headerStr[5];
            memcpy(headerStr, &hdr->type, 4);
            headerStr[4] = 0;
            processDSPPacket(headerStr, payload, hdr->len);
          }
        }
      }
      rx_idx = 0;
    }
    else
    {
      if (rx_idx < sizeof(rx_raw_buffer))
        rx_raw_buffer[rx_idx++] = b;
      else
        rx_idx = 0;
    }
  }

}


// ============================================================================
// JMP2 V6 GENERIC NAM STREAM
// ============================================================================
static bool sendJm2NamCurrentStep()
{
  auto& f = s_jm2NamFlight;
  bool ok = false;

  if (f.phase == JM2_NAM_STREAM_BEGIN)
  {
    const uint16_t nameLen = (uint16_t)strnlen(s_namModelName, 64u);
    uint8_t payload[sizeof(Jm2StreamBeginPayload) + 64u];
    Jm2StreamBeginPayload begin{};
    begin.object_type  = s_v8StreamFile?JM2_STREAM_OBJECT_IR:JM2_STREAM_OBJECT_NAM;
    begin.chunk_size   = JM2_STREAM_CHUNK_BYTES;
    begin.total_bytes  = s_namExpectedBytes;
    begin.object_crc32 = s_namExpectedCrc;
    begin.item_count   = s_namExpectedWeights;
    begin.metadata_len = nameLen;
    memcpy(payload, &begin, sizeof(begin));
    if (nameLen)
      memcpy(payload + sizeof(begin), s_namModelName, nameLen);

    ok = sendJm2(JM2_SBEG,
                 JM2_F_RELIABLE | JM2_F_STREAM,
                 f.transaction, f.sequence,
                 payload, (uint16_t)(sizeof(begin) + nameLen));
  }
  else if (f.phase == JM2_NAM_STREAM_DATA)
  {
    if (f.offset >= s_namExpectedBytes)
      return false;

    uint16_t dataLen = (uint16_t)(s_namExpectedBytes - f.offset);
    if (dataLen > JM2_STREAM_CHUNK_BYTES)
      dataLen = JM2_STREAM_CHUNK_BYTES;

    uint8_t payload[sizeof(Jm2StreamDataHeader) + JM2_STREAM_CHUNK_BYTES];
    Jm2StreamDataHeader hdr{};
    hdr.offset   = f.offset;
    hdr.data_len = dataLen;
    memcpy(payload, &hdr, sizeof(hdr));
    if(s_v8StreamFile){
      File source=LittleFS.open(v8Path(2),"r");const bool read=source&&source.seek(f.offset)&&source.read(payload+sizeof(hdr),dataLen)==dataLen;source.close();if(!read)return false;
    }else memcpy(payload + sizeof(hdr), s_namWeightBuffer + f.offset, dataLen);
    f.last_data_len = dataLen;

    ok = sendJm2(JM2_SDAT,
                 JM2_F_RELIABLE | JM2_F_STREAM,
                 f.transaction, f.sequence,
                 payload, (uint16_t)(sizeof(hdr) + dataLen));
  }
  else if (f.phase == JM2_NAM_STREAM_END)
  {
    Jm2StreamEndPayload end{};
    end.object_type  = s_v8StreamFile?JM2_STREAM_OBJECT_IR:JM2_STREAM_OBJECT_NAM;
    end.total_bytes  = s_namExpectedBytes;
    end.object_crc32 = s_namExpectedCrc;
    end.item_count   = s_namExpectedWeights;

    ok = sendJm2(JM2_SEND,
                 JM2_F_RELIABLE | JM2_F_STREAM,
                 f.transaction, f.sequence,
                 (const uint8_t*)&end, sizeof(end));
  }

  if (ok)
  {
    f.waiting = true;
    f.acked = false;
    f.nacked = false;
    f.reply_valid = false;
    f.reply_reason = JM2_STREAM_OK;
    f.sent_ms = millis();
  }
  return ok;
}


static bool isFatalJm2StreamReason(uint16_t reason)
{
  switch ((Jm2StreamError)reason)
  {
    case JM2_STREAM_BAD_LENGTH:
    case JM2_STREAM_OVERFLOW:
    case JM2_STREAM_BAD_DATA:
    case JM2_STREAM_BAD_TRANSACTION:
    case JM2_STREAM_BAD_METADATA:
    case JM2_STREAM_BAD_CRC:
    case JM2_STREAM_INCOMPLETE:
    case JM2_STREAM_LOAD_FAILED:
      return true;
    default:
      return false;
  }
}

static void finishJm2NamStream(bool ok)
{
  if (ok)
  {
    Serial.printf("[JM2] NAM committed tx=%u name=%s bytes=%lu\n",
                  s_jm2NamFlight.transaction, s_namModelName,
                  (unsigned long)s_namExpectedBytes);
    char statusMsg[96];
    snprintf(statusMsg, sizeof(statusMsg), "NAM Loaded: %s", s_namModelName);
    display.showMessage(statusMsg);
    sendNamAck(0x76, 0);
  }
  else
  {
    Serial.printf("[JM2] NAM stream failed tx=%u seq=%u\n",
                  s_jm2NamFlight.transaction, s_jm2NamFlight.sequence);
    char statusMsg[96];
    snprintf(statusMsg, sizeof(statusMsg), "NAM DSP transfer failed: %s", s_namModelName);
    display.showMessage(statusMsg);
    sendNamAck(0x76, 5);
  }
  s_jm2NamFlight = {};
  s_jm2NamPending = false;
}

void serviceJm2NamStream()
{
  if (!s_jm2Connected) return;
  auto& f = s_jm2NamFlight;
  const uint32_t now = millis();

  if (f.active)
  {
    if (f.waiting && f.acked)
    {
      f.waiting = false;
      f.acked = false;
      f.nacked = false;
      f.retries = 0;

      // Stream ACK payload is receiver-authoritative. This matters after an
      // ACK loss/retry and is also the basis for a future sliding window.
      const uint16_t nextSeq = f.reply_valid
                             ? f.reply_next_sequence
                             : (uint16_t)(f.sequence + 1u);
      const uint32_t received = f.reply_valid
                              ? f.reply_received_bytes
                              : (f.phase == JM2_NAM_STREAM_DATA
                                   ? f.offset + f.last_data_len
                                   : f.offset);

      if (f.phase == JM2_NAM_STREAM_BEGIN)
      {
        f.sequence = nextSeq;
        f.offset = received;
        f.phase = (f.offset >= s_namExpectedBytes)
                ? JM2_NAM_STREAM_END : JM2_NAM_STREAM_DATA;
      }
      else if (f.phase == JM2_NAM_STREAM_DATA)
      {
        f.sequence = nextSeq;
        f.offset = received;
        if (f.offset >= s_namExpectedBytes)
          f.phase = JM2_NAM_STREAM_END;
      }
      else if (f.phase == JM2_NAM_STREAM_END)
      {
        finishJm2NamStream(true);
        return;
      }
    }
    else if (f.waiting && f.nacked)
    {
      // A structured NACK tells us exactly where the DSP is. Sequence/offset
      // mismatches are recoverable; malformed/corrupt object errors are fatal.
      if (f.reply_valid && isFatalJm2StreamReason(f.reply_reason))
      {
        Serial.printf("[JM2] NAM fatal NACK tx=%u seq=%u reason=%u next=%u bytes=%lu\n",
                      f.transaction, f.sequence, f.reply_reason,
                      f.reply_next_sequence,
                      (unsigned long)f.reply_received_bytes);
        finishJm2NamStream(false);
        return;
      }

      if (f.retries >= JM2_STREAM_MAX_RETRIES)
      {
        finishJm2NamStream(false);
        return;
      }

      if (f.reply_valid)
      {
        f.sequence = f.reply_next_sequence;
        f.offset = f.reply_received_bytes;
        if (f.sequence == 0u)
          f.phase = JM2_NAM_STREAM_BEGIN;
        else if (f.offset >= s_namExpectedBytes)
          f.phase = JM2_NAM_STREAM_END;
        else
          f.phase = JM2_NAM_STREAM_DATA;
      }

      f.retries++;
      f.waiting = false;
      f.acked = false;
      f.nacked = false;
      if (sendJm2NamCurrentStep())
        Serial.printf("[JM2] STREAM resync tx=%u seq=%u offset=%lu attempt=%u\n",
                      f.transaction, f.sequence,
                      (unsigned long)f.offset, f.retries);
      return;
    }
    else if (f.waiting)
    {
      if ((uint32_t)(now - f.sent_ms) < JM2_STREAM_ACK_TIMEOUT_MS)
        return;

      if (f.retries >= JM2_STREAM_MAX_RETRIES)
      {
        finishJm2NamStream(false);
        return;
      }

      f.retries++;
      f.waiting = false;
      if (sendJm2NamCurrentStep())
        Serial.printf("[JM2] STREAM retry tx=%u seq=%u attempt=%u\n",
                      f.transaction, f.sequence, f.retries);
      return;
    }

    if (!f.waiting && !sendJm2NamCurrentStep())
    {
      Serial.printf("[JM2] STREAM send failed tx=%u seq=%u\n",
                    f.transaction, f.sequence);
      finishJm2NamStream(false);
    }
    return;
  }

  if (!s_jm2NamPending) return;

  // Do not start a bulk stream in the middle of another reliable operation.
  if (s_jm2PresetFlight.active || s_jm2EffectFlight.active)
    return;

  __sync_synchronize();
  f = {};
  f.active = true;
  f.phase = JM2_NAM_STREAM_BEGIN;
  f.transaction = s_jm2NextTransaction++;
  if (s_jm2NextTransaction == 0) s_jm2NextTransaction = 1;
  f.sequence = 0;

  Serial.printf("[JM2] NAM stream begin tx=%u name=%s bytes=%lu chunks=%lu\n",
                f.transaction, s_namModelName,
                (unsigned long)s_namExpectedBytes,
                (unsigned long)((s_namExpectedBytes + JM2_STREAM_CHUNK_BYTES - 1u)
                                / JM2_STREAM_CHUNK_BYTES));
  sendJm2NamCurrentStep();
}

// ============================================================================
// JMP2 V5 ATOMIC PRESET TRANSACTION
// ============================================================================
static bool buildJm2PresetItem(const Preset& p,
                               uint16_t item_index,
                               uint8_t* out,
                               uint16_t* out_len)
{
  if (!out || !out_len || item_index >= JM2_PRESET_ITEM_COUNT)
    return false;

  size_t off = 0;
  if (item_index < MAX_EFFECTS)
  {
    const uint8_t fx = (uint8_t)item_index;
    const uint8_t kc = FX_LAYOUT[fx][0];
    const uint8_t dc = FX_LAYOUT[fx][1];
    if (4u + 1u + kc + dc > JM2_PRESET_ITEM_MAX_BYTES)
      return false;
    memcpy(out + off, EFFECT_NAMES[fx], 4); off += 4;
    out[off++] = p.effects[fx].enabled ? 1u : 0u;
    for (uint8_t k = 0; k < kc; ++k) out[off++] = p.effects[fx].knobs[k];
    for (uint8_t d = 0; d < dc; ++d) out[off++] = p.effects[fx].dropdowns[d];
  }
  else
  {
    const uint8_t band = (uint8_t)(item_index - MAX_EFFECTS);
    if (band >= 12u) return false;
    char hdr[5];
    if (band == 0) memcpy(hdr, "EQHP", 4);
    else if (band == 11) memcpy(hdr, "EQLP", 4);
    else snprintf(hdr, sizeof(hdr), "EQ%02u", band);
    memcpy(out + off, hdr, 4); off += 4;
    out[off++] = p.eqPoints[band].enabled ? 1u : 0u;
    out[off++] = (uint8_t)(p.eqPoints[band].freq >> 8);
    out[off++] = (uint8_t)(p.eqPoints[band].freq & 0xFFu);
    out[off++] = (uint8_t)p.eqPoints[band].gain;
    out[off++] = p.eqPoints[band].q;
  }
  *out_len = (uint16_t)off;
  return true;
}

static bool sendJm2PresetCurrentStep()
{
  auto& f = s_jm2PresetFlight;
  bool ok = false;

  if (f.phase == JM2_PRESET_BEGIN)
  {
    Jm2PresetBeginPayload begin{};
    begin.item_count = JM2_PRESET_ITEM_COUNT;
    begin.bank = f.preset.bank;
    begin.preset = f.preset.number;
    begin.master_volume = f.preset.masterVolume;
    begin.bpm = f.preset.bpm;
    ok = sendJm2(JM2_PBEG, JM2_F_RELIABLE,
                 f.transaction, f.sequence,
                 (const uint8_t*)&begin, sizeof(begin));
  }
  else if (f.phase == JM2_PRESET_DATA)
  {
    uint8_t item[JM2_PRESET_ITEM_MAX_BYTES];
    uint16_t len = 0;
    if (!buildJm2PresetItem(f.preset, f.item_index, item, &len))
      return false;
    ok = sendJm2(JM2_PDAT, JM2_F_RELIABLE,
                 f.transaction, f.sequence, item, len);
  }
  else if (f.phase == JM2_PRESET_END)
  {
    Jm2PresetEndPayload end{};
    end.item_count = JM2_PRESET_ITEM_COUNT;
    ok = sendJm2(JM2_PEND, JM2_F_RELIABLE,
                 f.transaction, f.sequence,
                 (const uint8_t*)&end, sizeof(end));
  }

  if (ok)
  {
    f.waiting = true;
    f.acked = false;
    f.nacked = false;
    f.sent_ms = millis();
  }
  return ok;
}

void serviceJm2PresetTransaction()
{
  if (!s_jm2Connected) return;
  auto& f = s_jm2PresetFlight;
  const uint32_t now = millis();

  if (f.active)
  {
    if (f.waiting && f.acked)
    {
      f.waiting = false;
      f.acked = false;
      f.nacked = false;
      f.retries = 0;

      if (f.phase == JM2_PRESET_BEGIN)
      {
        f.phase = JM2_PRESET_DATA;
        f.item_index = 0;
        f.sequence = 1;
      }
      else if (f.phase == JM2_PRESET_DATA)
      {
        f.item_index++;
        f.sequence++;
        if (f.item_index >= JM2_PRESET_ITEM_COUNT)
          f.phase = JM2_PRESET_END;
      }
      else if (f.phase == JM2_PRESET_END)
      {
        Serial.printf("[JM2] PRESET committed tx=%u bank=%u preset=%u\n",
                      f.transaction, f.preset.bank, f.preset.number);
        f = {};
        // Master may have changed while this reliable preset transaction was
        // in flight. DSP applied the snapshot at PEND: restore live global level
        // *after* the commit ACK so the last intentional volume wins.
        const uint8_t liveGlobal[4] = {state.volume, 0, currentPreset.bpm, 0};
        sendDataRobust("GEN ", liveGlobal, sizeof(liveGlobal));
        return;
      }
    }
    else if (f.waiting)
    {
      const bool retry = f.nacked
                      || (uint32_t)(now - f.sent_ms) >= JM2_PRESET_ACK_TIMEOUT_MS;
      if (!retry) return;

      if (f.retries >= JM2_PRESET_MAX_RETRIES)
      {
        Serial.printf("[JM2] PRESET failed tx=%u seq=%u; reconnecting\n",
                      f.transaction, f.sequence);
        // Preserve requested state for a fresh transaction after reconnect.
        portENTER_CRITICAL(&s_jm2PresetMux);
        memcpy(&s_jm2PresetPendingSnapshot, &f.preset, sizeof(Preset));
        s_jm2PresetPending = true;
        portEXIT_CRITICAL(&s_jm2PresetMux);
        f = {};
        s_jm2Connected = false;
        s_jm2HelloSent = false;
        return;
      }

      f.retries++;
      f.waiting = false;
      if (sendJm2PresetCurrentStep())
        Serial.printf("[JM2] PRESET retry tx=%u seq=%u attempt=%u\n",
                      f.transaction, f.sequence, f.retries);
      return;
    }

    if (!f.waiting && !sendJm2PresetCurrentStep())
    {
      Serial.printf("[JM2] PRESET send failed tx=%u seq=%u\n",
                    f.transaction, f.sequence);
    }
    return;
  }

  // Finish an already active preset before yielding to a NAM request, but do
  // not begin a new queued preset while bulk transfer owns priority.
  if (s_jm2NamFlight.active || s_jm2NamPending) return;
  if (!s_jm2PresetPending) return;

  Preset snapshot{};
  portENTER_CRITICAL(&s_jm2PresetMux);
  memcpy(&snapshot, &s_jm2PresetPendingSnapshot, sizeof(Preset));
  s_jm2PresetPending = false;
  portEXIT_CRITICAL(&s_jm2PresetMux);

  f = {};
  f.active = true;
  f.phase = JM2_PRESET_BEGIN;
  f.transaction = s_jm2NextTransaction++;
  if (s_jm2NextTransaction == 0) s_jm2NextTransaction = 1;
  f.sequence = 0;
  memcpy(&f.preset, &snapshot, sizeof(Preset));

  Serial.printf("[JM2] PRESET begin tx=%u bank=%u preset=%u items=%u\n",
                f.transaction, f.preset.bank, f.preset.number,
                JM2_PRESET_ITEM_COUNT);
  sendJm2PresetCurrentStep();
}

// ============================================================================
// PRESET MANAGEMENT
// ============================================================================
void updateDSPFromPreset()
{
  // Every preset transaction carries the *live* master level, never the
  // level stored in an old preset file or received from a remote controller.
  currentPreset.masterVolume = state.volume;
  // Once this DSP has proven JMP2 support, never fall back to a legacy preset
  // burst merely because a reconnect is in progress. Queue the newest snapshot
  // and let the loop transmit it after HELA. This prevents mixed legacy/JMP2
  // traffic after a reliable transaction timeout.
  if (!s_jm2Connected && s_jm2EverConnected)
  {
    portENTER_CRITICAL(&s_jm2PresetMux);
    memcpy(&s_jm2PresetPendingSnapshot, &currentPreset, sizeof(Preset));
    s_jm2PresetPending = true;
    portEXIT_CRITICAL(&s_jm2PresetMux);
    Serial.printf("[JM2] PRESET queued waiting reconnect bank=%u preset=%u\n",
                  currentPreset.bank, currentPreset.number);
    return;
  }

  // Legacy fallback is only for a peer that has never completed JMP2 handshake.
  if (!s_jm2Connected)
  {
    uint8_t p[4] = {currentPreset.bank, currentPreset.number,
                    currentPreset.masterVolume, currentPreset.bpm};
    sendToDSP("PRES", p, 4);
    for (int i = 0; i < MAX_EFFECTS; i++)
    {
      sendEffectChangeLegacyToDSP(i, currentPreset.effects[i].enabled,
                                  currentPreset.effects[i].knobs,
                                  currentPreset.effects[i].dropdowns);
      delay(5);
    }
    for (int i = 0; i < 12; i++)
    {
      sendEQBandToDSP(i,
                      currentPreset.eqPoints[i].enabled ? 1 : 0,
                      currentPreset.eqPoints[i].freq,
                      currentPreset.eqPoints[i].gain,
                      currentPreset.eqPoints[i].q);
      delay(5);
    }
    return;
  }

  // Do not send UART from BLE/UI callers. Snapshot the complete preset and let
  // loop() own reliable transmission. A newer request replaces an older pending
  // request; an already active transaction is allowed to finish first.
  portENTER_CRITICAL(&s_jm2PresetMux);
  memcpy(&s_jm2PresetPendingSnapshot, &currentPreset, sizeof(Preset));
  s_jm2PresetPending = true;
  portEXIT_CRITICAL(&s_jm2PresetMux);
  Serial.printf("[JM2] PRESET queued bank=%u preset=%u\n",
                currentPreset.bank, currentPreset.number);
}

void initializeFactoryPresets()
{
  if (LittleFS.exists("/presets/factory_v3.flag"))
  {
    Serial.println("[PRESETS] Factory presets already up to date.");
    return;
  }
  Serial.println("[PRESETS] Generating new Factory Presets...");
  if (!LittleFS.exists("/presets"))
    LittleFS.mkdir("/presets");

  const char *bankNames[] = {"Clean", "Crunch", "Overdrive", "Distortion",
                             "Modulated", "Custom1", "Custom2"};
  for (int bank = 0; bank < 5; bank++)
  {
    for (int num = 0; num < 5; num++)
    {
      Preset p;
      memset(&p, 0, sizeof(Preset));
      snprintf(p.name, 32, "%s %d", bankNames[bank], num + 1);
      p.bank = bank;
      p.number = num;
      p.masterVolume = kBootMasterVolume;
      p.bpm = 120;
      for (int i = 0; i < 12; i++)
      {
        p.eqPoints[i].freq = (i == 0) ? 80 : (i == 11) ? 8000
                                                       : (100 * (i + 1));
        p.eqPoints[i].gain = 0;
        p.eqPoints[i].q = 14;
        p.eqPoints[i].enabled = true;
      }
      if (bank == 0)
      {
        p.effects[13].enabled = true;
        p.effects[13].knobs[6] = 30;
        p.effects[13].dropdowns[0] = 1;
        p.effects[16].enabled = true;
        p.effects[16].knobs[0] = 40;
        p.effects[1].enabled = true;
        p.effects[1].knobs[0] = 60;
      }
      else if (bank == 1)
      {
        p.effects[3].enabled = true;
        p.effects[3].knobs[1] = 70;
        p.effects[13].enabled = true;
        p.effects[13].dropdowns[0] = 3;
      }
      else if (bank == 3)
      {
        p.effects[0].enabled = true;
        p.effects[4].enabled = true;
        p.effects[4].knobs[1] = 90;
        p.effects[4].dropdowns[0] = 2;
        p.effects[14].enabled = true;
      }
      char filename[32];
      snprintf(filename, 32, "/presets/f_%d_%d.bin", bank, num);
      File file = LittleFS.open(filename, "w");
      if (file)
      {
        size_t size = serializeStructToBlob(p, blobBuffer);
        file.write(blobBuffer, size);
        file.close();
      }
    }
  }
  File flagFile = LittleFS.open("/presets/factory_v3.flag", "w");
  if (flagFile)
  {
    flagFile.print("done");
    flagFile.close();
  }
  Serial.println("[PRESETS] Generation Complete.");
}

bool loadPreset(uint8_t bank, uint8_t number, Preset &preset)
{
  if (bank > 6 || number > 4)
    return false;
  char filename[64];
  if (bank < 5)
    snprintf(filename, sizeof(filename), "/presets/f_%d_%d.bin", bank, number);
  else
    snprintf(filename, sizeof(filename), "/presets/c_%d_%d.bin", bank - 5, number);

  if (LittleFS.exists(filename))
  {
    File file = LittleFS.open(filename, "r");
    if (file)
    {
      Preset temp;
      memset(&temp, 0, sizeof(Preset)); // params missing from an older/shorter blob read as 0, not stack garbage
      if(file.size()>MAX_BLOB_SIZE){file.close();return false;}
      size_t size = file.read(blobBuffer, MAX_BLOB_SIZE);
      file.close();
      bool legacy=false;
      if(!PresetBlobReader::decode(blobBuffer,size,FX_LAYOUT,temp,legacy)){
        Serial.printf("[PRESET] Corrupt preset: %s (file preserved)\n",filename);
        return false;
      }
      if(legacy)Serial.printf("[PRESET] Read legacy parameter widths: %s (flash unchanged)\n",filename);
      preset = temp;
      preset.masterVolume = state.volume;
      preset.bank = bank;
      preset.number = number;
      return true;
    }
  }

  Serial.printf("[PRESET] File %s not found. Loading default.\n", filename);
  memset(&preset, 0, sizeof(Preset));
  const char *defaultNames[] = {"Clean", "Crunch", "Overdrive", "Distortion",
                                "Modulated", "Custom1", "Custom2"};
  snprintf(preset.name, 32, "%s %d", defaultNames[bank], number + 1);
  preset.bank = bank;
  preset.number = number;
  preset.masterVolume = state.volume;
  preset.bpm = 120;
  for (int i = 0; i < 12; i++)
  {
    preset.eqPoints[i].freq = (i == 0) ? 80 : (i == 11) ? 8000
                                                        : (100 * (i + 1));
    preset.eqPoints[i].gain = 0;
    preset.eqPoints[i].q = 14;
    preset.eqPoints[i].enabled = true;
  }
  return true;
}

void saveSystemState()
{
  File file = LittleFS.open("/state.dat", "w");
  if (file)
  {
    file.write((uint8_t *)&state, sizeof(SystemState));
    file.close();
  }
}

void loadSystemState()
{
  File file = LittleFS.open("/state.dat", "r");
  if (file)
  {
    file.read((uint8_t *)&state, sizeof(SystemState));
    file.close();
  }
  else
  {
    state.currentBank = 0;
    state.currentPresetNum = 0;
    state.volume = kBootMasterVolume;
    state.a2dpEnabled = true;
    for (int i = 0; i < 4; i++)
      state.switchStates[i] = false;
  }
  // Power-on always selects Clean 1 at a safe 20%. Current volume persists across
  // preset/effect changes *during this boot* but is intentionally NOT restored
  // from /state.dat on the next boot.
  state.volume = kBootMasterVolume;
  currentPreset.masterVolume = state.volume;
  state.currentBank = 0;
  state.currentPresetNum = 0;
  if (!loadPreset(state.currentBank, state.currentPresetNum, currentPreset))
  {
    memset(&currentPreset, 0, sizeof(Preset));
    strcpy(currentPreset.name,"Unreadable preset");currentPreset.bpm=120;currentPreset.masterVolume=state.volume;
    for(auto& eq:currentPreset.eqPoints){eq.freq=440;eq.q=14;}
  }
}

// ============================================================================
// INPUT HANDLERS
// ============================================================================
void setupSwitches()
{
  switch1.begin();
  switch2.begin();
}

void sendSwitchStateToDSP(int switchIndex, bool switchState)
{
  uint8_t payload[2] = {(uint8_t)switchIndex, (uint8_t)switchState};
  sendToDSP("SWCH", payload, 2);
}

void handleSwitches()
{
  switch1.update();
  switch2.update();

  static bool drainAfterFlash = false;

  // Volume encoder button (encoder2) + Switch 1 held together for >2.0s → flash Daisy
  if (switch1.isHeld() && (digitalRead(ENCODER1_BTN) == LOW)) {
    if (!drainAfterFlash) {
      if (bothSwitchesHeldSince == 0) bothSwitchesHeldSince = millis();
      if (millis() - bothSwitchesHeldSince > 2000) {
        bothSwitchesHeldSince = 0;
        drainAfterFlash = true;
        Serial.println("[ACTION] Flash Daisy triggered");
        display.showMessage("Flashing DSP...");
        uint8_t dummy = 0;
        sendToDSP("FLSH", &dummy, 0);
        delay(200);
        dspSerial.end();
        dspSerialOn = false;
        
        
      }
    }
    return; // suppress all other switch actions while both are held
  } else {
    bothSwitchesHeldSince = 0;
  }

  // Drain any long-click/press events that fired on release after the flash combo.
  // Keep draining until both switches are fully released.
  if (drainAfterFlash) {
    switch1.isLongClick();
    switch2.isLongClick();
    switch1.isButtonPressed();
    switch2.isButtonPressed();
    switch1.isDoubleClick();
    switch2.isDoubleClick();
    if (!switch1.isHeld() && !switch2.isHeld())
      drainAfterFlash = false;
    return;
  }

  bool sw1Long = switch1.isLongClick();
  bool sw2Long = switch2.isLongClick();

  if (sw1Long && display.currentState != STATE_MAIN_MENU)
    encoder1.injectLongPress(); // return to main from any sub-screen

  if (sw1Long && display.currentState == STATE_MAIN_MENU)
  {
    uint8_t tunerOnPayload[5] = { 2, 1, 0, 0, 0 };
    sendToDSP("UTIL", tunerOnPayload, 5);
    pendingTunerState = 1;
    tunerPendingAt = millis();
  }

  if (sw2Long && display.currentState == STATE_MAIN_MENU)
    encoder2.injectLongPress(); // toggle UART on main screen
}

void performEncoder1Action(int delta, int clickState)
{
  if (delta != 0)
  {
    int prevBank = state.currentBank;
    state.currentBank = constrain(state.currentBank + delta, 0, 6);
    if (state.currentBank != prevBank)
    {
      Serial.printf("[ACTION] Bank Changed: %d\n", state.currentBank);
      display.refresh();
    }
  }
  if (clickState == 1)
  {
    Serial.println("[ACTION] Loading Preset...");
    if (loadPreset(state.currentBank, state.currentPresetNum, currentPreset))
    {
      updateDSPFromPreset();
      size_t size = serializeStructToBlob(currentPreset, blobBuffer);
      uint8_t head[3] = {0x31, (uint8_t)(size & 0xFF), (uint8_t)(size >> 8)};
      btManager.sendBLEBlob(head[0], blobBuffer, size);
      display.refresh();
    }
  }
  else if (clickState == 2)
  {
    Serial.println("[ACTION] Long Click Triggered");
  }
}

void performEncoder2Action(int delta, int clickState)
{
  if (delta != 0)
  {
    int prevNum = state.currentPresetNum;
    state.currentPresetNum = constrain(state.currentPresetNum + delta, 0, 4);
    if (state.currentPresetNum != prevNum)
    {
      Serial.printf("[ACTION] Preset Num: %d\n", state.currentPresetNum);
      display.refresh();
    }
  }
  if (clickState == 1)
  {
    state.a2dpEnabled = !state.a2dpEnabled;
    if (state.a2dpEnabled)
      btManager.enableA2DP();
    else
      btManager.disableA2DP();
    Serial.printf("[ACTION] A2DP Toggled: %d\n", state.a2dpEnabled);
  }
}

void handleEncoders()
{
  int enc1Pos = encoder1.getPosition();
  if (enc1Pos != lastEncoder1Pos)
  {
    int delta = enc1Pos - lastEncoder1Pos;
    lastEncoder1Pos = enc1Pos;
    performEncoder1Action(delta, 0);
  }
  if (encoder1.isButtonPressed() && (millis() - lastEncoder1BtnTime > DEBOUNCE_TIME))
  {
    performEncoder1Action(0, 1);
    lastEncoder1BtnTime = millis();
  }

  int enc2Pos = encoder2.getPosition();
  if (enc2Pos != lastEncoder2Pos)
  {
    int delta = enc2Pos - lastEncoder2Pos;
    lastEncoder2Pos = enc2Pos;
    performEncoder2Action(delta, 0);
  }
  if (encoder2.isButtonPressed() && (millis() - lastEncoder2BtnTime > DEBOUNCE_TIME))
  {
    performEncoder2Action(0, 1);
    lastEncoder2BtnTime = millis();
  }

}

// ============================================================================
// MIDI CALLBACK
// ============================================================================
#if USE_MIDI
void processMidiFromPedal(uint8_t *data, size_t len)
{
  Serial.print("[MIDI IN] ");
  for (size_t i = 0; i < len; i++)
    Serial.printf("%02X ", data[i]);
  Serial.println();

  if (len < 4 || data[0] != 0x80 || data[1] != 0x80 || data[2] != 0xC0)
    return;
  uint8_t cmd = data[3];

  auto syncWebApp = [&]()
  {
    size_t size = serializeStructToBlob(currentPreset, blobBuffer);
    uint8_t head[3] = {0x31, (uint8_t)(size & 0xFF), (uint8_t)(size >> 8)};
    btManager.sendBLEBlob(head[0], blobBuffer, size);
  };

  switch (cmd)
  {
  case 0: // Bank Up
    state.currentBank = constrain(state.currentBank + 1, 0, 6);
    if (loadPreset(state.currentBank, state.currentPresetNum, currentPreset))
    {
      updateDSPFromPreset();
      display.refresh();
      syncWebApp();
    }
    break;
  case 1: // Bank Down
    state.currentBank = constrain(state.currentBank - 1, 0, 6);
    if (loadPreset(state.currentBank, state.currentPresetNum, currentPreset))
    {
      updateDSPFromPreset();
      display.refresh();
      syncWebApp();
    }
    break;
  case 2: // Preset Up
    state.currentPresetNum = constrain(state.currentPresetNum + 1, 0, 4);
    if (loadPreset(state.currentBank, state.currentPresetNum, currentPreset))
    {
      updateDSPFromPreset();
      display.refresh();
      syncWebApp();
    }
    break;
  case 3: // Preset Down
    state.currentPresetNum = constrain(state.currentPresetNum - 1, 0, 4);
    if (loadPreset(state.currentBank, state.currentPresetNum, currentPreset))
    {
      updateDSPFromPreset();
      display.refresh();
      syncWebApp();
    }
    break;
  case 4:
  {
    uint8_t p[] = {1, 0};
    sendDataRobust("L_RC", p, 2);
    break;
  }
  case 5:
  {
    uint8_t p[] = {0, 0};
    sendDataRobust("L_ST", p, 2);
    break;
  }
  case 6:
  {
    uint8_t p[] = {1, 0};
    sendDataRobust("L_UN", p, 2);
    break;
  }
  case 7:
  {
    uint8_t p[] = {1, 0};
    sendDataRobust("L_CL", p, 2);
    break;
  }
  case 8:
    encoder1.injectRotation(1);
    break;
  case 9:
    encoder1.injectRotation(-1);
    break;
  case 10:
    encoder1.injectButtonPress();
    break;
  case 11:
    encoder1.injectLongPress();
    break;
  default:
    Serial.printf("[MIDI] Unmapped Command: %d\n", cmd);
    break;
  }
}
#endif // USE_MIDI

// ============================================================================
// BOOT ANIMATION
// ============================================================================
#define MAX_JPG_SIZE 24000
void playBootAnimation()
{
  char filename[32];
  uint8_t *pBuffer = (uint8_t *)malloc(MAX_JPG_SIZE);
  if (!pBuffer)
  {
    Serial.println("Not enough RAM for animation buffer!");
    return;
  }
  for (int i = 1; i <= FRAME_COUNT; i++)
  {
    sprintf(filename, "/frame_%03d.jpg", i);
    File jpgFile = LittleFS.open(filename, "r");
    if (jpgFile)
    {
      size_t fileSize = jpgFile.size();
      if (fileSize < MAX_JPG_SIZE)
      {
        jpgFile.read(pBuffer, fileSize);
        TJpgDec.drawJpg(0, 0, pBuffer, fileSize);
      }
      jpgFile.close();
    }
  }
  free(pBuffer);
}

// ============================================================================
// SETUP
// ============================================================================
void setup()
{
  s_bleCommands=xQueueCreate(8,sizeof(BleCommand));
  
/*   // Temporary — add at top of setup(), remove after one flash
LittleFS.remove("/presets/factory_v3.flag");
// Also wipe all custom presets
File root = LittleFS.open("/presets");
if (root) {
    File f = root.openNextFile();
    while (f) {
        String name = f.name();
        f.close();
        LittleFS.remove(("/presets/" + name).c_str());
        f = root.openNextFile();
    }
} */
  
  s_dspMutex = xSemaphoreCreateMutex();

  Serial.setRxBufferSize(8192); // bounded serial ingress; leave heap for hybrid BLE/A2DP packet buffers
  Serial.begin(115200);
  Serial.printf("[BOOT] reset=%d heap=%u largest=%u stackMin=%u\n",int(esp_reset_reason()),ESP.getFreeHeap(),heap_caps_get_largest_free_block(MALLOC_CAP_8BIT),unsigned(uxTaskGetStackHighWaterMark(nullptr)));
  delay(10);


  // Filesystem
  if (!LittleFS.begin(false))
    Serial.println("[FS] Mount failed; existing presets preserved, configuration edits disabled");
  ensureWebConfig();
  loadFxLayoutFromConfig(); // Validated configuration drives protocol and display.
  initializeFactoryPresets();
  loadSystemState();
  display.btAudioEnabled = state.a2dpEnabled;

  // Encoders & switches
  encoder1.begin();
  encoder2.begin();
  setupSwitches();
  delay(10);

  // Flow control pin
  pinMode(DAISY_READY_PIN, INPUT);

  // Display & JPEG decoder
  display.tft.init();
  display.tft.setRotation(2);
  display.tft.fillScreen(TFT_BLACK);
  TJpgDec.setJpgScale(1);
  TJpgDec.setSwapBytes(true);
  TJpgDec.setCallback(tft_output);
  //playBootAnimation();

  // Bluetooth / A2DP
  i2s_pin_config_t pins = {
      .mck_io_num = 0, .bck_io_num = 14, .ws_io_num = 13, .data_out_num = 12, .data_in_num = 35};
  btManager.setA2DPPinConfig(pins);
  delay(10);
#if USE_MIDI
  btManager.setMidiCallback(processMidiFromPedal);
  delay(10);
#endif
  btManager.setBLEDataCallback(onBLEDataReceived);
  delay(10);
  btManager.begin("JamMate", state.a2dpEnabled);
  delay(10);
  btManager.setCurrentPreset(&currentPreset);
  delay(10);
#if USE_MIDI
  btManager.triggerMidiConnectionAttempt();
#endif

  display.begin();
  lastSaveTime = millis();
  delay(10);

  Serial.println("[JamMate] v8.4 binary protocol ready");
  display.begin();
  delay(500);

  // Re-configure after begin() (TFT_eSPI may reconfigure the pin)
  pinMode(ENCODER1_BTN, INPUT_PULLUP);

  lastSaveTime = millis();
}

// ============================================================================
// LOOP
// ============================================================================

void loop()
{
  BleCommand command;
  if(s_bleCommands&&xQueueReceive(s_bleCommands,&command,0)==pdTRUE){
    if(btManager.connected()&&command.epoch==btManager.session())processBLEData(command.data,command.size);
    s_commandBusy[command.slot]=false;
  }
  servicePresetSerial();
  // V2 handshake is non-blocking and independent of legacy traffic. Retry every
  // 2 s until the DSP confirms support; old firmware simply ignores JMP2.
  if (dspSerialOn && digitalRead(DAISY_READY_PIN) == HIGH && !s_jm2Connected)
  {
    if (!s_jm2HelloSent || (millis() - s_jm2LastHelloMs) >= 2000)
      sendJm2Hello();
  }

  // Reliable JMP2 commands are serviced only from loop(), never BLE callbacks.
  // Presets have priority so their staged transaction cannot be interleaved
  // with interactive single-effect writes.
  serviceJm2NamStream();
  serviceJm2PresetTransaction();
  serviceJm2ReliableEffects();

  // Non-blocking UART auto-connect
  if (checkUART)
  {
    uint32_t now = millis();
    if (uartStartTime == 0)
      uartStartTime = now;
    if (now - uartStartTime > UART_RETRY_TIMEOUT)
    {
      Serial.println("[UART] Timeout - Daisy may not be powered");
      checkUART = false;
    }
    else if (now - lastUartAttempt > UART_RETRY_INTERVAL)
    {
      lastUartAttempt = now;
      if (digitalRead(DAISY_READY_PIN))
      {
        Serial.println("[UART] Daisy detected, initializing...");
        dspSerial.begin(1000000, SERIAL_8N1, DSP_RX_PIN, DSP_TX_PIN);
        delay(100);
        dspSerialOn = true;
        checkUART = false;
        // Set the safe global level as soon as DSP UART comes online, before
        // the longer reliable preset download is sent.
        const uint8_t startupGlobal[4] = {state.volume, 0, currentPreset.bpm, 0};
        sendDataRobust("GEN ", startupGlobal, sizeof(startupGlobal));
        updateDSPFromPreset();
        display.showMessage("UART On!");
        Serial.println("[UART] Connected successfully!");
      }
      else
      {
        Serial.printf("[UART] Waiting for Daisy... (%d)\n",
                      (now - uartStartTime) / UART_RETRY_INTERVAL);
      }
    }
    return; // Don't run main loop until UART is resolved (or timed out)
  }
  encoder1.update();
  encoder2.update();
  handleSwitches();
  checkDSPIncoming();
  btManager.tick();

  // Handle deferred tuner activation — gives power/UART ~150ms to settle after UTIL packet
  if (pendingTunerState >= 0 && (millis() - tunerPendingAt >= 150)) {
    display.toggleTuner(pendingTunerState == 1);
    pendingTunerState = -1;
  }

  // --- Process deferred BLE commands (display/state changes must run on main task) ---
  if (s_pendingLooperEnable >= 0) {
    const int8_t enabled = s_pendingLooperEnable;
    s_pendingLooperEnable = -1;
    display.looperEnabled = enabled != 0;
    // Enable state does not require a full-screen repaint.
  }
  if (s_pendingLoopCmd) {
    s_pendingLoopCmd = false;
    const uint8_t *p = s_loopCmdPayload;
    const char *action = p[1] ? "REC" : p[2] ? "STOP"
                       : p[3] ? "CLEAR" : p[4] ? "UNDO"
                       : p[5] ? "REDO"  : p[6] ? "STOP ALL"
                       : p[7] ? "CLR ALL" : nullptr;
    char msg[24];
    if (action) snprintf(msg, sizeof(msg), "Loop T%d: %s", p[0], action);
    else        snprintf(msg, sizeof(msg), "Loop T%d cfg", p[0]);
    // The Looper page already exposes requested/confirmed states. A modal
    // toast covering the live ring would force it to flash on every command.
    Serial.printf("[BLE] %s\n",msg);
    if (p[1]) display.looperEnabled = true;
    display.looperNum      = p[0];
    display.looperSync     = p[8];
    display.looperPlayMode = p[9];
    display.looperBars     = p[10];
    display.looperAutoArm  = (p[11] > 0);
    display.looperLevel    = p[15];
    if (p[1])
    {
      // REC requested over BLE. Do NOT start the visible recording ring yet:
      // the DSP's LOOP status 1 confirms the actual sample-accurate onset.
      // The former optimistic TS_RECORDING animation could fill even while
      // the audio engine had rejected/did not receive the command.
      if (display.looperTrackState == 0)
        display.looperTrackState = display.looperAutoArm ? 1 : 2;
      else if (display.looperTrackState == 1 || display.looperTrackState == 4)
        display.looperTrackState = 2;
      display.isRecording = false;
    }
    else if (p[2] || p[6])  display.applyLooperStateChange(2); // stop / stop-all
    else if (p[3] || p[7]) { display.loopLayerCount = 0; display.applyLooperStateChange(2); }
    else if (p[4])          display.applyLooperStateChange(3); // undo
    const bool enteringLooper = display.currentState != STATE_LOOPER;
    if (enteringLooper) {
      display.currentState = STATE_LOOPER;
      display.overlayExpireAt = 0; // avoid a stale previous-page toast repaint
      display.looperHeaderOverlay = false;
    }
    if (enteringLooper) display.drawLooperScreen(true);
    else display.looperUiNeedsParameters = true;
  }

  if (s_pendingPresetRefresh) {
    s_pendingPresetRefresh = false;
    display.refresh();
  }

  if(s_pendingFxEnableRefresh>=0){
    const int id=s_pendingFxEnableRefresh;
    s_pendingFxEnableRefresh=-1;
    display.refreshFxEffect(id);
  }

  if (s_pendingFxParamRefresh) {
    s_pendingFxParamRefresh=false;
    if(display.currentState==STATE_FX_EDIT) {
      const int pid=int(s_pendingFxParamPid);
      if(pid>=0 && pid<fxLayouts[display.fxEditIndex].knobCount+
                               fxLayouts[display.fxEditIndex].dropCount) {
        // The new one-column portrait row knows its own scroll position.
        if(pid<fxLayouts[display.fxEditIndex].knobCount)
           display.drawFxParamSlider(pid,nullptr,0,false,false,true);
        else display.drawFxParamDropdown(pid,nullptr,0,false,false,true);
      }
    }
  }

  if (s_pendingDrumCmd) {
    s_pendingDrumCmd = false;
    const uint8_t *raw = s_drumCmdPayload; // raw[4..15] = 12 DSP fields
    uint8_t dspP[12];
    for (int i = 0; i < 12; i++) dspP[i] = raw[4 + i];
    char msg[32];
    snprintf(msg, sizeof(msg), "Drum%s BPM:%d T%d", dspP[0] ? " ON" : " OFF", dspP[2], dspP[11]);
    display.showMessage(msg);
    bool looperWasEnabled = display.looperEnabled;
    const bool newDrumsEnabled = dspP[0] != 0;
    if (display.drumEnabled != newDrumsEnabled)
      display.drumTileNeedsRefresh = true;
    display.drumEnabled = newDrumsEnabled;
    display.drumBPM = dspP[2];currentPreset.bpm=dspP[2];
    display.drumFill=dspP[4];
    display.drumLevel = dspP[1] <= 100 ? dspP[1] : 100;
    display.drumStyle = dspP[3] <= 3 ? dspP[3] : 0;
    display.drumPattern = dspP[5]; // retained for legacy packet round-trip
    if (!newDrumsEnabled) display.beatClock.Invalidate();
    if (display.currentState == STATE_DRUM) display.drawDrumSettings();
    display.looperEnabled = (dspP[6] > 0);
    display.looperLevel   = (int(dspP[7])*127+50)/100;
    display.looperSync    = dspP[8];
    display.looperAutoArm = (dspP[9] > 0);
    display.looperBars    = dspP[10];
    display.looperNum     = dspP[11];
    if (display.looperEnabled) {
      if (!looperWasEnabled && display.currentState != STATE_LOOPER) {
        display.currentState = STATE_LOOPER;
        display.drawLooperScreen();
      } else if (display.currentState == STATE_LOOPER) {
        display.looperUiNeedsParameters = true;
      }
    } else if (looperWasEnabled && display.currentState == STATE_LOOPER) {
      display.currentState = STATE_MAIN_MENU;
      display.drawMainScreen();
    }
  }

  display.loop();
  serviceWebSync();
  serviceV8Resources();

  unsigned long now = millis();
  if (now - lastSaveTime > SAVE_INTERVAL)
  {
    if (!btManager.isA2DPStreaming()) {
      saveSystemState();
    }
    lastSaveTime = now;
  }

  delay(1);
}