#pragma once
// JamMate serial preset v1: readable, line-by-line, CRC-checked and bounded.
// Requires PresetBinary_v2.hpp before this header (Preset, MAX_EFFECTS).
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

namespace JmSerialPreset {
constexpr size_t kMaxLine = 192;
constexpr char kHeader[] = "JAMMATE_PRESET_V1";
constexpr char kEnd[] = "END_JAMMATE_PRESET";
using Emit = void (*)(const char*, void*);
using ParamLabel = const char* (*)(uint8_t fx, bool dropdown, uint8_t index);

inline uint16_t crcAdd(uint16_t crc, const char* text) {
    for (const uint8_t* p = (const uint8_t*)text; *p; ++p) {
        crc ^= *p;
        for (int bit = 0; bit < 8; ++bit) crc = (crc & 1) ? (crc >> 1) ^ 0xA001 : crc >> 1;
    }
    crc ^= '\n';
    for (int bit = 0; bit < 8; ++bit) crc = (crc & 1) ? (crc >> 1) ^ 0xA001 : crc >> 1;
    return crc;
}

inline void emitData(const char* line, Emit emit, void* ctx, uint16_t& crc) {
    emit(line, ctx);
    crc = crcAdd(crc, line);
}

inline bool parseInt(const char* s, long lo, long hi, long& result) {
    if (!s || !*s) return false;
    char* end = nullptr;
    long n = strtol(s, &end, 10);
    if (end == s || *end || n < lo || n > hi) return false;
    result = n;
    return true;
}

inline void encodeName(const char* name, char* out, size_t outSize) {
    size_t j = 0;
    for (size_t i = 0; i < PRESET_NAME_LENGTH - 1 && name[i] && j + 5 < outSize; ++i) {
        const unsigned char c = (unsigned char)name[i];
        if (c < 32 || c > 126 || c == '\\') {
            snprintf(out + j, outSize - j, "\\x%02X", (unsigned)c);
            j += 4;
        } else out[j++] = (char)c;
    }
    out[j] = '\0';
}

inline int fromHex(char c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    return -1;
}

inline bool decodeName(const char* s, char* dest) {
    size_t j = 0;
    for (size_t i = 0; s[i]; ++i) {
        if (j >= PRESET_NAME_LENGTH - 1) return false;
        if (s[i] == '\\') {
            if (s[i + 1] != 'x' || !s[i + 2] || !s[i + 3]) return false;
            const int h = fromHex(s[i + 2]), l = fromHex(s[i + 3]);
            if (h < 0 || l < 0 || (h == 0 && l == 0)) return false;
            dest[j++] = (char)((h << 4) | l);
            i += 3;
        } else dest[j++] = s[i];
    }
    dest[j] = '\0';
    return true;
}

inline void dump(const Preset& p, const uint8_t layout[MAX_EFFECTS][2],
                 ParamLabel label, Emit emit, void* ctx) {
    char line[kMaxLine];
    char name[PRESET_NAME_LENGTH * 4 + 1];
    uint16_t crc = 0xFFFF;
    emit(kHeader, ctx);
    snprintf(line, sizeof(line), "BANK=%u", (unsigned)p.bank);
    emitData(line, emit, ctx, crc);
    snprintf(line, sizeof(line), "SLOT=%u", (unsigned)p.number + 1u);
    emitData(line, emit, ctx, crc);
    encodeName(p.name, name, sizeof(name));
    snprintf(line, sizeof(line), "NAME=%s", name);
    emitData(line, emit, ctx, crc);
    snprintf(line, sizeof(line), "VOLUME=%u", (unsigned)p.masterVolume);
    emitData(line, emit, ctx, crc);
    snprintf(line, sizeof(line), "BPM=%u", (unsigned)p.bpm);
    emitData(line, emit, ctx, crc);
    for (unsigned fx = 0; fx < MAX_EFFECTS; ++fx) {
        snprintf(line, sizeof(line), "FX%02u %s ENABLED=%u", fx, EFFECT_NAMES[fx],
                 (unsigned)(p.effects[fx].enabled ? 1 : 0));
        emitData(line, emit, ctx, crc);
        const uint8_t k = layout[fx][0] > MAX_EFFECT_KNOBS ? MAX_EFFECT_KNOBS : layout[fx][0];
        const uint8_t d = layout[fx][1] > MAX_EFFECT_DROPDOWNS ? MAX_EFFECT_DROPDOWNS : layout[fx][1];
        for (unsigned n = 0; n < k; ++n) {
            const char* lbl = label ? label(fx, false, n) : nullptr;
            snprintf(line, sizeof(line), "FX%02u K%02u %s=%u", fx, n,
                     (lbl && *lbl) ? lbl : "Knob", (unsigned)p.effects[fx].knobs[n]);
            emitData(line, emit, ctx, crc);
        }
        for (unsigned n = 0; n < d; ++n) {
            const char* lbl = label ? label(fx, true, n) : nullptr;
            snprintf(line, sizeof(line), "FX%02u D%02u %s=%u", fx, n,
                     (lbl && *lbl) ? lbl : "Select", (unsigned)p.effects[fx].dropdowns[n]);
            emitData(line, emit, ctx, crc);
        }
    }
    for (unsigned e = 0; e < 12; ++e) {
        snprintf(line, sizeof(line), "EQ%02u FREQ=%u GAIN=%d Q=%u ENABLED=%u", e,
                 (unsigned)p.eqPoints[e].freq, (int)p.eqPoints[e].gain,
                 (unsigned)p.eqPoints[e].q, (unsigned)(p.eqPoints[e].enabled ? 1 : 0));
        emitData(line, emit, ctx, crc);
    }
    snprintf(line, sizeof(line), "CRC16=%04X", (unsigned)crc);
    emit(line, ctx);
    emit(kEnd, ctx);
}

// Parsing accepts only a complete dump in its original order. It NEVER writes flash.
// Caller commits only after Result::Complete, with the validated bank/slot.
struct Importer {
    enum class Result { More, Complete, Error };
    enum class Stage { Header, Bank, Slot, Name, Volume, Bpm, Effects, Eq, Crc, End, Complete };
    Preset candidate{};
    Stage stage = Stage::Header;
    uint16_t crc = 0xFFFF;
    uint8_t fx = 0, part = 0, index = 0, eq = 0;
    char error[104] = {};

    void reset() { *this = Importer{}; }
    Result fail(const char* msg) {
        snprintf(error, sizeof(error), "%s", msg);
        return Result::Error;
    }

    Result consume(const char* line, const uint8_t layout[MAX_EFFECTS][2]) {
        if (!line || strlen(line) >= kMaxLine) return fail("Line too long");
        long number = 0;
        char key[30];
        const char* value = nullptr;
        switch (stage) {
        case Stage::Header:
            if (strcmp(line, kHeader)) return fail("Expected JAMMATE_PRESET_V1");
            stage = Stage::Bank; return Result::More;
        case Stage::Bank:
            if (strncmp(line, "BANK=", 5) || !parseInt(line + 5, 0, 6, number)) return fail("Invalid BANK");
            candidate.bank = (uint8_t)number;
            stage = Stage::Slot; break;
        case Stage::Slot:
            if (strncmp(line, "SLOT=", 5) || !parseInt(line + 5, 1, 5, number)) return fail("Invalid SLOT");
            candidate.number = (uint8_t)(number - 1);
            stage = Stage::Name; break;
        case Stage::Name:
            if (strncmp(line, "NAME=", 5) || !decodeName(line + 5, candidate.name)) return fail("Invalid NAME");
            stage = Stage::Volume; break;
        case Stage::Volume:
            if (strncmp(line, "VOLUME=", 7) || !parseInt(line + 7, 0, 127, number)) return fail("Invalid VOLUME");
            candidate.masterVolume = (uint8_t)number;
            stage = Stage::Bpm; break;
        case Stage::Bpm:
            if (strncmp(line, "BPM=", 4) || !parseInt(line + 4, 0, 255, number)) return fail("Invalid BPM");
            candidate.bpm = (uint8_t)number;
            stage = Stage::Effects; break;
        case Stage::Effects: {
            if (fx >= MAX_EFFECTS) return fail("Too many FX");
            const uint8_t k = layout[fx][0] > MAX_EFFECT_KNOBS ? MAX_EFFECT_KNOBS : layout[fx][0];
            const uint8_t d = layout[fx][1] > MAX_EFFECT_DROPDOWNS ? MAX_EFFECT_DROPDOWNS : layout[fx][1];
            if (part == 0) {
                snprintf(key, sizeof(key), "FX%02u ", (unsigned)fx);
                if (strncmp(line, key, strlen(key))) return fail("Invalid FX order");
                value = strstr(line + strlen(key), " ENABLED=");
                if (!value || !parseInt(value + 9, 0, 1, number)) return fail("Invalid FX ENABLED");
                candidate.effects[fx].enabled = number != 0;
                part = 1; index = 0;
            } else {
                if (part == 1 && index >= k) { part = 2; index = 0; }
                if (part == 2 && index >= d) return fail("Internal FX parser state");
                snprintf(key, sizeof(key), "FX%02u %c%02u ", (unsigned)fx,
                         part == 1 ? 'K' : 'D', (unsigned)index);
                if (strncmp(line, key, strlen(key))) return fail("Invalid FX parameter order");
                value = strrchr(line + strlen(key), '=');
                if (!value || !parseInt(value + 1, 0, 255, number)) return fail("Invalid FX parameter value");
                if (part == 1) candidate.effects[fx].knobs[index] = (uint8_t)number;
                else candidate.effects[fx].dropdowns[index] = (uint8_t)number;
                ++index;
            }
            // Select the next valid expected line, including FX with no parameters.
            if (part == 1 && index >= k) { part = 2; index = 0; }
            if (part == 2 && index >= d) {
                ++fx; part = 0; index = 0;
                if (fx == MAX_EFFECTS) stage = Stage::Eq;
            }
            break;
        }
        case Stage::Eq: {
            unsigned freq = 0, q = 0, enabled = 0;
            int gain = 0, tail = -1;
            unsigned pos = 99;
            if (sscanf(line, "EQ%u FREQ=%u GAIN=%d Q=%u ENABLED=%u%n",
                       &pos, &freq, &gain, &q, &enabled, &tail) != 5 ||
                tail < 0 || line[tail] || pos != eq || freq > 65535 ||
                gain < -128 || gain > 127 || q > 255 || enabled > 1) return fail("Invalid EQ point");
            candidate.eqPoints[eq].freq = (uint16_t)freq;
            candidate.eqPoints[eq].gain = (int8_t)gain;
            candidate.eqPoints[eq].q = (uint8_t)q;
            candidate.eqPoints[eq].enabled = enabled != 0;
            if (++eq == 12) stage = Stage::Crc;
            break;
        }
        case Stage::Crc: {
            if (strncmp(line, "CRC16=", 6) || strlen(line + 6) != 4) return fail("Missing CRC16");
            unsigned parsed = 0;
            for (int i = 6; i < 10; ++i) {
                int h = fromHex(line[i]); if (h < 0) return fail("Invalid CRC16");
                parsed = (parsed << 4) | (unsigned)h;
            }
            if (parsed != crc) return fail("CRC16 mismatch: paste incomplete or modified");
            stage = Stage::End; return Result::More;
        }
        case Stage::End:
            if (strcmp(line, kEnd)) return fail("Missing END_JAMMATE_PRESET");
            stage = Stage::Complete;
            return Result::Complete;
        default: return fail("Extra data after preset");
        }
        crc = crcAdd(crc, line);
        return Result::More;
    }
};
} // namespace JmSerialPreset
