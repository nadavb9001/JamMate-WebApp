#pragma once
// One staged file transfer for NAM, IR and MIDI. Flash is bounded; RAM use is
// independent of file size. Only a verified complete file can reach the DSP.
static constexpr uint32_t V8_RESOURCE_LIMIT=131072;
struct V8Resource {
 uint32_t id=0,total=0,crc=0,items=0,next=0,epoch=0;uint8_t kind=0;bool active=false,applying=false;
 char name[65]={};uint32_t touched=0;
} s_v8Resource;
static uint32_t s_v8ReadId=0,s_v8ReadCRC=0,s_v8ReadSize=0,s_v8ReadEpoch=0;static uint8_t s_v8ReadKind=0;
static uint32_t s_v8MidiOffset=0;static uint16_t s_v8MidiIndex=0;
static const char* v8Path(uint8_t kind){return kind==1?"/v8/nam.bin":kind==2?"/v8/ir.bin":"/v8/midi.bin";}
static uint32_t v8FileCRC(File& file){uint32_t crc=0xffffffff;uint8_t bytes[128];file.seek(0);while(file.available()){const size_t n=file.read(bytes,sizeof(bytes));if(!n)break;crc=crc32_update_buffer(crc,bytes,n);}return crc^0xffffffff;}
static void v8ResourceReply(uint32_t id,uint8_t status,uint8_t phase,uint32_t next){uint8_t p[10];JmBytes::put32(p,id);p[4]=status;p[5]=phase;JmBytes::put32(p+6,next);btManager.sendMessage(0x94,p,sizeof(p));}
static void v8Applied(uint8_t status){
 auto& r=s_v8Resource;if(!r.applying)return;
 v8ResourceReply(r.id,status?6:0,2,r.next);r.applying=false;r.active=false;s_v8Applying=false;s_v8StreamFile=false;
}
static void v8Domain(uint8_t op,const uint8_t* p,size_t n){static uint8_t record[1040];if(n>sizeof(record)-3)return;record[0]=op;JmBytes::put16(record+1,n);if(n)memcpy(record+3,p,n);processBLEData(record,n+3);}
static void v8ApplyResource(){
 auto& r=s_v8Resource;r.applying=true;s_v8Applying=true;s_v8ApplyError=0;
 File f=LittleFS.open(v8Path(r.kind),"r");if(!f||!dspSerialOn){f.close();v8Applied(3);return;}
 if(r.kind==1){
  uint8_t meta[74];JmBytes::put32(meta,r.items);JmBytes::put32(meta+4,r.crc);const size_t names=strlen(r.name);JmBytes::put16(meta+8,names);memcpy(meta+10,r.name,names);v8Domain(0x70,meta,names+10);
  static uint8_t block[1026];uint16_t index=0;
  while(!s_v8ApplyError&&f.available()){const size_t n=f.read(block+2,1024);if(!n){s_v8ApplyError=3;break;}JmBytes::put16(block,index++);v8Domain(0x72,block,n+2);}
  f.close();if(s_v8ApplyError){v8Applied(s_v8ApplyError);return;}v8Domain(0x74,nullptr,0);
 }else if(r.kind==2){
  f.close();
  if(!s_jm2Connected||!(s_jm2PeerCaps&JM2_CAP_IR)){v8Applied(5);return;}
  s_v8StreamFile=true;s_namExpectedBytes=r.total;s_namExpectedCrc=r.crc;s_namExpectedWeights=0;
  strncpy(s_namModelName,r.name,sizeof(s_namModelName)-1);s_jm2NamPending=true;
 }else{
  uint8_t meta[69];JmBytes::put32(meta,r.total);const size_t names=strlen(r.name);meta[4]=names;memcpy(meta+5,r.name,names);v8Domain(0x80,meta,5+names);
  f.close();s_v8MidiOffset=0;s_v8MidiIndex=0;
  if(!s_midiTransferActive)v8Applied(6);

 }
}
static void handleV8Resource(uint8_t op,const uint8_t* p,size_t n){
 auto& r=s_v8Resource;const uint32_t id=n>=4?JmBytes::u32(p):0;
 if(op==0x95){
  if(n!=11||p[4]<1||p[4]>3)return;const uint8_t kind=p[4];const uint32_t off=JmBytes::u32(p+5);const size_t count=std::min(size_t(1024),size_t(JmBytes::u16(p+9)));
  File f=LittleFS.open(v8Path(kind),"r");const uint32_t total=f?f.size():0;
  if(f&&(id!=s_v8ReadId||kind!=s_v8ReadKind||total!=s_v8ReadSize||btManager.session()!=s_v8ReadEpoch)){
    s_v8ReadId=id;s_v8ReadKind=kind;s_v8ReadSize=total;s_v8ReadEpoch=btManager.session();s_v8ReadCRC=v8FileCRC(f);
  }
  static uint8_t reply[18+1024];JmBytes::put32(reply,id);reply[4]=!f||off>total||!count?3:0;reply[5]=kind;JmBytes::put32(reply+6,total);JmBytes::put32(reply+10,off);JmBytes::put32(reply+14,f?s_v8ReadCRC:0);
  size_t bytes=0;if(!reply[4]&&f.seek(off))bytes=f.read(reply+18,std::min(count,size_t(total-off)));f.close();btManager.sendMessage(0x96,reply,18+bytes,true);return;
 }
 if(!id){v8ResourceReply(id,1,op==0x90?0:op==0x91?1:2,0);return;}
 if(op==0x90){
  if(n<18||p[4]<1||p[4]>3||!p[17]||p[17]>64||n!=size_t(18+p[17])){v8ResourceReply(id,1,0,0);return;}
  if(r.active&&r.id==id&&r.epoch==btManager.session()){v8ResourceReply(id,0,0,r.next);return;}
  if(r.active||r.applying||s_jm2NamPending||s_jm2NamFlight.active){v8ResourceReply(id,2,0,0);return;}
  const uint32_t total=JmBytes::u32(p+5),items=JmBytes::u32(p+13);
  if(!total||total>V8_RESOURCE_LIMIT||(p[4]==1&&(items!=1871||total!=1871*4))){v8ResourceReply(id,1,0,0);return;}
  LittleFS.mkdir("/v8");File f=LittleFS.open("/v8/incoming.tmp","w");if(!f){v8ResourceReply(id,3,0,0);return;}f.close();
  r={};r.id=id;r.kind=p[4];r.total=total;r.crc=JmBytes::u32(p+9);r.items=items;r.epoch=btManager.session();memcpy(r.name,p+18,p[17]);r.active=true;r.touched=millis();v8ResourceReply(id,0,0,0);return;
 }
 if(!r.active||r.id!=id||r.epoch!=btManager.session()){v8ResourceReply(id,1,op==0x91?1:2,0);return;}
 r.touched=millis();
 if(op==0x93){if(r.applying){v8ResourceReply(id,2,3,r.next);return;}LittleFS.remove("/v8/incoming.tmp");r.active=false;v8ResourceReply(id,0,3,r.next);return;}
 if(op==0x91){
  if(n<9||n>1032||r.applying){v8ResourceReply(id,1,1,r.next);return;}const uint32_t off=JmBytes::u32(p+4);const size_t count=n-8;
  if(off<r.next&&off+count<=r.next){File f=LittleFS.open("/v8/incoming.tmp","r");static uint8_t check[1024];bool same=f&&f.seek(off)&&f.read(check,count)==count&&!memcmp(check,p+8,count);f.close();v8ResourceReply(id,same?0:1,1,r.next);return;}
  if(off!=r.next||count>r.total-r.next){v8ResourceReply(id,1,1,r.next);return;}
  File f=LittleFS.open("/v8/incoming.tmp","a");bool ok=f&&f.write(p+8,count)==count;f.close();if(ok)r.next+=count;v8ResourceReply(id,ok?0:3,1,r.next);return;
 }
 if(op==0x92){
  if(n!=4||r.applying){if(!r.applying)v8ResourceReply(id,1,2,r.next);return;}
  File f=LittleFS.open("/v8/incoming.tmp","r");const bool valid=f&&r.next==r.total&&f.size()==r.total&&v8FileCRC(f)==r.crc;f.close();
  if(!valid){v8ResourceReply(id,4,2,r.next);return;}
  // rename atomically replaces the previous complete resource after validation.
  if(!LittleFS.rename("/v8/incoming.tmp",v8Path(r.kind))){v8ResourceReply(id,3,2,r.next);return;}s_v8ReadId=0;v8ApplyResource();
 }
}
static void serviceV8Resources(){
 auto& r=s_v8Resource;
 if(r.applying&&r.kind==3){
  // A multiple of MSUB's 12 data bytes prevents padding between chunks.
  // One bounded DSP batch per loop keeps LCD and physical controls responsive.
  static uint8_t block[1010];File f=LittleFS.open(v8Path(3),"r");
  const size_t n=std::min(size_t(1008),size_t(r.total-s_v8MidiOffset));
  if(!dspSerialOn||!f||!f.seek(s_v8MidiOffset)||f.read(block+2,n)!=n){f.close();v8Applied(6);return;}f.close();
  JmBytes::put16(block,s_v8MidiIndex++);v8Domain(0x81,block,n+2);s_v8MidiOffset+=n;
  if(s_midiReceivedBytes!=s_v8MidiOffset){v8Applied(6);return;}
  if(s_v8MidiOffset==r.total){v8Domain(0x82,nullptr,0);v8Applied(0);}
 }
 if(r.active&&!r.applying&&(r.epoch!=btManager.session()||millis()-r.touched>120000)){LittleFS.remove("/v8/incoming.tmp");r.active=false;}
}
