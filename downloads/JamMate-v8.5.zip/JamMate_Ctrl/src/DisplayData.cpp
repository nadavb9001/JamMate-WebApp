#include "DisplayComponents.h"

// --- Fonts ---
const GFXfont& FONT_GENERAL_NORMAL = FreeSans9pt7b;
const GFXfont& FONT_GENERAL_BOLD = FreeSansBold9pt7b;
const GFXfont& FONT_PRESET_TITLE_NORMAL = FreeSans18pt7b;
const GFXfont& FONT_LOOPER_BIG = FreeSansBold24pt7b;

// --- Colors & Labels ---
const char* presetNames[TOTAL_BANKS] = { "CLEAN", "CRUNCH", "OVERDRV", "DISTORT", "MODUL", "CUSTM1", "CUSTM2" };
const char* fxLabels[TOTAL_FX] = { "GATE", "COMP", "AWAH", "OVRD", "DIST", "EQUL", "HARM", "VIBR", "CHOR", "OCTV", "FLNG", "PHAS", "TREM", "FIR ", "DELY", "NAM ", "RVRB", "GNRC" };
const uint16_t fxColors[7] = { TFT_ORANGE, TFT_ORANGE, TFT_ORANGE, TFT_ORANGE, TFT_ORANGE, TFT_ORANGE, TFT_ORANGE };
const char* extraLabels[TOTAL_EXTRA_BUTTONS] = { "Setup", "Looper", "Drum" };
const uint16_t extraColors[TOTAL_EXTRA_BUTTONS] = { TFT_DARKGREY, TFT_DARKGREY, TFT_DARKGREY };

// --- Button Implementation ---
void EnhancedRectButton::drawWithFont(TFT_eSPI& tft, const GFXfont* font) {
    int clearMargin = HIGHLIGHT_BORDER_THICKNESS;
    tft.fillRoundRect(x - clearMargin, y - clearMargin, w + 2 * clearMargin, h + 2 * clearMargin, radius + clearMargin, TFT_BLACK);
    tft.fillRoundRect(x, y, w, h, radius, bgColor);

    if (type == RECT_PROGRESS) {
        int fillW = map(progressValue, 0, 100, 0, w);
        tft.fillRoundRect(x, y, fillW, h, radius, progressColor);
    }

    tft.setTextDatum(MC_DATUM);
    tft.setFreeFont(font);

    if (type == RECT_PROGRESS) tft.setTextColor(TFT_RED);
    else tft.setTextColor(TFT_WHITE, bgColor);

    tft.drawString(label, x + w / 2, y + h / 2);

    if (highlighted) {
        for (int i = 0; i < HIGHLIGHT_BORDER_THICKNESS; ++i)
            tft.drawRoundRect(x - i, y - i, w + 2 * i, h + 2 * i, radius + i, TFT_RED);
    } else {
        tft.drawRoundRect(x, y, w, h, radius, borderColor);
    }
    
    if (type == RECT_SELECTION && selected) {
        tft.drawRoundRect(x + 2, y + 2, w - 4, h - 4, radius - 2, TFT_ORANGE);
    }
}

// ===================================================================
// STATIC PARAMETER DATA
// ===================================================================

// Compiled fallbacks match JmDefaultConfig.hpp and the bundled web config.
const char* cfgKnobs0[] = { "threshold_db", "hold", "attack", "release", "level" };
const char* cfgKnobs1[] = { "level", "ratio", "threshold", "attack", "release", "wet", "dry", "makeup" };
const char* cfgKnobs2[] = { "dry", "wet", "sensitivity", "Q", "base_freq", "sweep_span", "env_amount", "attack", "release", "detector_hpf", "drive", "output", "pedal", "lfo_rate", "formant_shift" };
const char* cfgDrops2[] = { "awah_mode", "awah_filter", "awah_vowel_a", "awah_vowel_b", "awah_pedal_mode", "awah_preset" };
const char* cfgOptions2_0[] = { "Filter", "Humanizer" };
const char* cfgOptions2_1[] = { "LowPass", "BandPass", "HighPass", "Notch", "LP+BP" };
const char* cfgOptions2_2[] = { "A", "E", "I", "O", "U" };
const char* cfgOptions2_3[] = { "A", "E", "I", "O", "U" };
const char* cfgOptions2_4[] = { "Off", "Wah", "Offset", "Depth" };
const char* cfgOptions2_5[] = { "Custom", "Classic Auto-Wah", "Funk Band-Pass", "Warm Bass LP", "Reverse Quack", "Broad Notch", "Bass/Synth LP+BP", "Pedal Wah", "Humanizer Wow", "Humanizer Talk LFO", "Bass Humanizer" };
const char** cfgOptionGroups2[] = { cfgOptions2_0, cfgOptions2_1, cfgOptions2_2, cfgOptions2_3, cfgOptions2_4, cfgOptions2_5 };
const uint8_t cfgOptionCounts2[] = { 2, 5, 5, 5, 4, 11 };
const char* cfgKnobs3[] = { "level", "drive", "type", "PreLPF", "PreHPF", "PostLPF", "PostHPF", "midFreq", "Mid", "Blend" };
const char* cfgDrops3[] = { "dist_type", "ovrd_brand" };
const char* cfgOptions3_0[] = { "Exp", "Soft", "Hard", "High Gain", "Fuzz", "Assymetric", "Multi Stage", "Tube Amp", "BitCrunch" };
const char* cfgOptions3_1[] = { "TubeScreamer", "Blues Driver", "Klon", "ODR1" };
const char** cfgOptionGroups3[] = { cfgOptions3_0, cfgOptions3_1 };
const uint8_t cfgOptionCounts3[] = { 9, 4 };
const char* cfgKnobs4[] = { "level", "drive", "type", "PreLPF", "PreHPF", "PostLPF", "PostHPF", "midFreq", "Mid", "blend" };
const char* cfgDrops4[] = { "dist_type", "dist_brand" };
const char* cfgOptions4_0[] = { "Exp", "Soft", "Hard", "High Gain", "Fuzz", "Assymetric", "Multi Stage", "Tube Amp", "BitCrunch" };
const char* cfgOptions4_1[] = { "Rat", "DS2", "MetalZone", "MXR+", "BigMuff" };
const char** cfgOptionGroups4[] = { cfgOptions4_0, cfgOptions4_1 };
const uint8_t cfgOptionCounts4[] = { 9, 5 };
const char* cfgKnobs5[] = { "level", "hpf", "100", "200", "400", "800", "1600", "3200", "lpf", "q" };
const char* cfgDrops5[] = { "eq_type", "eq_freq_scale" };
const char* cfgOptions5_0[] = { "Neutral", "Mid Scoop", "Mid Boost", "Bass Boost", "Treble Boost" };
const char* cfgOptions5_1[] = { "100%", "75%", "50%", "125%", "150%" };
const char** cfgOptionGroups5[] = { cfgOptions5_0, cfgOptions5_1 };
const uint8_t cfgOptionCounts5[] = { 5, 5 };
const char* cfgKnobs6[] = { "Level", "Dry", "Wet1", "Wet2", "ArpegRate", "Gate", "Glide" };
const char* cfgDrops6[] = { "Scale", "Mode", "Harm1", "Harm2", "Arpg", "arpg_mode", "SynthType", "HarmonizerType", "SynthPreset", "DryTone" };
const char* cfgOptions6_0[] = { "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" };
const char* cfgOptions6_1[] = { "Major", "Minor", "Harmonic Minor", "Melodic Minor", "Lydian", "Mixolydian", "Phrygian", "Dorian", "Locrian" };
const char* cfgOptions6_2[] = { "-12", "-2", "-3", "-4", "-5", "-6", "2", "3", "4", "5", "6", "12" };
const char* cfgOptions6_3[] = { "-12", "-2", "-3", "-4", "-5", "-6", "2", "3", "4", "5", "6", "12" };
const char* cfgOptions6_4[] = { "None", "Pitched delay", "Triad up", "Triad down", "Up-down", "Full scale up", "Full scale down", "Triad loop", "Seventh chord", "Fifth bounce", "Octave jumps", "Zigzag ascent", "Triad bounce", "Harmony alternating", "Harmony switch", "Chord triad climb", "Chord open triad", "Seventh weave", "Vivaldi run", "Vivaldi pedal" };
const char* cfgOptions6_5[] = { "none", "Loop", "Env", "Loop+Env" };
const char* cfgOptions6_6[] = { "Guitar", "Analog", "Hammond", "Pipe Organ", "Strings", "Brass", "Choir", "Celesta" };
const char* cfgOptions6_7[] = { "Harmonizer", "Pitch Shifter" };
const char* cfgOptions6_8[] = { "Generic", "Dreams", "Shade", "Jump", "Take", "Cars", "Monday", "Countdown" };
const char* cfgOptions6_9[] = { "Guitar", "Synth" };
const char** cfgOptionGroups6[] = { cfgOptions6_0, cfgOptions6_1, cfgOptions6_2, cfgOptions6_3, cfgOptions6_4, cfgOptions6_5, cfgOptions6_6, cfgOptions6_7, cfgOptions6_8, cfgOptions6_9 };
const uint8_t cfgOptionCounts6[] = { 12, 9, 12, 12, 20, 4, 8, 2, 8, 2 };
const char* cfgKnobs7[] = { "rate", "depth", "flutter" };
const char* cfgKnobs8[] = { "level", "rate", "depth", "delay", "feedback", "wet", "dry" };
const char* cfgKnobs9[] = { "dry", "wet", "pedal" };
const char* cfgDrops9[] = { "shift_semitone", "shift_direction", "shift_pedal_mode" };
const char* cfgOptions9_0[] = { "detune", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "24" };
const char* cfgOptions9_1[] = { "up", "down" };
const char* cfgOptions9_2[] = { "Off", "Free", "Half", "Full", "Snap" };
const char** cfgOptionGroups9[] = { cfgOptions9_0, cfgOptions9_1, cfgOptions9_2 };
const uint8_t cfgOptionCounts9[] = { 14, 2, 5 };
const char* cfgKnobs10[] = { "level", "rate", "depth", "feedback", "delay" };
const char* cfgKnobs11[] = { "level", "lfoFreq", "lfoDepth", "freq", "feedback", "wet", "dry" };
const char* cfgDrops11[] = { "phaser_poles" };
const char* cfgOptions11_0[] = { "1", "2", "3", "4" };
const char** cfgOptionGroups11[] = { cfgOptions11_0 };
const uint8_t cfgOptionCounts11[] = { 4 };
const char* cfgKnobs12[] = { "level", "depth", "rate", "midFreq" };
const char* cfgDrops12[] = { "tremolo_mode", "waveform" };
const char* cfgOptions12_0[] = { "vintage", "harmonic" };
const char* cfgOptions12_1[] = { "Sine", "Triangle", "Saw", "Square" };
const char** cfgOptionGroups12[] = { cfgOptions12_0, cfgOptions12_1 };
const uint8_t cfgOptionCounts12[] = { 2, 4 };
const char* cfgKnobs13[] = { "level", "treble", "mid", "bass", "presence", "gain", "gain1" };
const char* cfgDrops13[] = { "amp_type", "tone_type", "ir_points", "ir_type", "ir_file" };
const char* cfgOptions13_0[] = { "None", "Fender 65", "Twin Reverb", "Marshall", "Orange", "Mesa", "EVH", "Friedman", "VOX", "Bassman", "Custom" };
const char* cfgOptions13_1[] = { "None", "Slash", "Mesa Gain", "Princetone", "Master", "Black", "Stevie", "Crunch", "Rock70" };
const char* cfgOptions13_2[] = { "256", "512", "1024", "2048", "4096", "8192" };
const char* cfgOptions13_3[] = { "FIR", "FFT", "Part Conv" };
const char* cfgOptions13_4[] = { "1", "2", "3" };
const char** cfgOptionGroups13[] = { cfgOptions13_0, cfgOptions13_1, cfgOptions13_2, cfgOptions13_3, cfgOptions13_4 };
const uint8_t cfgOptionCounts13[] = { 11, 9, 6, 3, 3 };
const char* cfgKnobs14[] = { "level", "feedback", "time", "LPF", "dry", "wet", "depth", "rate", "ser-par" };
const char* cfgDrops14[] = { "delay_type", "division", "delay-multi" };
const char* cfgOptions14_0[] = { "Digital", "Echo", "Tape", "Multi", "Modulated", "PingPong", "Ducking" };
const char* cfgOptions14_1[] = { "1/32", "1/16", "1/16t", "1/16d", "1/8", "1/8t", "1/8d", "1/4", "1/4t", "1/4d", "1/2", "1" };
const char* cfgOptions14_2[] = { "1", "2", "3" };
const char** cfgOptionGroups14[] = { cfgOptions14_0, cfgOptions14_1, cfgOptions14_2 };
const uint8_t cfgOptionCounts14[] = { 7, 12, 3 };
const char* cfgKnobs15[] = { "level", "pre_att" };
const char* cfgDrops15[] = { "NAM_Model" };
const char* cfgOptions15_0[] = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25" };
const char** cfgOptionGroups15[] = { cfgOptions15_0 };
const uint8_t cfgOptionCounts15[] = { 25 };
const char* cfgKnobs16[] = { "level", "feedback", "damp", "dry", "wet", "tone", "predelay", "depth", "rate", "size", "diffusion", "er" };
const char* cfgDrops16[] = { "ReverbEngine", "ReverbType" };
const char* cfgOptions16_0[] = { "Dattorro", "FDN", "Vintage" };
const char* cfgOptions16_1[] = { "None", "Room", "Hall", "Plate", "Spring", "Pads" };
const char** cfgOptionGroups16[] = { cfgOptions16_0, cfgOptions16_1 };
const uint8_t cfgOptionCounts16[] = { 3, 6 };
const char* cfgKnobs17[] = { "level", "par1", "par2", "par3", "par4", "par5", "par6", "par7", "par8", "par9" };
const char* cfgDrops17[] = { "generic1", "generic2" };
const char* cfgOptions17_0[] = { "A1", "B1", "C1", "D1", "E1" };
const char* cfgOptions17_1[] = { "A2", "B2", "C2", "D2", "E2" };
const char** cfgOptionGroups17[] = { cfgOptions17_0, cfgOptions17_1 };
const uint8_t cfgOptionCounts17[] = { 5, 5 };
FxLayout fxLayouts[TOTAL_FX] = {
  { 5, cfgKnobs0, 0, nullptr, nullptr, nullptr },
  { 8, cfgKnobs1, 0, nullptr, nullptr, nullptr },
  { 15, cfgKnobs2, 6, cfgDrops2, cfgOptionGroups2, cfgOptionCounts2 },
  { 10, cfgKnobs3, 2, cfgDrops3, cfgOptionGroups3, cfgOptionCounts3 },
  { 10, cfgKnobs4, 2, cfgDrops4, cfgOptionGroups4, cfgOptionCounts4 },
  { 10, cfgKnobs5, 2, cfgDrops5, cfgOptionGroups5, cfgOptionCounts5 },
  { 7, cfgKnobs6, 10, cfgDrops6, cfgOptionGroups6, cfgOptionCounts6 },
  { 3, cfgKnobs7, 0, nullptr, nullptr, nullptr },
  { 7, cfgKnobs8, 0, nullptr, nullptr, nullptr },
  { 3, cfgKnobs9, 3, cfgDrops9, cfgOptionGroups9, cfgOptionCounts9 },
  { 5, cfgKnobs10, 0, nullptr, nullptr, nullptr },
  { 7, cfgKnobs11, 1, cfgDrops11, cfgOptionGroups11, cfgOptionCounts11 },
  { 4, cfgKnobs12, 2, cfgDrops12, cfgOptionGroups12, cfgOptionCounts12 },
  { 7, cfgKnobs13, 5, cfgDrops13, cfgOptionGroups13, cfgOptionCounts13 },
  { 9, cfgKnobs14, 3, cfgDrops14, cfgOptionGroups14, cfgOptionCounts14 },
  { 2, cfgKnobs15, 1, cfgDrops15, cfgOptionGroups15, cfgOptionCounts15 },
  { 12, cfgKnobs16, 2, cfgDrops16, cfgOptionGroups16, cfgOptionCounts16 },
  { 10, cfgKnobs17, 2, cfgDrops17, cfgOptionGroups17, cfgOptionCounts17 }
};
