#pragma once
#include "PresetBinary_v2.hpp"
#include <algorithm>

// Reading existing flash is deliberately separate from validating new writes.
// Older v3 files store their own record widths. They must remain readable when
// the current UI adds parameters; no legacy file is rewritten during a read.
namespace PresetBlobReader {
inline bool decode(const uint8_t* data,size_t size,const uint8_t layout[18][2],Preset& result,bool& legacy){
  if(!data||size<4||data[0]!=3||size_t(data[3])+4>size)return false;
  Preset parsed{};legacy=false;
  parsed.bpm=data[1];parsed.masterVolume=data[2];
  const size_t nameLength=std::min(size_t(data[3]),size_t(PRESET_NAME_LENGTH-1));
  memcpy(parsed.name,data+4,nameLength);
  for(auto& point:parsed.eqPoints){point.freq=440;point.q=14;}
  size_t offset=4+data[3];uint32_t seen=0;
  while(offset<size){
    if(size-offset<2)return false;
    const uint8_t id=data[offset++],count=data[offset++];
    if(id==0xfe){
      if(count>12||offset+size_t(count)*5!=size||!seen)return false;
      for(unsigned i=0;i<count;i++,offset+=5){auto& p=parsed.eqPoints[i];p.freq=data[offset]|uint16_t(data[offset+1])<<8;p.gain=int8_t(data[offset+2]);p.q=data[offset+3];p.enabled=data[offset+4]!=0;}
      break;
    }
    if(id>=18||!count||count>1+MAX_EFFECT_KNOBS+MAX_EFFECT_DROPDOWNS||offset+count>size||(seen&(1u<<id)))return false;
    seen|=1u<<id;
    uint8_t knobs=layout[id][0],drops=layout[id][1];
    if(count!=1+knobs+drops){
      legacy=true;
      // Historical firmware widths: retain the original knob/drop boundary.
      if(id==2&&count==13){knobs=9;drops=3;}
      else if(id==2&&count==8){knobs=7;drops=0;}
      else if(id==6&&count==14){knobs=7;drops=6;}
      else if(id==6&&count==11){knobs=6;drops=4;}
      else if(id==9&&count==8){knobs=5;drops=2;}
      else if(id==13&&count==12){knobs=6;drops=5;}
      else if(id==16&&count==13){knobs=10;drops=2;}
      else {knobs=std::min(uint8_t(count-1),knobs);drops=std::min(uint8_t(count-1-knobs),drops);}
    }
    parsed.effects[id].enabled=data[offset]!=0;
    for(uint8_t i=0;i<knobs&&i<MAX_EFFECT_KNOBS;i++)parsed.effects[id].knobs[i]=data[offset+1+i];
    for(uint8_t i=0;i<drops&&i<MAX_EFFECT_DROPDOWNS;i++)parsed.effects[id].dropdowns[i]=data[offset+1+knobs+i];
    offset+=count;
  }
  if(!seen)return false;
  result=parsed;return true;
}
}
