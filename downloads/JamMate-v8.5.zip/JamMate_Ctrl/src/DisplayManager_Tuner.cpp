#include "DisplayManager.h"
#include "JmTunerPortrait.hpp"
#include "BluetoothManager_binary.hpp"
#include <math.h>
#include <stdio.h>

extern void sendToDSP(const char cmd[4], uint8_t* payload, size_t len);

void DisplayManager::toggleTuner(bool enable) {
  if (enable) {
    currentState = STATE_TUNER;
    currentFreq = 0;
    currentNote = "--";
    currentCents = 0;
    currentOctave = 0;
    lastTunerPacketMs = millis();
    lastTunerUpdate = 0;
    drawTunerScreen();
  } else if (currentState == STATE_TUNER) {
    currentState = STATE_MAIN_MENU;
    drawMainScreen();
  }
}

bool DisplayManager::isTunerActive() { return currentState == STATE_TUNER; }

void DisplayManager::updateTuner(float freq) {
  if (currentState != STATE_TUNER) return;
  const uint32_t now = millis();
  lastTunerPacketMs = now;
  if (now - lastTunerUpdate < 33) return; // cap redraw near 30 Hz to reduce SPI load
  // Avoid redrawing a full pitch panel for sub-resolution changes.
  if (isfinite(freq) && isfinite(currentFreq) && fabsf(freq-currentFreq) < 0.08f) return;
  calculatePitch(freq);
  drawTunerDynamic();
  lastTunerUpdate = now;
}

void DisplayManager::calculatePitch(float freq) {
  currentFreq = freq;
  if (!isfinite(freq) || freq < 20.0f) {
    currentFreq = 0;
    currentNote = "--";
    currentCents = 0;
    currentOctave = 0;
    return;
  }
  static const char* names[] = {"C","C#","D","D#","E","F","F#","G","G#","A","A#","B"};
  const float midi = 12.0f * log2f(freq / 440.0f) + 69.0f;
  const int n = (int)lroundf(midi);
  int idx = n % 12;
  if (idx < 0) idx += 12;
  currentNote = names[idx];
  currentOctave = ((n - idx) / 12) - 1;
  currentCents = (int)lroundf((midi - n) * 100.f);
}

void DisplayManager::handleTunerMode() {
  if (encoder1.isLongClick() || encoder1.isButtonPressed()) {
    uint8_t payload[5] = {2, 0, 0, 0, 0};
    sendToDSP("UTIL",payload,sizeof(payload));
    toggleTuner(false);
    return;
  }
  // UART / pitch detection may stop without an explicit zero-frequency packet.
  if (currentFreq >= 20.0f && (uint32_t)(millis()-lastTunerPacketMs)>800) {
    currentFreq=0;currentNote="--";currentCents=0;currentOctave=0;
    drawTunerDynamic();
  }
}

void DisplayManager::drawTunerScreen() {
  JmTunerPortrait::Model m{};
  m.note=currentNote.c_str(); m.octave=currentOctave;
  m.frequency=currentFreq;m.cents=currentCents;m.cpu=lastDspCpuPercent;
  JmTunerPortrait::draw(tft,m);
  beatLedLastAppearance=-1;
  drawBeatLed(true);
}

void DisplayManager::drawTunerDynamic() {
  JmTunerPortrait::Model m{};
  m.note=currentNote.c_str();m.octave=currentOctave;
  m.frequency=currentFreq;m.cents=currentCents;m.cpu=lastDspCpuPercent;
  static TFT_eSprite sprite(&tft);
  static bool initialized=false,available=false;
  if(!initialized){initialized=true;sprite.setColorDepth(8);
    available=sprite.createSprite(240,258)!=nullptr;}
  if(available){JmTunerPortrait::dynamicSprite(sprite,m);sprite.pushSprite(0,32);}
  else JmTunerPortrait::dynamic(tft,m);
}
