#pragma once
#include "BluetoothA2DPSink.h"
#include "BaselineBleStream.hpp"
#include <atomic>
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLE2902.h>
#include "esp_gap_bt_api.h"
#include "driver/i2s.h"
#define USE_MIDI 0
#define BLE_SERVICE_UUID "6e400001-b5a3-f393-e0a9-e50e24dcca9f"
#define BLE_CHARACTERISTIC_UUID "6e400002-b5a3-f393-e0a9-e50e24dcca9f"
class BluetoothManager {
public:
 using BLEDataCallback=bool(*)(uint8_t*,size_t);
 void begin(const char* name="JamMate",bool audio=true){
  if(audio)setupA2DP("JamMate Audio");
  BLEDevice::init(name);BLEDevice::setMTU(517);BLEDevice::setPower(ESP_PWR_LVL_P9);
  auto* server=BLEDevice::createServer();server->setCallbacks(new ServerCallbacks(this));
  auto* service=server->createService(BLE_SERVICE_UUID);
  auto* control=service->createCharacteristic(BLE_CHARACTERISTIC_UUID,
    BLECharacteristic::PROPERTY_WRITE|BLECharacteristic::PROPERTY_WRITE_NR|BLECharacteristic::PROPERTY_READ|BLECharacteristic::PROPERTY_NOTIFY);
  control->addDescriptor(new BLE2902());control->setCallbacks(new WriteCallbacks(this));
  const uint8_t empty=0;control->setValue(const_cast<uint8_t*>(&empty),0);service->start();
  advertising=BLEDevice::getAdvertising();advertising->addServiceUUID(BLE_SERVICE_UUID);advertising->setScanResponse(true);advertising->start();
  Serial.println("[BLE] baseline single-characteristic control ready; no ESP notifications");
 }
 void setA2DPPinConfig(const i2s_pin_config_t& pins){a2dp_sink.set_pin_config(pins);}
 void setBLEDataCallback(BLEDataCallback cb){callback=cb;}
 void setCurrentPreset(Preset*){}
 void triggerMidiConnectionAttempt(){Serial.println("[MIDI] disabled");}
 void enableA2DP(){if(!a2dpEnabled)setupA2DP("JamMate Audio");}
 void disableA2DP(){if(a2dpEnabled){a2dp_sink.end();a2dpEnabled=false;}}
 void setA2DPvolume(uint8_t v){if(a2dpEnabled)a2dp_sink.set_volume(v);}
 bool isA2DPStreaming()const{return a2dpEnabled;}
 bool connected()const{return link.load();}
 uint32_t session()const{return generation.load();}
 // DSP/LCD call sites remain valid; all ESP-to-web application traffic is off.
 bool sendMessage(uint8_t,const uint8_t*,size_t,bool=false){return false;}
 void sendBLEData(const uint8_t*,size_t){}
 void sendBLEBlob(uint8_t,const uint8_t*,size_t,int=-1){}
private:
 BluetoothA2DPSink a2dp_sink;bool a2dpEnabled=false;BLEDataCallback callback=nullptr;
 BLEAdvertising* advertising=nullptr;std::atomic_bool link{false};std::atomic<uint32_t> generation{0};BaselineBleStream stream;
 class ServerCallbacks:public BLEServerCallbacks{
  BluetoothManager* m;
 public:explicit ServerCallbacks(BluetoothManager* p):m(p){}
  void onConnect(BLEServer*,esp_ble_gatts_cb_param_t* p)override{
   m->stream.reset();m->generation++;m->link=true;
   esp_ble_conn_update_params_t c={};memcpy(c.bda,p->connect.remote_bda,6);c.min_int=40;c.max_int=60;c.latency=0;c.timeout=1000;esp_ble_gap_update_conn_params(&c);
   Serial.println("[BLE] WebApp connected");
  }
  void onDisconnect(BLEServer*)override{m->link=false;m->generation++;m->stream.reset();m->advertising->start();Serial.println("[BLE] WebApp disconnected; advertising");}
 };
 class WriteCallbacks:public BLECharacteristicCallbacks{
  BluetoothManager* m;
 public:explicit WriteCallbacks(BluetoothManager* p):m(p){}
  void onWrite(BLECharacteristic*,esp_ble_gatts_cb_param_t* p)override{
   if(!m->link||!p||p->write.is_prep)return;
   m->stream.accept(p->write.value,p->write.len,millis(),[&](uint8_t* bytes,size_t n){
    if(!m->callback||!m->callback(bytes,n))Serial.println("[BLE] Command queue busy; command not applied");
   });
  }
 };
  static void a2dpConnectionCallback(esp_a2d_connection_state_t state, void* obj) {
    const char* stateStr[] = {"Disconnected", "Connecting", "Connected", "Disconnecting"};
    Serial.printf("[A2DP] Connection state: %s\n", stateStr[state]);
  }

  void setupA2DP(const char* name) {
    a2dp_sink.set_task_core(1);
    a2dp_sink.set_task_priority(10);
    a2dp_sink.set_on_connection_state_changed(a2dpConnectionCallback, this);
    i2s_config_t i2s_config = {
      .mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_TX),
      .sample_rate = 44100,
      .bits_per_sample = I2S_BITS_PER_SAMPLE_16BIT,
      .channel_format = I2S_CHANNEL_FMT_RIGHT_LEFT,
      .communication_format = I2S_COMM_FORMAT_STAND_I2S,
      .intr_alloc_flags = 0,
      .dma_buf_count = 16,
      .dma_buf_len = 128,
      .use_apll = false,
      .tx_desc_auto_clear = true
    };
    a2dp_sink.set_i2s_config(i2s_config);
    a2dp_sink.start(name);
    a2dpEnabled = true;
    esp_bt_cod_t cod;
    cod.major = 0b00100;
    cod.minor = 0b000100;
    cod.service = 0b0010000000;
    esp_bt_gap_set_cod(cod, ESP_BT_INIT_COD);
  }

};
