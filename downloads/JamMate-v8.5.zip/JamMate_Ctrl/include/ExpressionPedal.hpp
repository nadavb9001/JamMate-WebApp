#ifndef EXPRESSION_PEDAL_HPP
#define EXPRESSION_PEDAL_HPP

#include <Arduino.h>

struct PedalConfig {
    uint8_t pin = 36;
    uint8_t smoothSamples = 8;
    uint8_t deadband = 5;
    uint16_t updateRateHz = 100;
    float minVoltage = 0.0f;
    float maxVoltage = 3.3f;
};

class ExpressionPedal {
public:
    enum ResponseCurve {
        LINEAR,
        LOG,
        EXP,
        S_CURVE
    };

private:
    static const int MAX_SAMPLES = 32;
    
    PedalConfig cfg_;
    uint16_t buffer_[MAX_SAMPLES];  // FIXED: Static array instead of pointer
    uint32_t sum_;
    uint8_t index_;
    
    uint16_t rawLast_;
    uint16_t smooth_;
    float value_;
    ResponseCurve curve_;
    
    unsigned long lastReadTime_;
    
    const uint16_t ADC_MAX = 4095;
    
    float adcToNormalized(uint16_t adc) {
        float voltage = (adc / (float)ADC_MAX) * 3.3f;
        float normalized = (voltage - cfg_.minVoltage) / (cfg_.maxVoltage - cfg_.minVoltage);
        normalized = constrain(normalized, 0.0f, 1.0f);
        
        switch(curve_) {
            case LOG:
                normalized = log10(1.0f + normalized * 9.0f);
                break;
            case EXP:
                normalized = (exp(normalized) - 1.0f) / (exp(1.0f) - 1.0f);
                break;
            case S_CURVE:
                normalized = (tanh((normalized - 0.5f) * 4.0f) + 1.0f) / 2.0f;
                break;
            case LINEAR:
            default:
                break;
        }
        
        return normalized;
    }

public:
    // Default constructor for global declaration
    ExpressionPedal() 
        : sum_(0), index_(0), rawLast_(0), smooth_(0), 
          value_(0.0f), curve_(LINEAR), lastReadTime_(0) {
        memset(buffer_, 0, sizeof(buffer_));
        cfg_ = PedalConfig();
    }
    
    // Config constructor
    ExpressionPedal(const PedalConfig& config) 
        : cfg_(config), sum_(0), index_(0), rawLast_(0), smooth_(0), 
          value_(0.0f), curve_(LINEAR), lastReadTime_(0) {
        
        if(cfg_.smoothSamples > MAX_SAMPLES) cfg_.smoothSamples = MAX_SAMPLES;
        if(cfg_.smoothSamples < 1) cfg_.smoothSamples = 1;
        
        memset(buffer_, 0, sizeof(buffer_));
    }
    
    // CRITICAL: Use this instead of assignment operator
    void setConfig(const PedalConfig& config) {
        cfg_ = config;
        
        if(cfg_.smoothSamples > MAX_SAMPLES) cfg_.smoothSamples = MAX_SAMPLES;
        if(cfg_.smoothSamples < 1) cfg_.smoothSamples = 1;
        
        memset(buffer_, 0, sizeof(buffer_));
        sum_ = 0;
        index_ = 0;
    }
    
    void begin() {
        pinMode(cfg_.pin, INPUT);
        
        // CRITICAL: Pre-fill buffer to avoid ramp-up from zero
        uint16_t initialRead = analogRead(cfg_.pin);
        
        for(int i = 0; i < cfg_.smoothSamples; i++) {
            buffer_[i] = initialRead;
        }
        
        sum_ = initialRead * cfg_.smoothSamples;
        smooth_ = initialRead;
        rawLast_ = initialRead;
        value_ = adcToNormalized(initialRead);
        
        lastReadTime_ = millis();
        
        Serial.print("[Pedal] Initialized on pin ");
        Serial.print(cfg_.pin);
        Serial.print(", initial ADC: ");
        Serial.println(initialRead);
    }
    
    bool update() {
    unsigned long now = millis();
    if(now - lastReadTime_ < (1000 / cfg_.updateRateHz)) {
        return false;
    }
    lastReadTime_ = now;
    
    // NEW: Take 5 samples and use median (rejects spikes)
    uint16_t samples[5];
    for(int i = 0; i < 5; i++) {
        samples[i] = analogRead(cfg_.pin);
        delayMicroseconds(100);
    }
    
    // Sort and take median
    for(int i = 0; i < 4; i++) {
        for(int j = i + 1; j < 5; j++) {
            if(samples[j] < samples[i]) {
                uint16_t temp = samples[i];
                samples[i] = samples[j];
                samples[j] = temp;
            }
        }
    }
    uint16_t raw = samples[2];  // Middle value
    rawLast_ = raw;
    
    // Existing moving average
    sum_ -= buffer_[index_];
    buffer_[index_] = raw;
    sum_ += raw;
    index_ = (index_ + 1) % cfg_.smoothSamples;
    
    uint16_t smoothed = sum_ / cfg_.smoothSamples;
    
    // Increased deadband check
    if(abs((int)smoothed - (int)smooth_) > cfg_.deadband) {
        smooth_ = smoothed;
        
        float newValue = adcToNormalized(smooth_);
        
        // Only update if change is significant
        if(abs(newValue - value_) > 0.005f) {  // Was 0.001f
            value_ = newValue;
            return true;
        }
    }
    
    return false;
}

    
    // Getters
    uint16_t getRaw() const { return rawLast_; }
    uint16_t getSmooth() const { return smooth_; }
    float getValue() const { return value_; }
    uint8_t getMidiCC() const { return (uint8_t)(value_ * 127.0f); }
    uint8_t getPercent() const { return (uint8_t)(value_ * 100.0f); }
    
    void setResponseCurve(ResponseCurve curve) { 
        curve_ = curve; 
        value_ = adcToNormalized(smooth_);
    }
    
    // Debug helper
    void printDebug() {
        Serial.println("\n=== Pedal Debug ===");
        Serial.print("Buffer: [");
        for(int i = 0; i < cfg_.smoothSamples; i++) {
            Serial.print(buffer_[i]);
            if(i < cfg_.smoothSamples - 1) Serial.print(", ");
        }
        Serial.println("]");
        Serial.print("Sum: "); Serial.println(sum_);
        Serial.print("Expected: "); Serial.println(sum_ / cfg_.smoothSamples);
        Serial.println("==================\n");
    }
};

#endif
