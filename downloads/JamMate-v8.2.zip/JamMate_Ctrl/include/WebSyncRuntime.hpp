#pragma once
#include "JmWebSyncProtocol.hpp"
#include "JmDefaultConfig.hpp"
#include <atomic>

struct BleCommand { uint8_t* data; size_t size; uint32_t epoch; uint8_t slot; };
static QueueHandle_t s_bleCommands=nullptr;
static uint8_t s_webDrumGrid[144]={};
static uint16_t s_webGridRevision=0;
static uint32_t s_webReadyEpoch=0;
static uint8_t s_webUsbMode=1;
static uint8_t s_commandSmall[4][1100],s_commandLarge[2051];
static std::atomic_bool s_commandBusy[5]{};

static void webSlotPath(uint8_t bank,uint8_t slot,char* out,size_t n){
  snprintf(out,n,bank<5?"/presets/f_%u_%u.bin":"/presets/c_%u_%u.bin",bank<5?bank:bank-5,slot);
}
static bool writeVerifiedFile(const char* path,const uint8_t* bytes,size_t n){
  const char* temp="/.web-write.tmp";
  File f=LittleFS.open(temp,"w");if(!f)return false;
  const size_t written=f.write(bytes,n);f.close();
  if(written!=n){LittleFS.remove(temp);return false;}
  f=LittleFS.open(temp,"r");bool ok=f&&f.size()==n;
  uint8_t check[96];size_t off=0;
  while(ok&&off<n){size_t k=std::min(sizeof(check),n-off);ok=f.read(check,k)==k&&!memcmp(check,bytes+off,k);off+=k;}
  f.close();
  if(!ok||!LittleFS.rename(temp,path)){LittleFS.remove(temp);return false;}
  return true;
}
static void ensureWebConfig(){
  if(!LittleFS.exists("/config.json"))
    writeVerifiedFile("/config.json",(const uint8_t*)g_webDefaultConfig,strlen(g_webDefaultConfig));
}
// Small, browser-paced reads: do not burst a 3 KiB reply into the controller's
// notification queue. Each page has explicit offset, total and whole-file CRC.
static void sendWebConfigPage(uint16_t offset,uint16_t requested){
  File f=LittleFS.open("/config.json","r");
  const size_t total=f&&f.size()<=4096?f.size():0;
  uint8_t scan[96];uint16_t crc=0xffff;size_t remaining=total;
  while(remaining){
    const size_t n=std::min(sizeof(scan),remaining);
    if(f.read(scan,n)!=n){f.close();return;}
    for(size_t i=0;i<n;i++){crc^=scan[i];for(int bit=0;bit<8;bit++)crc=(crc&1)?(crc>>1)^0xa001:crc>>1;}
    remaining-=n;
  }
  uint8_t payload[7+96]={2};
  JmWebSync::put16(payload+1,total);JmWebSync::put16(payload+3,offset);JmWebSync::put16(payload+5,crc);
  size_t n=offset<total?std::min(size_t(96),std::min(size_t(requested),total-offset)):0;
  if(n&&(!f.seek(offset)||f.read(payload+7,n)!=n)){f.close();return;}
  f.close();
  if(offset==0||offset+n==total)Serial.printf("[WEB] Config page offset=%u bytes=%u total=%u crc=%04x\n",offset,unsigned(n),unsigned(total),crc);
  btManager.sendBLEBlob(0x55,payload,n+7);
}
static void receiveWebConfig(const uint8_t* p,size_t n){
  static String pending;
  static uint16_t next=0,last=0xffff,lastCrc=0,committedCrc=0;
  static bool active=false;
  const uint16_t index=JmWebSync::get16(p),chunkCrc=JmWebSync::crc16(p,n);
  uint8_t status=0;
  if(index==last && chunkCrc==lastCrc){
    // Duplicate of the most recently acknowledged chunk is idempotent.
  }else{
    if(index==0){pending="";next=0;active=true;committedCrc=0;}
    if(!active||index!=next||pending.length()+n-3>4096||p[2]>1)status=2;
    else{
      for(size_t i=3;i<n;i++)pending+=(char)p[i];
      if(p[2]){
        uint8_t layout[18][2];
        if(!JmWebSync::validateConfig(pending.c_str(),pending.length(),layout))status=3;
        else if(!writeVerifiedFile("/config.json",(const uint8_t*)pending.c_str(),pending.length()))status=1;
        else{
          loadFxLayoutFromConfig();
          committedCrc=JmWebSync::crc16((const uint8_t*)pending.c_str(),pending.length());
        }
        active=false;
      }
      if(!status){last=index;lastCrc=chunkCrc;next++;}
    }
  }
  uint8_t ack[6]={0x53,status};JmWebSync::put16(ack+2,index);JmWebSync::put16(ack+4,committedCrc);
  btManager.sendBLEData(ack,sizeof(ack));
}
static bool validWebPreset(const uint8_t* b,size_t n){
  if(n<4||n>MAX_BLOB_SIZE||b[0]!=3||b[3]>=PRESET_NAME_LENGTH||size_t(b[3])+4>n)return false;
  size_t off=4+b[3];uint32_t seen=0;
  while(off<n){
    if(n-off<2)return false;
    uint8_t id=b[off++],count=b[off++];
    if(id==0xfe)return count<=12 && off+size_t(count)*5==n && seen==0x3ffff;
    if(id>=18||(seen&(1u<<id))||count!=1+FX_LAYOUT[id][0]+FX_LAYOUT[id][1]||off+count>n)return false;
    seen|=1u<<id;off+=count;
  }
  return seen==0x3ffff;
}
static void presetAck(uint8_t cmd,uint8_t status,uint8_t bank,uint8_t slot){
  uint8_t bytes[]={0x59,cmd,status,bank,slot};btManager.sendBLEData(bytes,sizeof(bytes));
}
static size_t webReadSlot(uint8_t bank,uint8_t slot,uint8_t* bytes){
  // Cache normalized blobs, with a fixed volume: global volume is not preset data.
  Preset preset{};
  if(!loadPreset(bank,slot,preset))return 0;
  preset.masterVolume=20;
  return serializeStructToBlob(preset,bytes);
}
static void sendWebCatalog(){
  // These helpers run only on loop(), never concurrently in BLE callbacks.
  // Keep bulk buffers out of the 8 KiB Arduino task stack.
  static uint8_t catalog[2+35*6]={1,35};uint8_t* const bytes=blobBuffer;
  for(uint8_t b=0;b<7;b++)for(uint8_t s=0;s<5;s++){
    size_t n=webReadSlot(b,s,bytes),o=2+(b*5+s)*6;
    catalog[o]=b;catalog[o+1]=s;JmWebSync::put16(catalog+o+2,n);
    JmWebSync::put16(catalog+o+4,JmWebSync::crc16(bytes,n));
  }
  btManager.sendBLEBlob(0x38,catalog,sizeof(catalog));
}
static void sendWebSlot(uint8_t bank,uint8_t slot){
  if(!JmWebSync::validSlot(bank,slot))return;
  static uint8_t bytes[MAX_BLOB_SIZE+2];bytes[0]=bank;bytes[1]=slot;size_t n=webReadSlot(bank,slot,bytes+2);
  if(n)btManager.sendBLEBlob(0x3a,bytes,n+2);
}
void sendWebSnapshot(bool force){
  if(!btManager.connected()||s_webReadyEpoch!=btManager.session())return;
  force=force||btManager.needsSnapshot();
  uint16_t cpu;
  if(s_cpuTelemetry.take(millis(),btManager.session(),cpu)){
    uint8_t data[2];JmWebSync::put16(data,cpu);if(!btManager.sendMessage(0x48,data,sizeof(data)))s_cpuTelemetry.sent=false;
  }
  static bool initialized=false;
  static uint8_t selection[4],controls[18];
  static uint16_t presetCrc=0;
  static uint8_t previousSystem[11]={};
  static Preset previous{};
  uint8_t system[]={uint8_t(state.a2dpEnabled),uint8_t(display.btAudioVol),s_webUsbMode,uint8_t(dspSerialOn),
    uint8_t(display.noiseEnabled),uint8_t(display.noiseLevel),uint8_t(display.toneEnabled),uint8_t(display.toneLevel),
    uint8_t(display.toneFreq),uint8_t(display.toneFreq>>8),uint8_t(presetsLocked)};
  if(force||!initialized||memcmp(system,previousSystem,sizeof(system))){memcpy(previousSystem,system,sizeof(system));btManager.sendMessage(0x49,system,sizeof(system));}
  uint8_t selected[]={currentPreset.bank,currentPreset.number,state.volume,currentPreset.bpm};
  const bool presetSelected=!initialized||memcmp(selection,selected,2);
  const bool selectionChanged=!initialized||memcmp(selection,selected,4);
  if(force||selectionChanged){
    memcpy(selection,selected,4);uint8_t frame[5]={0x3f};memcpy(frame+1,selected,4);btManager.sendBLEData(frame,5);
  }
  uint8_t values[]={uint8_t(display.drumEnabled),uint8_t(display.drumLevel),uint8_t(display.drumStyle),
    uint8_t(display.drumPattern),uint8_t(currentPreset.bpm),uint8_t(display.looperEnabled),uint8_t(display.looperLevel),
    uint8_t(display.looperSync),uint8_t(display.looperAutoArm),uint8_t(display.looperBars),uint8_t(display.looperNum),
    uint8_t(display.looperPlayMode),uint8_t(display.looperBounce),display.looperMute,display.looperSolo,display.drumFill,
    uint8_t(display.isTunerActive()),uint8_t(display.bypassEnabled)};
  if(force||!initialized||memcmp(values,controls,18)){
    memcpy(controls,values,18);uint8_t frame[19]={0x3e};memcpy(frame+1,values,18);btManager.sendBLEData(frame,19);
  }
  uint8_t* const bytes=blobBuffer;size_t n=serializeStructToBlob(currentPreset,bytes);
  const uint16_t crc=JmWebSync::crc16(bytes,n);
  if(force||presetSelected||strcmp(previous.name,currentPreset.name)){
    btManager.sendBLEBlob(0x34,bytes,n);
  }else if(crc!=presetCrc){
    unsigned changes=0;
    for(uint8_t fx=0;fx<18;fx++){
      changes+=previous.effects[fx].enabled!=currentPreset.effects[fx].enabled;
      for(uint8_t k=0;k<FX_LAYOUT[fx][0];k++)changes+=previous.effects[fx].knobs[k]!=currentPreset.effects[fx].knobs[k];
      for(uint8_t d=0;d<FX_LAYOUT[fx][1];d++)changes+=previous.effects[fx].dropdowns[d]!=currentPreset.effects[fx].dropdowns[d];
    }
    if(changes>12)btManager.sendBLEBlob(0x34,bytes,n);
    else for(uint8_t fx=0;fx<18;fx++){
      const auto& now=currentPreset.effects[fx];const auto& old=previous.effects[fx];
      unsigned effectChanges=now.enabled!=old.enabled;
      for(uint8_t k=0;k<FX_LAYOUT[fx][0];k++)effectChanges+=now.knobs[k]!=old.knobs[k];
      for(uint8_t d=0;d<FX_LAYOUT[fx][1];d++)effectChanges+=now.dropdowns[d]!=old.dropdowns[d];
      if(effectChanges>1){
        uint8_t data[29];data[0]=fx;data[1]=1+FX_LAYOUT[fx][0]+FX_LAYOUT[fx][1];data[2]=now.enabled;
        memcpy(data+3,now.knobs,FX_LAYOUT[fx][0]);memcpy(data+3+FX_LAYOUT[fx][0],now.dropdowns,FX_LAYOUT[fx][1]);
        btManager.sendMessage(0x27,data,2+data[1]);continue;
      }
      for(uint8_t flat=0;flat<=FX_LAYOUT[fx][0]+FX_LAYOUT[fx][1];flat++){
        uint8_t v=flat==0?now.enabled:flat<=FX_LAYOUT[fx][0]?now.knobs[flat-1]:now.dropdowns[flat-FX_LAYOUT[fx][0]-1];
        uint8_t before=flat==0?old.enabled:flat<=FX_LAYOUT[fx][0]?old.knobs[flat-1]:old.dropdowns[flat-FX_LAYOUT[fx][0]-1];
        if(v!=before){uint8_t frame[]={0x36,fx,flat,v};btManager.sendBLEData(frame,sizeof(frame));}
      }
    }
    for(uint8_t b=0;b<12;b++)if(memcmp(&previous.eqPoints[b],&currentPreset.eqPoints[b],sizeof(EQPoint))){
      const auto& point=currentPreset.eqPoints[b];uint8_t frame[]={0x22,b,uint8_t(point.enabled),0,0,uint8_t(point.gain),point.q};
      JmWebSync::put16(frame+3,point.freq);btManager.sendBLEData(frame,sizeof(frame));
    }
  }
  presetCrc=crc;previous=currentPreset;
  if(force&&s_webGridRevision)btManager.sendBLEBlob(0x57,s_webDrumGrid,144);
  initialized=true;
}
void serviceWebSync(){
  static uint32_t last=0;static bool wasConnected=false;
  if(!btManager.connected()||s_webReadyEpoch!=btManager.session()){wasConnected=false;return;}
  if(wasConnected&&millis()-last<200)return;
  last=millis();sendWebSnapshot(!wasConnected);wasConnected=true;
}
