#pragma once
// Canonical wire layout; checked against the web configuration by cross-repository tests.
static const char g_webDefaultConfig[] = R"JMCFG(GATE|threshold_db,hold,attack,release,level||
COMP|level,ratio,threshold,attack,release,wet,dry,makeup||
AWAH|dry,wet,sensitivity,Q,base_freq,sweep_span,env_amount,attack,release,detector_hpf,drive,output,pedal,lfo_rate,formant_shift|awah_mode,awah_filter,awah_vowel_a,awah_vowel_b,awah_pedal_mode,awah_preset|Filter:Humanizer;LowPass:BandPass:HighPass:Notch:LP+BP;A:E:I:O:U;A:E:I:O:U;Off:Wah:Offset:Depth;Custom:Classic Auto-Wah:Funk Band-Pass:Warm Bass LP:Reverse Quack:Broad Notch:Bass/Synth LP+BP:Pedal Wah:Humanizer Wow:Humanizer Talk LFO:Bass Humanizer
OVRD|level,drive,type,PreLPF,PreHPF,PostLPF,PostHPF,midFreq,Mid,Blend|dist_type,ovrd_brand|Exp:Soft:Hard:High Gain:Fuzz:Assymetric:Multi Stage:Tube Amp:BitCrunch;TubeScreamer:Blues Driver:Klon:ODR1
DIST|level,drive,type,PreLPF,PreHPF,PostLPF,PostHPF,midFreq,Mid,blend|dist_type,dist_brand|Exp:Soft:Hard:High Gain:Fuzz:Assymetric:Multi Stage:Tube Amp:BitCrunch;Rat:DS2:MetalZone:MXR+:BigMuff
EQUL|level,hpf,100,200,400,800,1600,3200,lpf,q|eq_type,eq_freq_scale|Neutral:Mid Scoop:Mid Boost:Bass Boost:Treble Boost;100%:75%:50%:125%:150%
HARM|Level,Dry,Wet1,Wet2,ArpegRate,Gate,Glide|Scale,Mode,Harm1,Harm2,Arpg,arpg_mode,SynthType,HarmonizerType,SynthPreset,DryTone|C:C#:D:D#:E:F:F#:G:G#:A:A#:B;Major:Minor:Harmonic Minor:Melodic Minor:Lydian:Mixolydian:Phrygian:Dorian:Locrian;-12:-2:-3:-4:-5:-6:2:3:4:5:6:12;-12:-2:-3:-4:-5:-6:2:3:4:5:6:12;None:Pitched delay:Triad up:Triad down:Up-down:Full scale up:Full scale down:Triad loop:Seventh chord:Fifth bounce:Octave jumps:Zigzag ascent:Triad bounce:Harmony alternating:Harmony switch:Chord triad climb:Chord open triad:Seventh weave:Vivaldi run:Vivaldi pedal;none:Loop:Env:Loop+Env;Guitar:Analog:Hammond:Pipe Organ:Strings:Brass:Choir:Celesta;Harmonizer:Pitch Shifter;Generic:Dreams:Shade:Jump:Take:Cars:Monday:Countdown;Guitar:Synth
VIBR|rate,depth,flutter||
CHOR|level,rate,depth,delay,feedback,wet,dry||
OCTV|dry,wet,pedal|shift_semitone,shift_direction,shift_pedal_mode|detune:1:2:3:4:5:6:7:8:9:10:11:12:24;up:down;Off:Free:Half:Full:Snap
FLNG|level,rate,depth,feedback,delay||
PHAS|level,lfoFreq,lfoDepth,freq,feedback,wet,dry|phaser_poles|1:2:3:4
TREM|level,depth,rate,midFreq|tremolo_mode,waveform|vintage:harmonic;Sine:Triangle:Saw:Square
_FIR|level,treble,mid,bass,presence,gain,gain1|amp_type,tone_type,ir_points,ir_type,ir_file|None:Fender 65:Twin Reverb:Marshall:Orange:Mesa:EVH:Friedman:VOX:Bassman:Custom;None:Slash:Mesa Gain:Princetone:Master:Black:Stevie:Crunch:Rock70;256:512:1024:2048:4096:8192;FIR:FFT:Part Conv;1:2:3
DELY|level,feedback,time,LPF,dry,wet,depth,rate,ser-par|delay_type,division,delay-multi|Digital:Echo:Tape:Multi:Modulated:PingPong:Ducking;1/32:1/16:1/16t:1/16d:1/8:1/8t:1/8d:1/4:1/4t:1/4d:1/2:1;1:2:3
_NAM|level,pre_att|NAM_Model|1:2:3:4:5:6:7:8:9:10:11:12:13:14:15:16:17:18:19:20:21:22:23:24:25
RVRB|level,feedback,damp,dry,wet,tone,predelay,depth,rate,size,diffusion,er|ReverbEngine,ReverbType|Dattorro:FDN:Vintage;None:Room:Hall:Plate:Spring:Pads
GNRC|level,par1,par2,par3,par4,par5,par6,par7,par8,par9|generic1,generic2|A1:B1:C1:D1:E1;A2:B2:C2:D2:E2)JMCFG";
