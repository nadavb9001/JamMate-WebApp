#pragma once
#include "BluetoothA2DPSink.h"
#include "JmWebSyncProtocol.hpp"
#include "JmV8.hpp"
#include <atomic>
#include <algorithm>
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLE2902.h>
#include "esp_gap_bt_api.h"
#include "driver/i2s.h"
#define USE_MIDI 0
#define BLE_SERVICE_UUID "8a8e0001-8a8e-4800-8000-4a616d4d6174"
#define BLE_CHARACTERISTIC_UUID "8a8e0002-8a8e-4800-8000-4a616d4d6174"
#define BLE_NOTIFY_UUID "8a8e0003-8a8e-4800-8000-4a616d4d6174"

class BluetoothManager {
public:
 using BLEDataCallback=bool(*)(uint8_t*,size_t);
 void begin(const char* name="JamMate v8",bool audio=true){
  if(audio)setupA2DP("JamMate Audio");
  BLEDevice::init(name);BLEDevice::setMTU(247);BLEDevice::setPower(ESP_PWR_LVL_P9);
  instance=this;BLEDevice::setCustomGattsHandler(observeGatts);
  notifyMutex=xSemaphoreCreateMutex();controlQueue=xQueueCreate(16,sizeof(Outgoing));bulkQueue=xQueueCreate(16,sizeof(Outgoing));
  server=BLEDevice::createServer();server->setCallbacks(new ServerCallbacks(this));
  auto* service=server->createService(BLE_SERVICE_UUID);
  rxChar=service->createCharacteristic(BLE_CHARACTERISTIC_UUID,BLECharacteristic::PROPERTY_WRITE|BLECharacteristic::PROPERTY_WRITE_NR);
  txChar=service->createCharacteristic(BLE_NOTIFY_UUID,BLECharacteristic::PROPERTY_NOTIFY);
  txChar->addDescriptor(new BLE2902());rxChar->setCallbacks(new WriteCallbacks(this));service->start();
  advertising=BLEDevice::getAdvertising();advertising->addServiceUUID(BLE_SERVICE_UUID);advertising->setScanResponse(true);advertising->setMinPreferred(0x06);advertising->setMaxPreferred(0x0c);
  if(!notifyMutex||!controlQueue||!bulkQueue||xTaskCreate(senderTask,"V8TX",4096,this,2,nullptr)!=pdPASS){Serial.println("[V8] transport initialization failed");return;}
  advertising->start();Serial.println("[V8] binary BLE ready");
 }
 void setA2DPPinConfig(const i2s_pin_config_t& pins){a2dp_sink.set_pin_config(pins);}
 void setBLEDataCallback(BLEDataCallback cb){callback=cb;}
 void setCurrentPreset(Preset*){}
 void triggerMidiConnectionAttempt(){Serial.println("[MIDI] disabled");}
 void enableA2DP(){if(!a2dpEnabled)setupA2DP("JamMate Audio");}
 void disableA2DP(){if(a2dpEnabled){a2dp_sink.end();a2dpEnabled=false;}}
 void setA2DPvolume(uint8_t v){if(a2dpEnabled)a2dp_sink.set_volume(v);}
 bool isA2DPStreaming()const{return a2dpEnabled;}
 bool connected()const{return link&&wireSession.load()!=0;}
 uint32_t session()const{return generation.load();}
 void tick(){}
 bool needsSnapshot(){return snapshotFailed.exchange(false);}
 // Domain messages share one queue/transfer engine. No unframed BLE path exists.
 bool sendMessage(uint8_t op,const uint8_t* p,size_t n,bool bulk=false){
  if(!connected()||n>JmV8::MAX)return false;
  auto* copy=(uint8_t*)malloc(n+3);if(!copy){snapshotFailed=true;return false;}
  copy[0]=op;JmV8::put16(copy+1,n);if(n)memcpy(copy+3,p,n);
  return enqueue({copy,n+3,generation.load()},bulk||n>200);
 }
 void sendBLEData(const uint8_t* p,size_t n){
  if(!n)return;
  if(p[0]==0x35&&n==7&&p[1]==4&&p[2]==0)sendMessage(p[0],p+3,4);
  else sendMessage(p[0],p+1,n-1);
 }
 void sendBLEBlob(uint8_t op,const uint8_t* p,size_t n,int version=-1){
  if(version<0){sendMessage(op,p,n);return;}
  if(n+1>JmV8::MAX)return;
  auto* copy=(uint8_t*)malloc(n+4);if(!copy){snapshotFailed=true;return;}copy[0]=op;JmV8::put16(copy+1,n+1);copy[3]=version;if(n)memcpy(copy+4,p,n);
  enqueue({copy,n+4,generation.load()},n>200);
 }
private:
 struct Outgoing{uint8_t* data;size_t size;uint32_t epoch;};
 BLEServer* server=nullptr;BLECharacteristic* rxChar=nullptr;BLECharacteristic* txChar=nullptr;BLEAdvertising* advertising=nullptr;
 BluetoothA2DPSink a2dp_sink;bool a2dpEnabled=false;BLEDataCallback callback=nullptr;
 std::atomic_bool snapshotFailed{false};
 std::atomic_bool link{false};std::atomic<uint32_t> generation{0},wireSession{0},lastAck{0};
 QueueHandle_t controlQueue=nullptr,bulkQueue=nullptr;SemaphoreHandle_t notifyMutex=nullptr;
 JmV8::Receiver receiver;uint16_t txId=0;
 std::atomic<uint16_t> activeTx{0},sentThrough{0};std::atomic<uint8_t> activeOp{0};
 esp_gatt_if_t gattsIf=ESP_GATT_IF_NONE;std::atomic<uint16_t> connection{0xffff};
 std::atomic<uint32_t> notifyFailures{0},notifyCode{0};
 inline static BluetoothManager* instance=nullptr;
 inline static volatile uint16_t mtu=23;
 inline static volatile bool congested=false;
 static void observeGatts(esp_gatts_cb_event_t e,esp_gatt_if_t interface,esp_ble_gatts_cb_param_t* p){
  // Bind to CREATE for this exact service UUID, never the last registered app.
  if(instance&&e==ESP_GATTS_CREATE_EVT&&p->create.status==ESP_GATT_OK&&BLEUUID(p->create.service_id.id.uuid).equals(BLEUUID(BLE_SERVICE_UUID))){
   instance->gattsIf=interface;Serial.printf("[V8] service interface=%u handle=%u\n",unsigned(interface),unsigned(p->create.service_handle));
  }
  if(!instance||interface!=instance->gattsIf)return;
  if(e==ESP_GATTS_MTU_EVT&&p->mtu.conn_id==instance->connection)mtu=p->mtu.mtu;
  if(e==ESP_GATTS_CONGEST_EVT)congested=p->congest.congested;
 }
 static void release(Outgoing& p){free(p.data);}
 bool enqueue(Outgoing p,bool bulk){
  const auto q=bulk?bulkQueue:controlQueue;
  if(!connected()||!q||xQueueSend(q,&p,0)!=pdTRUE){snapshotFailed=true;release(p);return false;}return true;
 }
 bool notify(uint8_t* p,size_t n){
  if(!link||congested||!notifyMutex||gattsIf==ESP_GATT_IF_NONE)return false;
  if(xSemaphoreTake(notifyMutex,pdMS_TO_TICKS(100))!=pdTRUE)return false;
  // Arduino 2.x notify() copies an unlocked peer map. Use the server-owned
  // interface and CONNECT event's ID instead; SDK copies bytes before return.
  bool ok=false;
  if(link&&n>=JmV8::HEADER&&JmV8::u32(p+12)==wireSession.load()){
   const esp_err_t result=esp_ble_gatts_send_indicate(gattsIf,connection.load(),txChar->getHandle(),n,p,false);
   ok=result==ESP_OK;if(!ok){notifyFailures++;notifyCode=uint32_t(result);}
  }
  xSemaphoreGive(notifyMutex);return ok;
 }
 void transmit(const Outgoing& p){
  if(p.size<3||p.size>JmV8::MAX+3||p.epoch!=generation||!connected())return;
  const uint8_t op=p.data[0];const auto* data=p.data+3;const uint16_t total=p.size-3;
  uint16_t id=++txId;if(!id)id=++txId;
  const auto session=wireSession.load();const auto crc=JmV8::crc16(data,total);
  const size_t att=std::max(size_t(20),std::min(size_t(244),size_t(mtu>23?mtu-3:20))),chunk=att-JmV8::HEADER;
  uint16_t offset=0;unsigned failures=0;bool empty=total==0,finished=false;activeTx=id;activeOp=op;sentThrough=0;lastAck=0;
  do{
   const uint16_t base=offset;uint16_t end=offset;uint8_t bytes[244];empty=total==0;
   // A bounded four-fragment window; each valid fragment carries a cumulative ACK.
   for(unsigned w=0;w<4&&(end<total||empty)&&connected()&&generation==p.epoch;w++){
    const size_t count=std::min(chunk,size_t(total-end));JmV8::header(bytes,JmV8::DATA,op,id,end,total,crc,session);
    if(count)memcpy(bytes+JmV8::HEADER,data+end,count);
    sentThrough=end+count;
    if(!notify(bytes,JmV8::HEADER+count))break;
    end+=count;empty=false;
   }
   const uint32_t started=millis();
   while(connected()&&generation==p.epoch&&millis()-started<1000){
    const uint32_t ack=lastAck.load();const uint16_t next=ack;
    if(uint16_t(ack>>16)==id&&next<=end){if(next==0&&end){offset=0;break;}if(next>=base){offset=next;if(offset==end)break;}}
    delay(1);
   }
   finished=total?offset==total:uint16_t(lastAck.load()>>16)==id;
   if(!finished&&offset==base){if(++failures>=4)break;}else failures=0;
  }while(!finished&&connected()&&generation==p.epoch);
  if(!finished&&connected()&&generation==p.epoch){
   Serial.printf("[V8] delivery stalled op=%02x offset=%u/%u ack=%u:%u notifyErrors=%lu code=%lu mtu=%u; closing session\n",op,offset,total,unsigned(lastAck.load()>>16),unsigned(lastAck.load()&65535),static_cast<unsigned long>(notifyFailures.load()),static_cast<unsigned long>(notifyCode.load()),unsigned(mtu));
   server->disconnect(connection.load());
  }
  activeTx=0;
 }
 static void senderTask(void* ptr){
  auto* self=(BluetoothManager*)ptr;Outgoing p;
  for(;;){
   if(xQueueReceive(self->controlQueue,&p,0)==pdTRUE||xQueueReceive(self->bulkQueue,&p,pdMS_TO_TICKS(2))==pdTRUE){self->transmit(p);release(p);}
  }
 }
 class ServerCallbacks:public BLEServerCallbacks{
  BluetoothManager* m;
 public:explicit ServerCallbacks(BluetoothManager* x):m(x){}
  void onConnect(BLEServer*,esp_ble_gatts_cb_param_t* p)override{
   m->generation++;m->wireSession=0;m->receiver.reset();m->connection=p->connect.conn_id;m->link=true;mtu=23;congested=false;
   esp_ble_conn_update_params_t c={};memcpy(c.bda,p->connect.remote_bda,6);c.min_int=6;c.max_int=12;c.latency=0;c.timeout=600;esp_ble_gap_update_conn_params(&c);
   Serial.println("[V8] connected; awaiting session");
  }
  void onDisconnect(BLEServer*)override{m->link=false;m->connection=0xffff;m->wireSession=0;m->generation++;m->receiver.reset();m->advertising->start();Serial.println("[V8] disconnected; advertising");}
 };
 class WriteCallbacks:public BLECharacteristicCallbacks{
  BluetoothManager* m;
 public:explicit WriteCallbacks(BluetoothManager* x):m(x){}
  void onWrite(BLECharacteristic*,esp_ble_gatts_cb_param_t* e)override{
   if(!e||e->write.is_prep)return;const auto* p=e->write.value;const size_t n=e->write.len;
   if(n==20&&p[0]==0xd8&&p[1]==8&&p[2]==JmV8::HELLO&&JmV8::u32(p+12)&&!m->wireSession){
    m->wireSession=JmV8::u32(p+12);m->receiver.reset();
    uint8_t caps[4]={8,4,0,0};JmV8::put16(caps+2,std::max(20,std::min(244,int(mtu)-3)));m->sendMessage(0,caps,4);return;
   }
   const uint32_t session=m->wireSession.load();if(!JmV8::valid(p,n,session))return;
   if(p[2]==JmV8::ACK&&n==JmV8::HEADER){
    const auto id=JmV8::u16(p+4),next=JmV8::u16(p+6);
    if(id==m->activeTx&&p[3]==m->activeOp&&next<=m->sentThrough)m->lastAck=uint32_t(id)<<16|next;
    return;
   }
   if(p[2]==JmV8::DATA&&(p[3]==0x21||p[3]==0x50||p[3]==0x70||p[3]==0x72||p[3]==0x74||p[3]==0x80||p[3]==0x81||p[3]==0x82))return;
   uint16_t next;const bool complete=m->receiver.accept(p,n,session,next);
   if(complete&&(!m->callback||!m->callback(m->receiver.bytes,m->receiver.total+3))){
    // Never ACK a command that could not be queued. Abort instead of silently losing it.
    m->server->disconnect(m->connection.load());return;
   }
   if(next!=0xffff){uint8_t ack[JmV8::HEADER];JmV8::header(ack,JmV8::ACK,p[3],JmV8::u16(p+4),next,0,0,session);m->notify(ack,sizeof(ack));}
  }
 };
  static void a2dpConnectionCallback(esp_a2d_connection_state_t state, void* obj) {
    const char* stateStr[] = {"Disconnected", "Connecting", "Connected", "Disconnecting"};
    Serial.printf("[A2DP] Connection state: %s\n", stateStr[state]);
  }

  void setupA2DP(const char* name) {
    a2dp_sink.set_task_core(1);
    a2dp_sink.set_task_priority(10);
    a2dp_sink.set_on_connection_state_changed(a2dpConnectionCallback, this);
    i2s_config_t i2s_config = {
      .mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_TX),
      .sample_rate = 44100,
      .bits_per_sample = I2S_BITS_PER_SAMPLE_16BIT,
      .channel_format = I2S_CHANNEL_FMT_RIGHT_LEFT,
      .communication_format = I2S_COMM_FORMAT_STAND_I2S,
      .intr_alloc_flags = 0,
      .dma_buf_count = 16,
      .dma_buf_len = 128,
      .use_apll = false,
      .tx_desc_auto_clear = true
    };
    a2dp_sink.set_i2s_config(i2s_config);
    a2dp_sink.start(name);
    a2dpEnabled = true;
    esp_bt_cod_t cod;
    cod.major = 0b00100;
    cod.minor = 0b000100;
    cod.service = 0b0010000000;
    esp_bt_gap_set_cod(cod, ESP_BT_INIT_COD);
  }


};
