#pragma once
#include <TFT_eSPI.h>
#include <TJpg_Decoder.h>
#include "MyRotaryEncoder.h"
#include "PresetBinary_v2.hpp" 
#include "DisplayComponents.h"
#include "BeatVisualClock.hpp"

// --- External Hardware References ---
extern RotaryEncoder encoder1; 
extern RotaryEncoder encoder2; 
extern PushSwitch switch1;     
extern PushSwitch switch2;     
extern Preset currentPreset;   
extern bool dspSerialOn;
extern HardwareSerial dspSerial;

class DisplayManager {
public:
    DisplayManager();
    void begin();
    void loop();
    void refresh();
    
    // Global Actions
    void setVolume(uint8_t vol);
    void setTempo(uint8_t bpm);
    void highlightRect(int index, bool highlight);
    void drawPresetInfo();
    void checkExternalChanges();
    void handleGlobalInput();
    
    // Connection Status Flags (New)
    bool connUART;   // Top-Left
    bool connWeb;    // Top-Right
    bool connA2DP;   // Bottom-Left
    bool connMIDI;   // Bottom-Right

    // Bypass
    bool bypassEnabled;
    void toggleBypass(bool enable);
    
    // Tuner Actions
    void toggleTuner(bool enable);
    void updateTuner(float freq);
    bool isTunerActive();

    // The Display Object
    TFT_eSPI tft;

    // --- State Variables ---
    DisplayState currentState;
    int currentRectIndex;
    int lastEncoder1Pos;
    int lastEncoder2Pos;
    unsigned long lastSwitchTime;
    
    // Cached Data
    int currentPresetTypeIndex;
    int currentPresetNumber;
    uint8_t volumeValue;
    uint8_t bpmValue;
    bool fxEnabled[TOTAL_FX];
    bool looperEnabled;
    bool drumEnabled;
    
    // UI Elements
    RectButton* mainMenuButtons[TOTAL_MAIN_MENU_RECTS];

    // MAIN MENU STATE
    bool mainMenuAdjusting;
    char mainPresetNameCache[PRESET_NAME_LENGTH + 1];

    // --- Sub-State Data ---
    
    // LOOPER STATE
    // looperTrackState mirrors jm_looper TrackState: 0=IDLE,1=ARMED,2=WAITING,3=RECORDING,4=PLAYING
    int  looperTrackState;
    int  looperRectIndex;
    bool looperAdjusting;
    bool isRecording;           // true when looperTrackState == TS_RECORDING
    unsigned long loopStart, loopLength, lastStepTime;
    float currentArcAngle;   // current arc position in degrees (0–360)
    uint16_t lastArcColor;   // last color drawn — used to detect color changes
    unsigned long lastBpmBeat; // millis() of last beat onset (for dot blink)
    bool bpmBlinkOn;           // current blink state of the BPM dot
    int loopLayerCount;
    int lastDspCpuPercent = -1;  // latest LOAD sample, retained across STAT messages

    // DSP is the only beat authority. ESP uses millis() for between-beat
    // animation frames and stops extrapolating if BEAT messages disappear.
    BeatVisualClock beatClock;
    LooperBeatPhase  looperBeatPhase;
    void onDspBeat(const uint8_t* payload, size_t len);
    void drawBeatLed(bool force = false);
    int8_t beatLedLastAppearance;
    int beatLedLastScreen;
    bool drumTileNeedsRefresh;

    // Looper Parameters (jm_looper update_param byte map)
    int  looperLevel;           // master level 0-127  → data[15]
    int  looperNum;             // track select 0-3    → data[0]
    int  looperSync;            // 0=NONE,1=BEAT,2=BAR,3=DRUM_START → data[8]
    bool looperAutoArm;         // auto-arm enable     → data[11]
    int  looperBars;            // bars to record 0-16 → data[10]
    bool looperBounce=false;
    uint8_t looperMute=0,looperSolo=0,drumFill=0;
    int  looperPlayMode;        // 0=PARALLEL,1=SERIES → data[9]

    void applyLooperStateChange(int trigger, uint32_t loopMs = 0); // 0=REC,1=DSP_arm_fired,2=STOP,3=UNDO_CLEAR,4=DSP_loop_closed

    // DRUM STATE
    int drumRectIndex;
    bool drumAdjusting;
    int drumStyle, drumPattern, drumBPM, drumLevel;
    uint32_t lastDrumBeatFrameMs = 0;
    int lastDrumBeatKey = -1;

    // SETUP STATE 
    int setupRectIndex;
    bool setupAdjusting;
    int setupFirstVisible = 0;
    int setupConfirmIndex = -1;
    uint32_t setupConfirmDeadline = 0;
    
    bool noiseEnabled;
    int noiseLevel;
    
    bool toneEnabled;
    int toneLevel;
    int toneFreq;
    
    bool btAudioEnabled;
    int btAudioVol;
    
    // TUNER STATE
    float currentFreq;
    String currentNote;
    int currentCents;
    int currentOctave = 0;
    unsigned long lastTunerUpdate;
    unsigned long lastTunerPacketMs = 0;

    // OVERLAY MESSAGE STATE
    void showMessage(const char* msg);
    char overlayMsg[64];
    unsigned long overlayExpireAt;  // millis() when overlay should clear

    // STATUS LINE (bottom bar — LOAD / STAT messages from DSP)
    char statusLine[64];
    void drawStatusLine();
    void updateStatusLine(const char* msg);

    // FX EDIT STATE
    int fxGridIndex;
    int fxEditIndex;         
    int fxParamIndex;        
    bool fxParamAdjusting;
    int fxRenderedScroll = -1;
    // Independent dirty areas: ring, centre, beat, bar and selected track.
    // A 40ms animation tick never invalidates the full 226x157 panel.
    bool looperDynamicBaseReady = false;
    int looperLastProgressStep = -1;
    int looperLastState = -1;
    int looperLastLayers = -1;
    int looperLastBeat = -1;
    int looperLastMeter = -1;
    int looperLastBar = -1;
    int looperLastBarsConfig = -1;
    int looperLastTrack = -1;
    int looperLastParamValues[6] = {-1,-1,-1,-1,-1,-1};
    int looperLastParamSelected = -1;
    bool looperLastParamEditing = false;
    bool looperUiNeedsParameters = false;
    bool looperHeaderOverlay = false;
    uint32_t tunerLastPaintMs = 0;

    // --- Sub-State Handlers ---
    void handleMainMenu();
    void drawMainScreen();
    
    void handleLooperMode();
    void drawLooperScreen(bool full = true);
    void drawLooperSettings();
    void drawLooperDynamic(bool force = false);
    void updateLooperVisuals();
    void drawLooperControl(int idx, const char* label, String value, bool selected, bool adjusting);
    void drawLooperArc(float fromAngle, float toAngle, uint16_t color);
    void sendLooperPacket(int recBtn=0, int stopBtn=0, int clearBtn=0, int undoBtn=0, int redoBtn=0);

    void handleDrumMode();
    void drawDrumScreen();
    void drawDrumSettings();
    void updateDrumVisuals();
    void drawDrumControl(int idx, const char* label, String valueStr, bool isSelected, bool isAdjusting);
    
    void handleSetupMode();
    void drawSetupScreen(bool full = true, int previousIndex = -1, int previousFirst = -1);
    void sendSetupPacket(int type); 

    void handleTunerMode();
    void drawTunerScreen();
    void drawTunerDynamic();
    void calculatePitch(float freq);

    void handleFxGridMode();
    void drawFxGridScreen();
    void refreshFxTile(int cell);
    void refreshFxEffect(int dspIndex);
    void handleFxEditMode();
    void drawFxEditScreen(bool fullRedraw = true, int prevParamIndex = -1);
    void drawFxParamSlider(int index, const char* label, uint8_t value, bool selected, bool adjusting, bool partialUpdate = false);
    void drawFxParamDropdown(int index, const char* label, uint8_t value, bool selected, bool adjusting, bool partialUpdate = false);
};

extern DisplayManager display;