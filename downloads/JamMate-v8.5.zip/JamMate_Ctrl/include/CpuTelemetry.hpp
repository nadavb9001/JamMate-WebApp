#pragma once
#include <stdint.h>
#include <cmath>
// Event-driven CPU telemetry, tenths of a percent. No polling request is needed.
struct JmCpuTelemetry {
 bool known=false,sent=false;uint16_t latest=0,previous=0;uint32_t epoch=0,last=0;
 void sample(float percent){
  if(!std::isfinite(percent))return;
  percent=percent<0?0:percent>100?100:percent;latest=uint16_t(percent*10+0.5f);known=true;
 }
 bool take(uint32_t now,uint32_t connection,uint16_t& value){
  if(!known||!connection)return false;
  const bool fresh=!sent||epoch!=connection;
  if(!fresh&&(latest==previous||uint32_t(now-last)<2000))return false;
  value=previous=latest;epoch=connection;last=now;sent=true;return true;
 }
};
