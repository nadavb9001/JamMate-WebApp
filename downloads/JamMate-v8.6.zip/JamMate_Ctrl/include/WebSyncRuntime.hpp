#pragma once
#include "JmWebSyncProtocol.hpp"
#include "JmDefaultConfig.hpp"
#include "ByteUtils.hpp"
#include <atomic>

struct BleCommand { uint8_t* data; size_t size; uint32_t epoch; uint8_t slot; };
static QueueHandle_t s_bleCommands=nullptr;
static uint8_t s_webDrumGrid[144]={};
static uint16_t s_webGridRevision=0;
static uint32_t s_webReadyEpoch=0;
static uint8_t s_webUsbMode=1;
static uint8_t s_commandSmall[4][1100],s_commandLarge[2051];
static std::atomic_bool s_commandBusy[5]{};

static void webSlotPath(uint8_t bank,uint8_t slot,char* out,size_t n){
  snprintf(out,n,bank<5?"/presets/f_%u_%u.bin":"/presets/c_%u_%u.bin",bank<5?bank:bank-5,slot);
}
static bool writeVerifiedFile(const char* path,const uint8_t* bytes,size_t n){
  const char* temp="/.web-write.tmp";
  File f=LittleFS.open(temp,"w");if(!f)return false;
  const size_t written=f.write(bytes,n);f.close();
  if(written!=n){LittleFS.remove(temp);return false;}
  f=LittleFS.open(temp,"r");bool ok=f&&f.size()==n;
  uint8_t check[96];size_t off=0;
  while(ok&&off<n){size_t k=std::min(sizeof(check),n-off);ok=f.read(check,k)==k&&!memcmp(check,bytes+off,k);off+=k;}
  f.close();
  if(!ok||!LittleFS.rename(temp,path)){LittleFS.remove(temp);return false;}
  return true;
}
static void ensureWebConfig(){
  if(!LittleFS.exists("/config.json"))
    writeVerifiedFile("/config.json",(const uint8_t*)g_webDefaultConfig,strlen(g_webDefaultConfig));
}
static bool receiveWebConfig(const uint8_t* p,size_t n){
  static char pending[4097];static size_t pendingLength=0;
  static uint16_t next=0,last=0xffff,lastCrc=0,committedCrc=0;
  static bool active=false;static uint32_t epoch=0;
  if(n<3)return false;
  if(epoch!=btManager.session()){epoch=btManager.session();active=false;next=0;last=0xffff;committedCrc=0;pendingLength=0;}
  const uint16_t index=JmWebSync::get16(p),chunkCrc=JmWebSync::crc16(p,n);
  uint8_t status=0;
  if(index!=0 && index==last && chunkCrc==lastCrc){
    // Duplicate of the most recently acknowledged chunk is idempotent.
  }else{
    if(index==0){pendingLength=0;next=0;active=true;committedCrc=0;}
    if(!active||index!=next||pendingLength+n-3>4096||p[2]>1)status=2;
    else{
      memcpy(pending+pendingLength,p+3,n-3);pendingLength+=n-3;pending[pendingLength]=0;
      if(p[2]){
        uint8_t layout[18][2];
        if(!JmWebSync::validateConfig(pending,pendingLength,layout))status=3;
        else if(!writeVerifiedFile("/config.json",(const uint8_t*)pending,pendingLength))status=1;
        else{
          if(!applyFxConfigText(pending,pendingLength)||memcmp(FX_LAYOUT,layout,sizeof(layout)))status=4;
          else {committedCrc=JmWebSync::crc16((const uint8_t*)pending,pendingLength);}
        }
        active=false;
      }
      if(!status){last=index;lastCrc=chunkCrc;next++;}
    }
  }
  if(epoch!=btManager.session())return false; // never publish an old upload ACK into a new session
  Serial.printf("[CFG] Upload chunk %u status=%u final=%u\n",unsigned(index),unsigned(status),unsigned(p[2]));
  return p[2]&&status==0;

}
static bool validWebPreset(const uint8_t* b,size_t n){
  if(n<4||n>MAX_BLOB_SIZE||b[0]!=3||b[3]>=PRESET_NAME_LENGTH||size_t(b[3])+4>n)return false;
  size_t off=4+b[3];uint32_t seen=0;
  while(off<n){
    if(n-off<2)return false;
    uint8_t id=b[off++],count=b[off++];
    if(id==0xfe)return count<=12 && off+size_t(count)*5==n && seen==0x3ffff;
    if(id>=18||(seen&(1u<<id))||count!=1+FX_LAYOUT[id][0]+FX_LAYOUT[id][1]||off+count>n)return false;
    seen|=1u<<id;off+=count;
  }
  return seen==0x3ffff;
}
static bool decodeWebPreset(const uint8_t* bytes,size_t n,Preset& result){
 if(!validWebPreset(bytes,n))return false;
 bool legacy=false;return PresetBlobReader::decode(bytes,n,FX_LAYOUT,result,legacy)&&!legacy;
}

static void presetAck(uint8_t cmd,uint8_t status,uint8_t bank,uint8_t slot){
  uint8_t bytes[]={0x59,cmd,status,bank,slot};btManager.sendBLEData(bytes,sizeof(bytes));
}
static size_t webReadSlot(uint8_t bank,uint8_t slot,uint8_t* bytes){
  // Cache normalized blobs, with a fixed volume: global volume is not preset data.
  Preset preset{};
  if(!loadPreset(bank,slot,preset))return 0;
  preset.masterVolume=20;
  return serializeStructToBlob(preset,bytes);
}
// ESP-to-web configuration, catalog, state, CPU and telemetry are disabled.
static void sendWebCatalog(){}
static void sendWebSlot(uint8_t,uint8_t){}
void sendWebSnapshot(bool){}
void serviceWebSync(){}
