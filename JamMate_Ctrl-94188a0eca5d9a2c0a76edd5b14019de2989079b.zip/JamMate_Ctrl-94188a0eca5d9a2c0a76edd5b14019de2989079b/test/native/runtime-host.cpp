// Host adapters for the real WebSyncRuntime.hpp. No BLE, flash, display or DSP
// hardware is simulated as successful: only file/protocol helper logic is tested.
#include <cassert>
#include <algorithm>
#include <cstdint>
#include <cstring>
#include <string>
#include <vector>
#include <map>
#include <fstream>
struct Logger{template<class...T>void printf(const char*,T...){}void println(const char* =nullptr){}void print(const char*){}}Serial;
#include "PresetBinary_v2.hpp"
#include "JmWebSyncProtocol.hpp"
#include "JmDefaultConfig.hpp"
#include "PresetBlobReader.hpp"
#include "PresetSwitchCursor.hpp"
struct String {
 std::string value;
 String(){}String(const char* s):value(s){}String(std::string s):value(s){}
 size_t length()const{return value.size();}const char* c_str()const{return value.c_str();}
 String&operator+=(char c){value+=c;return *this;}
};
struct File {
 std::vector<uint8_t>* bytes=nullptr;size_t offset=0;bool writing=false,fail=false;
 explicit operator bool()const{return bytes;}
 size_t size()const{return bytes?bytes->size():0;}
 size_t write(const uint8_t* p,size_t n){if(!bytes||!writing||fail)return 0;bytes->insert(bytes->end(),p,p+n);return n;}
 size_t read(uint8_t* p,size_t n){if(!bytes)return 0;n=std::min(n,bytes->size()-offset);memcpy(p,bytes->data()+offset,n);offset+=n;return n;}
 String readString(){return bytes?String(std::string(bytes->begin(),bytes->end())):String();}
 void close(){}
};
struct Filesystem {
 std::map<std::string,std::vector<uint8_t>> files;bool failWrite=false,failRename=false;
 bool exists(const char* p){return files.count(p);}
 File open(const char* p,const char* mode){
  if(mode[0]=='r'&&!exists(p))return {};
  if(mode[0]=='w')files[p].clear();
  return {&files[p],0,mode[0]=='w',failWrite};
 }
 bool remove(const char* p){return files.erase(p);}
 bool rename(const char* a,const char* b){if(failRename||!exists(a))return false;files[b]=files[a];files.erase(a);return true;}
}LittleFS;
struct Bluetooth {
 std::vector<std::vector<uint8_t>> sent;
 void enableA2DP(){}void disableA2DP(){}void setA2DPvolume(uint8_t){}
 bool connected(){return true;}uint32_t session(){return 1;}
 void sendBLEData(const uint8_t* p,size_t n){sent.emplace_back(p,p+n);}
 void sendBLEBlob(uint8_t cmd,const uint8_t* p,size_t n){std::vector<uint8_t>b(n+3);b[0]=cmd;JmWebSync::put16(b.data()+1,n);memcpy(b.data()+3,p,n);sent.push_back(b);}
}btManager;
using QueueHandle_t=void*;
constexpr size_t MAX_BLOB_SIZE=1024;
uint32_t millis(){return 10000;}
uint8_t FX_LAYOUT[18][2];
Preset currentPreset{};
struct {uint8_t volume=38;bool a2dpEnabled=false;}state;
struct Clock{bool Active(uint32_t){return false;}};
struct Phase{double Fraction(Clock&,uint32_t,uint8_t,bool){return -1;}};
struct DisplayManager {
 bool drumEnabled=false,looperEnabled=false,looperAutoArm=false,looperBounce=false,bypassEnabled=false;
 uint8_t looperMute=0,looperSolo=0,drumFill=0;
 int bpmValue=120,drumBPM=120,currentState=0,currentRectIndex=0;
 void setTempo(uint8_t bpm);void highlightRect(int,bool){}
 int drumLevel=50,drumStyle=0,drumPattern=1,looperLevel=64,looperSync=0,looperBars=0,looperNum=0,looperPlayMode=0;
 int looperTrackState=0,loopLayerCount=0;uint32_t loopLength=0,loopStart=0;
 Clock beatClock;Phase looperBeatPhase;
 bool isTunerActive(){return false;}
}display;
void saveSystemState(){}void updateDSPFromPreset(){}
std::vector<std::pair<std::string,std::vector<uint8_t>>> dspWrites;
void sendToDSP(const char* tag,uint8_t* payload,size_t len){dspWrites.emplace_back(std::string(tag,4),std::vector<uint8_t>(payload,payload+len));}
void delay(unsigned){}
namespace MainHome {constexpr int BPM=0;}
constexpr int STATE_MAIN_MENU=0;
#include "tempo-functions.inc"

void loadFxLayoutFromConfig(){auto f=LittleFS.open("/config.json","r");auto text=f.readString();assert(JmWebSync::validateConfig(text.c_str(),text.length(),FX_LAYOUT));}
#include "blob-functions.inc"
uint8_t blobBuffer[MAX_BLOB_SIZE];
#include "load-preset.inc"
#include "WebSyncRuntime.hpp"
static void write(const std::string& path,const std::vector<uint8_t>& bytes){std::ofstream f(path,std::ios::binary);f.write((const char*)bytes.data(),bytes.size());}
static void chunk(uint16_t index,bool last,const std::string& data){std::vector<uint8_t> p(data.size()+3);JmWebSync::put16(p.data(),index);p[2]=last;memcpy(p.data()+3,data.data(),data.size());receiveWebConfig(p.data(),p.size());}
int main(int argc,char** argv){
 assert(argc==2);std::string folder=argv[1];
 ensureWebConfig();loadFxLayoutFromConfig();
 // Seed real flash files using the former firmware layouts, then exercise the
 // production loadPreset() (not a fake loader) across every bank and slot.
 uint8_t canonical[18][2];memcpy(canonical,FX_LAYOUT,sizeof(canonical));
 FX_LAYOUT[2][0]=9;FX_LAYOUT[2][1]=3;FX_LAYOUT[6][1]=6;FX_LAYOUT[9][0]=5;FX_LAYOUT[9][1]=2;
 for(uint8_t b=0;b<7;b++)for(uint8_t s=0;s<5;s++){
   Preset fixture{};fixture.bank=b;fixture.number=s;fixture.bpm=137;fixture.masterVolume=95;strcpy(fixture.name,"Legacy flash fixture");
   for(int fx=0;fx<18;fx++){
     fixture.effects[fx].enabled=fx%2;
     for(int k=0;k<FX_LAYOUT[fx][0];k++)fixture.effects[fx].knobs[k]=(b*5+s+k)%101;
     for(int d=0;d<FX_LAYOUT[fx][1];d++)fixture.effects[fx].dropdowns[d]=d+1;
   }
   for(auto& p:fixture.eqPoints){p.freq=440;p.q=14;p.enabled=true;}
   uint8_t bytes[1024];size_t n=serializeStructToBlob(fixture,bytes);char file[40];webSlotPath(b,s,file,sizeof(file));
   LittleFS.files[file]=std::vector<uint8_t>(bytes,bytes+n);
 }
 memcpy(FX_LAYOUT,canonical,sizeof(canonical));
 const auto flashBefore=LittleFS.files;
 for(uint8_t b=0;b<7;b++)for(uint8_t s=0;s<5;s++){
   Preset loaded{};assert(loadPreset(b,s,loaded));assert(loaded.bank==b&&loaded.number==s&&loaded.masterVolume==38&&loaded.bpm==137);
   assert(loaded.effects[2].dropdowns[0]==1&&loaded.effects[6].dropdowns[5]==6&&loaded.effects[9].dropdowns[1]==2);
 }
 assert(LittleFS.files==flashBefore);
 PresetSwitchCursor cursor;uint8_t b=0,s=0;
 for(int i=0;i<20;i++){cursor.move(b,s,0,1);s=cursor.slot;Preset loaded{};assert(loadPreset(b,s,loaded));cursor.loaded();assert(s==(i+1)%5);}
 cursor.move(0,0,0,1);cursor.move(0,0,0,1);assert(cursor.slot==2); // first attempt failed: next click progresses

 const auto original=LittleFS.files["/config.json"];
 chunk(2,false,"out of order");assert(btManager.sent.back()[1]==2);
 std::string candidate=g_webDefaultConfig;
 const auto at=candidate.find("threshold_db");candidate.replace(at,12,"threshold_test");
 const size_t step=160;uint16_t index=0;
 for(size_t off=0;off<candidate.size();off+=step,index++){
   std::string part=candidate.substr(off,step);bool last=off+step>=candidate.size();
   chunk(index,last,part);assert(btManager.sent.back()[1]==0);
   if(!index){assert(LittleFS.files["/config.json"]==original);chunk(index,last,part);assert(btManager.sent.back()[1]==0);}
 }
 assert(JmWebSync::get16(btManager.sent.back().data()+4)==JmWebSync::crc16((const uint8_t*)candidate.data(),candidate.size()));
 assert(std::string(LittleFS.files["/config.json"].begin(),LittleFS.files["/config.json"].end())==candidate);
 auto applied=LittleFS.files["/config.json"];
 chunk(0,true,"invalid");assert(btManager.sent.back()[1]==3);assert(LittleFS.files["/config.json"]==applied);
 LittleFS.failWrite=true;assert(!writeVerifiedFile("/config.json",original.data(),original.size()));assert(LittleFS.files["/config.json"]==applied);LittleFS.failWrite=false;
 LittleFS.failRename=true;assert(!writeVerifiedFile("/config.json",original.data(),original.size()));assert(LittleFS.files["/config.json"]==applied);LittleFS.failRename=false;
 sendWebCatalog();write(folder+"/catalog.bin",btManager.sent.back());
 for(uint8_t b=0;b<7;b++)for(uint8_t s=0;s<5;s++){sendWebSlot(b,s);write(folder+"/slot"+std::to_string(b)+std::to_string(s)+".bin",btManager.sent.back());}
 size_t sent=btManager.sent.size();sendWebSlot(7,0);assert(btManager.sent.size()==sent);
 uint8_t blob[1024];size_t n=serializeStructToBlob(currentPreset,blob);assert(validWebPreset(blob,n));
 assert(!validWebPreset(blob,n-1));assert(!validWebPreset(blob,3));
 loadPreset(2,3,currentPreset);s_webReadyEpoch=1;btManager.sent.clear();sendWebSnapshot(true);
 bool selected=false,stateSent=false,controls=false;
 for(const auto& p:btManager.sent){if(p[0]==0x3f){selected=p[1]==2&&p[2]==3;}if(p[0]==0x34)stateSent=true;if(p[0]==0x3e)controls=p.size()==19;}
 assert(selected&&stateSent&&controls);
 btManager.sent.clear();currentPreset.effects[2].knobs[14]=98;display.looperAutoArm=true;display.looperBounce=true;display.looperMute=5;
 sendWebSnapshot(false);bool param=false;
 for(const auto& p:btManager.sent){if(p[0]==0x36&&p[1]==2&&p[2]==15)param=p[3]==98;if(p[0]==0x3e){assert(p[9]==1);assert(p[13]==1);assert(p[14]==5);}}
 assert(param);
 dspWrites.clear();display.drumEnabled=true;display.setTempo(143);
 assert(currentPreset.bpm==143&&display.drumBPM==143&&state.volume==38&&display.drumEnabled);
 assert(dspWrites.front().first=="TCTL"&&dspWrites.front().second==std::vector<uint8_t>({1,1,150,5}));
 assert(dspWrites.back().first=="DRUM"&&dspWrites.back().second[0]==1&&dspWrites.back().second[2]==143&&dspWrites.back().second[4]==0);
 dspWrites.clear();uint8_t request[]={38,50,143,0};applyWebGlobal(request,4);
 assert(dspWrites[dspWrites.size()-2].first=="TCTL"); // resend cached BPM, not a no-op
 request[2]=111;applyWebGlobal(request,4);assert(currentPreset.bpm==111&&display.drumEnabled&&state.volume==38);
 puts("PASS firmware runtime: ordered/idempotent config, applied checksum, invalid config and file failure preservation, 35 slots, malformed presets");
}
