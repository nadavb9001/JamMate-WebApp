#pragma once
#include "PresetBinary_v2.hpp"
#include "ByteUtils.hpp"
#include <algorithm>
// Main-task only. Snapshot transport is separate; no DSP work or allocations.
struct ActivePresetSync {
 static bool decodeParam(const uint8_t* p,size_t n,const uint8_t counts[18][2],uint8_t& fx,uint8_t& flat,uint8_t& value){
  if(n!=4)return false;fx=p[0];const auto kind=p[1],index=p[2];value=p[3];
  if(fx>=18||kind>2||(kind==0&&index)||(kind==1&&index>=counts[fx][0])||(kind==2&&index>=counts[fx][1]))return false;
  flat=kind==0?0:kind==1?1+index:1+counts[fx][0]+index;return true;
 }
 Preset previous{};uint8_t layout[18][2]{};bool initialized=false;uint32_t revision=0;
 static bool sameEq(const EQPoint& a,const EQPoint& b){return a.freq==b.freq&&a.gain==b.gain&&a.q==b.q&&a.enabled==b.enabled;}
 template<class Emit>bool observe(const Preset& now,const uint8_t counts[18][2],Emit emit){
  unsigned changes=0;
  if(initialized){
   changes+=previous.bpm!=now.bpm;changes+=previous.masterVolume!=now.masterVolume;
   for(unsigned f=0;f<18;f++){
    changes+=previous.effects[f].enabled!=now.effects[f].enabled;
    for(unsigned k=0;k<counts[f][0];k++)changes+=previous.effects[f].knobs[k]!=now.effects[f].knobs[k];
    for(unsigned d=0;d<counts[f][1];d++)changes+=previous.effects[f].dropdowns[d]!=now.effects[f].dropdowns[d];
   }
   for(unsigned b=0;b<12;b++)if(!sameEq(previous.eqPoints[b],now.eqPoints[b]))changes++;
  }
  const bool full=!initialized||previous.bank!=now.bank||previous.number!=now.number||strncmp(previous.name,now.name,PRESET_NAME_LENGTH)||memcmp(layout,counts,36)||changes>8;
  auto delta=[&](uint8_t fx,uint8_t kind,uint8_t index,const uint8_t* p,size_t n){
   uint8_t out[14]={0xa7,2};JmBytes::put32(out+2,++revision);out[6]=fx;out[7]=kind;out[8]=index;memcpy(out+9,p,n);emit(out,n+9);
  };
  if(full)revision++;
  else if(changes){
   if(previous.bpm!=now.bpm)delta(0xfe,3,1,&now.bpm,1);
   if(previous.masterVolume!=now.masterVolume)delta(0xfe,3,0,&now.masterVolume,1);
   for(uint8_t f=0;f<18;f++){
    if(previous.effects[f].enabled!=now.effects[f].enabled){uint8_t value=now.effects[f].enabled;delta(f,0,0,&value,1);}
    for(uint8_t k=0;k<counts[f][0];k++)if(previous.effects[f].knobs[k]!=now.effects[f].knobs[k])delta(f,1,k,&now.effects[f].knobs[k],1);
    for(uint8_t d=0;d<counts[f][1];d++)if(previous.effects[f].dropdowns[d]!=now.effects[f].dropdowns[d])delta(f,2,d,&now.effects[f].dropdowns[d],1);
   }
   for(uint8_t b=0;b<12;b++)if(!sameEq(previous.eqPoints[b],now.eqPoints[b])){const auto& q=now.eqPoints[b];uint8_t p[5]={uint8_t(q.enabled),uint8_t(q.freq),uint8_t(q.freq>>8),uint8_t(q.gain),q.q};delta(0xfd,4,b,p,5);}
  }
  previous=now;memcpy(layout,counts,36);initialized=true;return full;
 }
};
