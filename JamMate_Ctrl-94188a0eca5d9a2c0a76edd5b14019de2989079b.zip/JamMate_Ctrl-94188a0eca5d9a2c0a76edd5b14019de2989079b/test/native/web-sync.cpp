#include <cassert>
#include <cstdio>
#include <vector>
#include <algorithm>
#include "JmWebSyncProtocol.hpp"
#include "JmDefaultConfig.hpp"
using namespace JmWebSync;
static std::vector<uint8_t> fragment(const std::vector<uint8_t>& data,uint16_t id,size_t off,size_t n){
 std::vector<uint8_t> p(10+n);p[0]=0x7e;p[1]=1;put16(p.data()+2,id);put16(p.data()+4,off);
 put16(p.data()+6,data.size());put16(p.data()+8,crc16(data.data(),data.size()));
 memcpy(p.data()+10,data.data()+off,n);return p;
}
int main(){
 uint8_t layout[18][2];assert(validateConfig(g_webDefaultConfig,strlen(g_webDefaultConfig),layout));
 assert(layout[2][0]==15&&layout[2][1]==6&&layout[6][1]==10&&layout[9][0]==3);
 assert(!validateConfig("GATE|x||",9,layout));
 std::vector<char> wrong(g_webDefaultConfig,g_webDefaultConfig+strlen(g_webDefaultConfig));wrong[0]='X';
 assert(!validateConfig(wrong.data(),wrong.size(),layout));
 assert(validSlot(6,4)&&!validSlot(7,0)&&!validSlot(0,5));
 std::vector<uint8_t> data(1024);for(size_t i=0;i<data.size();i++)data[i]=i;
 Receiver rx;bool complete=false;
 for(size_t off=0;off<data.size();off+=10){auto p=fragment(data,7,off,std::min(size_t(10),data.size()-off));complete=rx.accept(p.data(),p.size(),100+off);}
 assert(complete&&!memcmp(rx.bytes,data.data(),data.size()));
 auto first=fragment(data,8,0,10),second=fragment(data,8,10,10);
 assert(!rx.accept(first.data(),first.size(),0));assert(!rx.accept(second.data(),second.size(),6000));
 auto skipped=fragment(data,9,20,10);first=fragment(data,9,0,10);
 assert(!rx.accept(first.data(),first.size(),0));assert(!rx.accept(skipped.data(),skipped.size(),1));
 std::vector<uint8_t> shortData={1,2,3};auto corrupted=fragment(shortData,10,0,3);corrupted.back()^=1;
 assert(!rx.accept(corrupted.data(),corrupted.size(),0));
 auto valid=fragment(shortData,11,0,3);assert(rx.accept(valid.data(),valid.size(),1));
 puts("PASS native framing: CRC, sequence gaps, deadlines, recovery, canonical config and slot bounds");
}
