#pragma once
#include <stdint.h>
// Keep navigation progress separate from the sounding preset. A corrupt slot
// reports an error but must not trap every subsequent click at that same slot.
struct PresetSwitchCursor {
  uint8_t bank=0,slot=0,playingBank=255,playingSlot=255;
  void move(uint8_t currentBank,uint8_t currentSlot,int bankDelta,int slotDelta){
    if(currentBank!=playingBank||currentSlot!=playingSlot){bank=currentBank;slot=currentSlot;}
    playingBank=currentBank;playingSlot=currentSlot;
    if(bankDelta){bank=(bank+7+bankDelta)%7;slot=0;}
    else slot=(slot+5+slotDelta)%5;
  }
  void loaded(){playingBank=bank;playingSlot=slot;}
};
