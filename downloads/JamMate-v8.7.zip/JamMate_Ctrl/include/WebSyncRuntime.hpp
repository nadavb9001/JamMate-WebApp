#pragma once
#include "JmWebSyncProtocol.hpp"
#include "JmDefaultConfig.hpp"
#include "ByteUtils.hpp"
#include <atomic>

struct BleCommand { uint8_t* data; size_t size; uint32_t epoch; uint8_t slot; };
static QueueHandle_t s_bleCommands=nullptr;
static uint8_t s_webDrumGrid[144]={};
static uint16_t s_webGridRevision=0;
static uint32_t s_webReadyEpoch=0;
static uint8_t s_webUsbMode=1;
static uint8_t s_commandSmall[4][1100],s_commandLarge[2051];
static std::atomic_bool s_commandBusy[5]{};

static void webSlotPath(uint8_t bank,uint8_t slot,char* out,size_t n){
  snprintf(out,n,bank<5?"/presets/f_%u_%u.bin":"/presets/c_%u_%u.bin",bank<5?bank:bank-5,slot);
}
static bool writeVerifiedFile(const char* path,const uint8_t* bytes,size_t n){
  const char* temp="/.web-write.tmp";
  File f=LittleFS.open(temp,"w");if(!f)return false;
  const size_t written=f.write(bytes,n);f.close();
  if(written!=n){LittleFS.remove(temp);return false;}
  f=LittleFS.open(temp,"r");bool ok=f&&f.size()==n;
  uint8_t check[96];size_t off=0;
  while(ok&&off<n){size_t k=std::min(sizeof(check),n-off);ok=f.read(check,k)==k&&!memcmp(check,bytes+off,k);off+=k;}
  f.close();
  if(!ok||!LittleFS.rename(temp,path)){LittleFS.remove(temp);return false;}
  return true;
}
static void ensureWebConfig(){
  if(!LittleFS.exists("/config.json"))
    writeVerifiedFile("/config.json",(const uint8_t*)g_webDefaultConfig,strlen(g_webDefaultConfig));
}
static bool receiveWebConfig(const uint8_t* p,size_t n){
  static char pending[4097];static size_t pendingLength=0;
  static uint16_t next=0,last=0xffff,lastCrc=0,committedCrc=0;
  static bool active=false;static uint32_t epoch=0;
  if(n<3)return false;
  if(epoch!=btManager.session()){epoch=btManager.session();active=false;next=0;last=0xffff;committedCrc=0;pendingLength=0;}
  const uint16_t index=JmWebSync::get16(p),chunkCrc=JmWebSync::crc16(p,n);
  uint8_t status=0;
  if(index!=0 && index==last && chunkCrc==lastCrc){
    // Duplicate of the most recently acknowledged chunk is idempotent.
  }else{
    if(index==0){pendingLength=0;next=0;active=true;committedCrc=0;}
    if(!active||index!=next||pendingLength+n-3>4096||p[2]>1)status=2;
    else{
      memcpy(pending+pendingLength,p+3,n-3);pendingLength+=n-3;pending[pendingLength]=0;
      if(p[2]){
        uint8_t layout[18][2];
        if(!JmWebSync::validateConfig(pending,pendingLength,layout))status=3;
        else if(!writeVerifiedFile("/config.json",(const uint8_t*)pending,pendingLength))status=1;
        else{
          if(!applyFxConfigText(pending,pendingLength)||memcmp(FX_LAYOUT,layout,sizeof(layout)))status=4;
          else {committedCrc=JmWebSync::crc16((const uint8_t*)pending,pendingLength);}
        }
        active=false;
      }
      if(!status){last=index;lastCrc=chunkCrc;next++;}
    }
  }
  if(epoch!=btManager.session())return false; // never publish an old upload ACK into a new session
  Serial.printf("[CFG] Upload chunk %u status=%u final=%u\n",unsigned(index),unsigned(status),unsigned(p[2]));
  return p[2]&&status==0;

}
static bool validWebPreset(const uint8_t* b,size_t n){
  if(n<4||n>MAX_BLOB_SIZE||b[0]!=3||b[3]>=PRESET_NAME_LENGTH||size_t(b[3])+4>n)return false;
  size_t off=4+b[3];uint32_t seen=0;
  while(off<n){
    if(n-off<2)return false;
    uint8_t id=b[off++],count=b[off++];
    if(id==0xfe)return count<=12 && off+size_t(count)*5==n && seen==0x3ffff;
    if(id>=18||(seen&(1u<<id))||count!=1+FX_LAYOUT[id][0]+FX_LAYOUT[id][1]||off+count>n)return false;
    seen|=1u<<id;off+=count;
  }
  return seen==0x3ffff;
}
static bool decodeWebPreset(const uint8_t* bytes,size_t n,Preset& result){
 if(!validWebPreset(bytes,n))return false;
 bool legacy=false;return PresetBlobReader::decode(bytes,n,FX_LAYOUT,result,legacy)&&!legacy;
}

static void presetAck(uint8_t cmd,uint8_t status,uint8_t bank,uint8_t slot){
  uint8_t bytes[]={0x59,cmd,status,bank,slot};btManager.sendBLEData(bytes,sizeof(bytes));
}
static size_t webReadSlot(uint8_t bank,uint8_t slot,uint8_t* bytes){
  // Cache normalized blobs, with a fixed volume: global volume is not preset data.
  Preset preset{};
  if(!loadPreset(bank,slot,preset))return 0;
  preset.masterVolume=20;
  return serializeStructToBlob(preset,bytes);
}
#include "ActivePresetSync.hpp"
static ActivePresetSync s_activeSync;
static uint8_t s_syncBytes[1100];static size_t s_syncLength=0,s_syncOffset=0;
static uint16_t s_syncToken=0,s_syncCRC=0;static uint32_t s_syncRevision=0,s_syncEpoch=0,s_syncObserved=0,s_syncSent=0;
static bool s_syncRequested=false,s_syncSending=false;static uint8_t s_syncFailures=0;
static void requestActiveSnapshot(uint16_t token){
 s_webReadyEpoch=btManager.session();s_syncToken=token;s_syncRequested=true;
}
static void syncObserve(bool emit){
 Preset now=currentPreset;now.masterVolume=state.volume;
 const bool full=s_activeSync.observe(now,FX_LAYOUT,[&](const uint8_t* p,size_t n){if(emit)btManager.sendSyncPacket(p,n);});
 if(full&&!s_syncRequested){s_syncToken=0;s_syncRequested=true;}
}
static void sendActiveRevision(uint16_t token){
 if(!s_syncSending)syncObserve(true);
 uint8_t p[8]={0xa7,3};JmBytes::put16(p+2,token);JmBytes::put32(p+4,s_activeSync.revision);btManager.sendSyncPacket(p,sizeof(p));
}
static void sendWebCatalog(){}
static void sendWebSlot(uint8_t,uint8_t){}
void sendWebSnapshot(bool){if(btManager.connected()&&s_webReadyEpoch==btManager.session()&&!s_syncRequested){s_syncToken=0;s_syncRequested=true;}}
void serviceWebSync(){
 if(!btManager.connected()||s_webReadyEpoch!=btManager.session())return;
 if(s_syncEpoch!=btManager.session()){s_syncEpoch=btManager.session();s_activeSync.initialized=false;s_syncSending=false;}
 const uint32_t now=millis();
 if(s_syncRequested){
  syncObserve(false);s_syncBytes[0]=currentPreset.bank;s_syncBytes[1]=currentPreset.number;memcpy(s_syncBytes+2,FX_LAYOUT,36);
  Preset snapshot=currentPreset;snapshot.masterVolume=state.volume;
  s_syncLength=38+serializeStructToBlob(snapshot,s_syncBytes+38);s_syncOffset=0;s_syncCRC=JmWebSync::crc16(s_syncBytes,s_syncLength);s_syncRevision=s_activeSync.revision;
  s_syncRequested=false;s_syncSending=true;s_syncFailures=0;s_syncObserved=now;
 }
 if(s_syncSending){
  if(now-s_syncSent<(s_syncFailures?100u:btManager.syncPacketSize()<=20?80u:20u))return;
  uint8_t packet[244]={0xa7,1};const size_t n=std::min(s_syncLength-s_syncOffset,btManager.syncPacketSize()-14);
  JmBytes::put16(packet+2,s_syncToken);JmBytes::put32(packet+4,s_syncRevision);JmBytes::put16(packet+8,s_syncOffset);JmBytes::put16(packet+10,s_syncLength);JmBytes::put16(packet+12,s_syncCRC);memcpy(packet+14,s_syncBytes+s_syncOffset,n);
  if(btManager.sendSyncPacket(packet,n+14)){s_syncFailures=0;s_syncOffset+=n;s_syncSent=now;if(s_syncOffset==s_syncLength)s_syncSending=false;}
  else {s_syncSent=now;if(++s_syncFailures>=3)s_syncSending=false;} // receiver timeout/revision check repairs; never disconnect
  return;
 }
 if(now-s_syncObserved>=40){s_syncObserved=now;syncObserve(true);}
}
