#include "DisplayComponents.h"

// --- Fonts ---
const GFXfont& FONT_GENERAL_NORMAL = FreeSans9pt7b;
const GFXfont& FONT_GENERAL_BOLD = FreeSansBold9pt7b;
const GFXfont& FONT_PRESET_TITLE_NORMAL = FreeSans18pt7b;
const GFXfont& FONT_LOOPER_BIG = FreeSansBold24pt7b;

// --- Colors & Labels ---
const char* presetNames[TOTAL_BANKS] = { "CLEAN", "CRUNCH", "OVERDRV", "DISTORT", "MODUL", "CUSTM1", "CUSTM2" };
const char* fxLabels[TOTAL_FX] = { "GATE", "COMP", "AWAH", "OVRD", "DIST", "EQUL", "HARM", "VIBR", "CHOR", "OCTV", "FLNG", "PHAS", "TREM", "FIR ", "DELY", "NAM ", "RVRB", "GNRC" };
const uint16_t fxColors[7] = { TFT_ORANGE, TFT_ORANGE, TFT_ORANGE, TFT_ORANGE, TFT_ORANGE, TFT_ORANGE, TFT_ORANGE };
const char* extraLabels[TOTAL_EXTRA_BUTTONS] = { "Setup", "Looper", "Drum" };
const uint16_t extraColors[TOTAL_EXTRA_BUTTONS] = { TFT_DARKGREY, TFT_DARKGREY, TFT_DARKGREY };

// --- Button Implementation ---
void EnhancedRectButton::drawWithFont(TFT_eSPI& tft, const GFXfont* font) {
    int clearMargin = HIGHLIGHT_BORDER_THICKNESS;
    tft.fillRoundRect(x - clearMargin, y - clearMargin, w + 2 * clearMargin, h + 2 * clearMargin, radius + clearMargin, TFT_BLACK);
    tft.fillRoundRect(x, y, w, h, radius, bgColor);

    if (type == RECT_PROGRESS) {
        int fillW = map(progressValue, 0, 100, 0, w);
        tft.fillRoundRect(x, y, fillW, h, radius, progressColor);
    }

    tft.setTextDatum(MC_DATUM);
    tft.setFreeFont(font);

    if (type == RECT_PROGRESS) tft.setTextColor(TFT_RED);
    else tft.setTextColor(TFT_WHITE, bgColor);

    tft.drawString(label, x + w / 2, y + h / 2);

    if (highlighted) {
        for (int i = 0; i < HIGHLIGHT_BORDER_THICKNESS; ++i)
            tft.drawRoundRect(x - i, y - i, w + 2 * i, h + 2 * i, radius + i, TFT_RED);
    } else {
        tft.drawRoundRect(x, y, w, h, radius, borderColor);
    }
    
    if (type == RECT_SELECTION && selected) {
        tft.drawRoundRect(x + 2, y + 2, w - 4, h - 4, radius - 2, TFT_ORANGE);
    }
}

// ===================================================================
// STATIC PARAMETER DATA
// ===================================================================

const char* lbl_Gate_K[] = { "Thresh", "Hold", "Attack", "Rel", "Level" };
const char* lbl_Comp_K[] = { "Level", "Ratio", "Thresh", "Attack", "Rel", "Wet", "Dry", "MakeUp" };
const char* lbl_Awah_K[] = { "Dry", "Wet", "Sens", "Q", "Fcent", "Fmin", "Fmax", "Attack", "Decay" };
const char* lbl_Awah_D[] = { "Filter", "Mode", "Direc" };
const char* lbl_Ovrd_K[] = { "Level", "Drive", "Type", "PreLP", "PreHP", "PstLP", "PstHP", "MidF", "MidG", "Blend" };
const char* lbl_Ovrd_D[] = { "Type", "Brand" };
const char* lbl_Dist_K[] = { "Level", "Drive", "Type", "PreLP", "PreHP", "PstLP", "PstHP", "MidF", "MidG", "Blend" };
const char* lbl_Dist_D[] = { "Type", "Brand" };
const char* lbl_Equl_K[] = { "Level", "HPF", "100", "200", "400", "800", "1.6k", "3.2k", "LPF", "Q" };
const char* lbl_Equl_D[] = { "Type", "Scale" };
const char* lbl_Harm_K[] = { "Level", "Dry", "Wet1", "Wet2", "Arpeg", "Rate" };
const char* lbl_Harm_D[] = { "Scale", "Mode", "Wet1", "Wet2" };
const char* lbl_Vibr_K[] = { "Rate", "Depth", "Fluttr" };
const char* lbl_Chor_K[] = { "Level", "Rate", "Depth", "Delay", "Fdbk", "Wet", "Dry" };
const char* lbl_Octv_K[] = { "Level", "Dry", "Wet", "Shift", "Buf" };
const char* lbl_Octv_D[] = { "Semi", "Dir" };
const char* lbl_Flng_K[] = { "Level", "Rate", "Depth", "Fdbk", "Delay" };
const char* lbl_Phas_K[] = { "Level", "Rate", "Depth", "Freq", "Fdbk", "Wet", "Dry" };
const char* lbl_Phas_D[] = { "Poles" };
const char* lbl_Trem_K[] = { "Level", "Depth", "Rate", "MidF" };
const char* lbl_Trem_D[] = { "Mode", "Wave" };
const char* lbl_Fir_K[] = { "Level", "Treble", "Mid", "Bass", "Pres", "Gain" };
const char* lbl_Fir_D[] = { "Amp", "Tone", "Pts", "Type", "File" };
const char* lbl_Dely_K[] = { "Level", "Fdbk", "Time", "LPF", "Dry", "Wet", "Depth", "Rate", "S/P" };
const char* lbl_Dely_D[] = { "Type", "Div", "Multi" };
const char* lbl_Nam_K[] = { "Level", "PreAtt" };
const char* lbl_Nam_D[] = { "Model" };
const char* lbl_Rvrb_K[] = { "Level", "Fdbk", "Damp", "Dry", "Wet", "Freez", "Gain", "Depth", "Rate", "Type" };
const char* lbl_Rvrb_D[] = { "Eng", "Type" };
const char* lbl_Gnrc_K[] = { "Lvl", "P1", "P2", "P3", "P4", "P5", "P6", "P7", "P8", "P9" };
const char* lbl_Gnrc_D[] = { "G1", "G2" };

const char* opt_None[] = { "None" };
const char* opt_NAM_Models[] = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25" };
const char* opt_AmpType[] = { "None", "Fender", "Twin", "Marsh", "Orange", "Mesa", "EVH", "Fried", "VOX", "Bass", "Cust" };
const char* opt_ToneType[] = { "None", "Fender", "Marsh" };
const char* opt_IRPoints[] = { "256", "512", "1024", "2048", "4096", "8192" };
const char* opt_IRType[] = { "FIR", "FFT", "Conv" };
const char* opt_IRFile[] = { "1", "2", "3" };
const char* opt_DistType[] = { "Exp", "Soft", "Hard", "HiGain", "Fuzz", "Assym", "Multi", "Tube", "BitCr" };
const char* opt_DistBrand[] = { "Rat", "DS2", "M_Zone", "MXR+", "Muff" };
const char* opt_OvrdBrand[] = { "TubeScr", "Blues", "Klon", "ODR1" };
const char* opt_PhaserPoles[] = { "1", "2", "3", "4" };
const char* opt_TremMode[] = { "Vint", "Harm" };
const char* opt_Waveform[] = { "Sine", "Tri", "Saw", "Sqr" };
const char* opt_DelayType[] = { "Digi", "Echo", "Tape", "Multi", "Mod", "Ping", "Duck" };
const char* opt_Division[] = { "1/32", "1/16", "1/16t", "1/16d", "1/8", "1/8t", "1/8d", "1/4", "1/4t", "1/4d", "1/2", "1" };
const char* opt_DelayMulti[] = { "1", "2", "3" };
const char* opt_RvrbEng[] = { "Free", "Datt", "FDN", "RevSC" };
const char* opt_RvrbType[] = { "Room", "Hall", "Plate", "Sprng", "Pads" };
const char* opt_ShiftDir[] = { "Up", "Down" };
const char* opt_ShiftSemi[] = { "Detune", "1", "2", "3", "4", "5", "6", "7", "8", "9", "11", "12" };
const char* opt_Scale[] = { "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" };
const char* opt_Mode[] = { "Maj", "Min", "H.Min", "M.Min", "Lyd", "Mixo", "Phry", "Dor", "Loc" };
const char* opt_HarmWet[] = { "2", "3", "4", "5", "6" };
const char* opt_EQType[] = { "Neut", "Scoop", "Mid+", "Bass+", "Treb+" };
const char* opt_EQScale[] = { "100%", "75%", "50%", "125%", "150%" };
const char* opt_Gen1[] = { "A1", "B1", "C1", "D1", "E1" };
const char* opt_Gen2[] = { "A2", "B2", "C2", "D2", "E2" };

// --- Grouping Arrays ---
const char** opts_Ovrd[] = { opt_DistType, opt_OvrdBrand };
const uint8_t cnts_Ovrd[] = { 9, 4 };
const char** opts_Dist[] = { opt_DistType, opt_DistBrand };
const uint8_t cnts_Dist[] = { 9, 5 };
const char** opts_Equl[] = { opt_EQType, opt_EQScale };
const uint8_t cnts_Equl[] = { 5, 5 };
const char** opts_Harm[] = { opt_Scale, opt_Mode, opt_HarmWet, opt_HarmWet };
const uint8_t cnts_Harm[] = { 12, 9, 5, 5 };
const char** opts_Octv[] = { opt_ShiftSemi, opt_ShiftDir };
const uint8_t cnts_Octv[] = { 12, 2 };
const char** opts_Phas[] = { opt_PhaserPoles };
const uint8_t cnts_Phas[] = { 4 };
const char** opts_Trem[] = { opt_TremMode, opt_Waveform };
const uint8_t cnts_Trem[] = { 2, 4 };
const char** opts_Fir[] = { opt_AmpType, opt_ToneType, opt_IRPoints, opt_IRType, opt_IRFile };
const uint8_t cnts_Fir[] = { 11, 3, 6, 3, 3 };
const char** opts_Dely[] = { opt_DelayType, opt_Division, opt_DelayMulti };
const uint8_t cnts_Dely[] = { 7, 12, 3 };
const char** opts_Nam[] = { opt_NAM_Models };
const uint8_t cnts_Nam[] = { 25 };
const char** opts_Rvrb[] = { opt_RvrbEng, opt_RvrbType };
const uint8_t cnts_Rvrb[] = { 2, 4 };
const char** opts_Gnrc[] = { opt_Gen1, opt_Gen2 };
const uint8_t cnts_Gnrc[] = { 5, 5 };

FxLayout fxLayouts[TOTAL_FX] = {
  { 5, lbl_Gate_K, 0, nullptr, nullptr, nullptr },          // Gate
  { 8, lbl_Comp_K, 0, nullptr, nullptr, nullptr },          // Comp
  { 7, lbl_Awah_K, 0, nullptr, nullptr, nullptr },          // Awah
  { 10, lbl_Ovrd_K, 2, lbl_Ovrd_D, opts_Ovrd, cnts_Ovrd },  // Ovrd
  { 10, lbl_Dist_K, 2, lbl_Dist_D, opts_Dist, cnts_Dist },  // Dist
  { 10, lbl_Equl_K, 2, lbl_Equl_D, opts_Equl, cnts_Equl },  // Equl
  { 6, lbl_Harm_K, 4, lbl_Harm_D, opts_Harm, cnts_Harm },   // Harm
  { 3, lbl_Vibr_K, 0, nullptr, nullptr, nullptr },          // Vibr
  { 7, lbl_Chor_K, 0, nullptr, nullptr, nullptr },          // Chor
  { 5, lbl_Octv_K, 2, lbl_Octv_D, opts_Octv, cnts_Octv },   // Octv
  { 5, lbl_Flng_K, 0, nullptr, nullptr, nullptr },          // Flng
  { 7, lbl_Phas_K, 1, lbl_Phas_D, opts_Phas, cnts_Phas },   // Phas
  { 4, lbl_Trem_K, 2, lbl_Trem_D, opts_Trem, cnts_Trem },   // Trem
  { 6, lbl_Fir_K, 5, lbl_Fir_D, opts_Fir, cnts_Fir },       // FIR
  { 9, lbl_Dely_K, 3, lbl_Dely_D, opts_Dely, cnts_Dely },   // Dely
  { 2, lbl_Nam_K, 1, lbl_Nam_D, opts_Nam, cnts_Nam },       // NAM
  { 10, lbl_Rvrb_K, 2, lbl_Rvrb_D, opts_Rvrb, cnts_Rvrb },  // Rvrb
  { 10, lbl_Gnrc_K, 2, lbl_Gnrc_D, opts_Gnrc, cnts_Gnrc }   // Gnrc
};