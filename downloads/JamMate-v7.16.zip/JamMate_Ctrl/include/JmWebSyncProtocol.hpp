#pragma once
#include <stdint.h>
#include <stddef.h>
#include <string.h>

namespace JmWebSync {
constexpr uint8_t PARAM_CHANGE=0x36, CATALOG_DATA=0x38, BEAT=0x3c;
constexpr size_t MAX_FRAME=6144, FRAME_HEADER=10;
inline void put16(uint8_t* p,uint16_t n){p[0]=n;p[1]=n>>8;}
inline uint16_t get16(const uint8_t* p){return uint16_t(p[0])|(uint16_t(p[1])<<8);}
inline bool validSlot(uint8_t b,uint8_t s){return b<7&&s<5;}
inline uint16_t crc16(const uint8_t* p,size_t n){
  uint16_t crc=0xffff;
  while(n--){crc^=*p++;for(int i=0;i<8;i++)crc=(crc&1)?(crc>>1)^0xa001:crc>>1;}
  return crc;
}
// One ordered GATT writer per connection. Every fragment includes a transaction,
// offset, total length and whole-message CRC. No partial message is dispatched.
struct Receiver {
  uint8_t bytes[MAX_FRAME];
  uint16_t id=0,total=0,used=0,crc=0;
  uint32_t last=0;
  void reset(){total=used=0;}
  bool accept(const uint8_t* p,size_t n,uint32_t now){
    if(n<=FRAME_HEADER||p[0]!=0x7e||p[1]!=1)return false;
    const uint16_t tx=get16(p+2),off=get16(p+4),len=get16(p+6),sum=get16(p+8);
    if(total&&uint32_t(now-last)>5000)reset();
    if(!off){reset();id=tx;total=len;crc=sum;}
    if(!total||total>MAX_FRAME||id!=tx||total!=len||crc!=sum||used!=off||n-FRAME_HEADER>size_t(total-used)){
      reset();return false;
    }
    memcpy(bytes+used,p+FRAME_HEADER,n-FRAME_HEADER);used+=n-FRAME_HEADER;last=now;
    if(used!=total)return false;
    const bool ok=crc16(bytes,total)==crc;
    total=0;
    return ok;
  }
};
// Validate a complete config before replacing the active flash file or labels.
// Four pipe-delimited fields, 18 effects, bounded counts and label pool.
inline bool validateConfig(const char* text,size_t n,uint8_t layout[18][2]){
  if(!n||n>4096)return false;
  size_t row=0,start=0,pool=0;
  for(size_t end=0;end<=n;end++){
    if(end<n&&text[end]!='\n')continue;
    if(end==start||row>=18)return false;
    size_t pipes[3],count=0;
    for(size_t i=start;i<end;i++){
      if(text[i]=='\0'||text[i]=='\r')return false;
      if(text[i]=='|'){if(count==3)return false;pipes[count++]=i;}
    }
    if(count!=3||pipes[0]==start||pipes[0]-start>11)return false;
    static const char* names[]={"GATE","COMP","AWAH","OVRD","DIST","EQUL","HARM","VIBR","CHOR","OCTV","FLNG","PHAS","TREM","FIR","DELY","NAM","RVRB","GNRC"};
    size_t letter=0;
    for(size_t i=start;i<pipes[0];i++){
      if(text[i]=='_'||text[i]==' ')continue;
      if(!names[row][letter]||text[i]!=names[row][letter++])return false;
    }
    if(names[row][letter])return false;
    for(int field=0;field<2;field++){
      size_t a=pipes[field]+1,b=pipes[field+1];
      unsigned tokens=a==b?0:1;
      for(size_t i=a;i<b;i++){if(text[i]==',')tokens++;if(text[i]==':'||text[i]==';')return false;}
      if(tokens>(field?10u:16u))return false;
      layout[row][field]=tokens;
      pool+=b-a+(tokens?1:0);
    }
    size_t a=pipes[2]+1;unsigned groups=layout[row][1]?1:0,options=1;
    for(size_t i=a;i<end;i++){
      if(text[i]==',')return false;
      if(text[i]==':')options++;
      if(text[i]==';'){if(options>28)return false;groups++;options=1;}
    }
    if(options>28||groups!=layout[row][1])return false;
    pool+=end-a+(groups?1:0);
    if(pool>6144)return false;
    row++;start=end+1;
  }
  return row==18;
}
}
