#pragma once
// JamMate 240x320 vivid tuner. Static top/footer + dynamic pitch area.
// Uses built-in TFT_eSPI fonts (2 and 4), no external font dependency.
#include <TFT_eSPI.h>
#include <stdint.h>
#include <stdio.h>
#include <math.h>

namespace JmTunerPortrait {
struct Model {
    const char* note="--";
    int octave=0;
    float frequency=0.0f;
    int cents=0;
    int cpu=-1;
};
inline uint16_t rgb(TFT_eSPI& t,uint8_t r,uint8_t g,uint8_t b){return t.color565(r,g,b);}
inline uint16_t bg(TFT_eSPI& t){return rgb(t,3,9,21);}
inline uint16_t panel(TFT_eSPI& t){return rgb(t,8,23,41);}
inline uint16_t edge(TFT_eSPI& t){return rgb(t,40,71,99);}
inline uint16_t white(TFT_eSPI& t){return rgb(t,247,253,255);}
inline uint16_t muted(TFT_eSPI& t){return rgb(t,147,184,212);}
inline uint16_t cyan(TFT_eSPI& t){return rgb(t,0,220,250);}
inline uint16_t green(TFT_eSPI& t){return rgb(t,0,240,131);}
inline uint16_t amber(TFT_eSPI& t){return rgb(t,255,183,48);}
inline uint16_t coral(TFT_eSPI& t){return rgb(t,255,97,113);}
inline void text(TFT_eSPI& t,const char* s,int x,int y,int font,uint16_t color,uint16_t fill){
    t.setTextDatum(MC_DATUM);t.setTextColor(color,fill);t.drawString(s,x,y,font);
}
inline void header(TFT_eSPI& t){
    const uint16_t fill=rgb(t,8,25,44);
    t.fillRect(0,0,240,30,fill);t.drawFastHLine(0,29,240,edge(t));
    t.fillRoundRect(8,6,4,16,1,cyan(t));
    t.setTextDatum(ML_DATUM);t.setTextColor(white(t),fill);t.drawString("TUNER",18,15,2);
}
inline void footer(TFT_eSPI& t,int cpu){
    const uint16_t fill=rgb(t,8,24,39);
    t.fillRect(0,294,240,26,fill);t.drawFastHLine(0,294,240,edge(t));
    char s[24];if(cpu<0)snprintf(s,sizeof(s),"CPU --");
    else snprintf(s,sizeof(s),"CPU %d%%",cpu>100?100:cpu);
    t.setTextDatum(ML_DATUM);t.setTextColor(white(t),fill);t.drawString(s,9,307,2);
    t.fillRoundRect(103,304,85,6,2,rgb(t,29,54,77));
    if(cpu>0)t.fillRoundRect(103,304,(cpu>100?100:cpu)*85/100,6,2,cyan(t));
    t.fillCircle(223,304,8,rgb(t,25,57,51));
}
inline void dynamic(TFT_eSPI& t,const Model& m){
    const uint16_t fill=panel(t);const bool valid=isfinite(m.frequency)&&m.frequency>=20.0f;
    const bool tune=valid&&abs(m.cents)<=5;
    const int clamped=m.cents<-50?-50:m.cents>50?50:m.cents;
    t.fillRect(0,32,240,258,bg(t));
    t.fillRoundRect(8,36,224,158,8,fill);
    t.drawRoundRect(8,36,224,158,8,valid?(tune?green(t):cyan(t)):edge(t));
    t.setTextDatum(TC_DATUM);t.setTextColor(muted(t),fill);t.drawString("NOTE",120,42,2);
    // Big 50-ish pixel single-note display with separate, less prominent octave.
    t.setTextSize(2);
    text(t,valid?m.note:"--",111,106,4,valid?(tune?green(t):white(t)):muted(t),fill);
    t.setTextSize(1);
    if(valid){
        char oc[8];snprintf(oc,sizeof(oc),"%d",m.octave);
        text(t,oc,185,123,4,muted(t),fill);
    }
    char freq[28];
    if(valid)snprintf(freq,sizeof(freq),"%.1f Hz",(double)m.frequency);
    else snprintf(freq,sizeof(freq),"NO SIGNAL");
    text(t,freq,120,175,2,valid?cyan(t):muted(t),fill);

    const int x=14,w=212;
    t.fillRoundRect(x,205,w,62,7,fill);t.drawRoundRect(x,205,w,62,7,edge(t));
    t.setTextDatum(ML_DATUM);t.setTextColor(muted(t),fill);
    t.drawString("-50",20,214,2);
    t.setTextDatum(MR_DATUM);t.drawString("+50",220,214,2);
    text(t,"0",120,220,2,green(t),fill);
    // Simplified pitch scale; center target never moves.
    const int left=30,right=210,center=120;
    t.fillRoundRect(left,237,right-left,7,2,edge(t));
    t.fillRect(center-9,235,18,11,rgb(t,21,114,81));
    t.drawFastVLine(center,229,23,green(t));
    if(valid){
        const int needle=center+(clamped*87)/50;
        const uint16_t c=tune?green(t):(abs(m.cents)>25?coral(t):amber(t));
        t.fillCircle(needle,240,7,c);
    }
    char cents[26];
    if(valid)snprintf(cents,sizeof(cents),"%+d cents",m.cents);
    else snprintf(cents,sizeof(cents),"-- cents");
    text(t,cents,120,283,2,valid?(tune?green(t):white(t)):muted(t),bg(t));
}
// 8-bit animation buffer (240x258 ~62 KB); created once, only pitch area.
// All y coordinates are translated by -32 because sprite is pushed at y=32.
inline void dynamicSprite(TFT_eSprite& s,const Model& m){
    const uint16_t b=0x002A,card=0x08C5,line=0x32AC;
    const bool valid=isfinite(m.frequency)&&m.frequency>=20.0f;
    const bool tune=valid&&abs(m.cents)<=5;
    const int cents=m.cents<-50?-50:m.cents>50?50:m.cents;
    s.fillSprite(b);
    s.fillRoundRect(8,4,224,158,8,card);
    s.drawRoundRect(8,4,224,158,8,valid?(tune?0x07E8:0x07FF):line);
    s.setTextDatum(TC_DATUM);s.setTextFont(2);s.setTextColor(0xADDA,card);
    s.drawString("NOTE",120,10,2);
    s.setTextDatum(MC_DATUM);s.setTextSize(2);s.setTextFont(4);
    s.setTextColor(valid?(tune?0x07E8:TFT_WHITE):0xADDA,card);
    s.drawString(valid?m.note:"--",111,74,4);s.setTextSize(1);
    if(valid){char oct[8];snprintf(oct,sizeof(oct),"%d",m.octave);
      s.setTextColor(0xADDA,card);s.drawString(oct,185,91,4);}
    char f[30];
    if(valid)snprintf(f,sizeof(f),"%.1f Hz",(double)m.frequency);
    else strcpy(f,"NO SIGNAL");
    s.setTextColor(valid?0x07FF:0xADDA,card);s.drawString(f,120,143,2);
    s.fillRoundRect(14,173,212,62,7,card);
    s.drawRoundRect(14,173,212,62,7,line);
    s.setTextFont(2);s.setTextDatum(ML_DATUM);s.setTextColor(0xADDA,card);
    s.drawString("-50",20,182,2);s.setTextDatum(MR_DATUM);
    s.drawString("+50",220,182,2);
    s.setTextDatum(MC_DATUM);s.setTextColor(0x07E8,card);
    s.drawString("0",120,188,2);
    s.fillRoundRect(30,205,180,7,2,line);
    s.fillRect(111,203,18,11,0x1BAA);
    s.drawFastVLine(120,197,23,0x07E8);
    if(valid){const int needle=120+cents*87/50;
      s.fillCircle(needle,208,7,tune?0x07E8:(abs(m.cents)>25?0xFA49:0xFD20));}
    char cv[25];
    if(valid)snprintf(cv,sizeof(cv),"%+d cents",m.cents);
    else strcpy(cv,"-- cents");
    s.setTextColor(valid?(tune?0x07E8:TFT_WHITE):0xADDA,b);
    s.drawString(cv,120,251,2);
}
inline void draw(TFT_eSPI& t,const Model& m){t.fillScreen(bg(t));header(t);dynamic(t,m);footer(t,m.cpu);}
} // namespace JmTunerPortrait
