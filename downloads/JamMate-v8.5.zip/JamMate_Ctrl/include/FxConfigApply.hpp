#pragma once
#include "JmWebSyncProtocol.hpp"
// The caller owns the complete config text. Validate first, then populate the
// existing fixed label pool directly: no line Strings or second file copy.
static bool applyFxConfigText(const char* text,size_t n){
 uint8_t layout[18][2];if(!JmWebSync::validateConfig(text,n,layout))return false;
 g_cfgPoolUsed=0;memset(g_optCounts,0,sizeof(g_optCounts));
 auto copy=[&](size_t a,size_t b)->const char*{
  const size_t count=b-a;
  if(size_t(g_cfgPoolUsed)+count+1>sizeof(g_cfgPool))return nullptr;
  char* out=g_cfgPool+g_cfgPoolUsed;memcpy(out,text+a,count);out[count]=0;g_cfgPoolUsed+=count+1;return out;
 };
 size_t start=0;
 for(uint8_t fx=0;fx<18;fx++){
  size_t end=start;while(end<n&&text[end]!='\n')end++;
  size_t pipes[3],found=0;for(size_t i=start;i<end;i++)if(text[i]=='|')pipes[found++]=i;
  const size_t name=pipes[0]-start;memcpy(g_fxNameBufs[fx],text+start,name);g_fxNameBufs[fx][name]=0;fxLabels[fx]=g_fxNameBufs[fx];
  for(unsigned field=0;field<2;field++){
   const uint8_t count=layout[fx][field];size_t a=pipes[field]+1;
   for(uint8_t j=0;j<count;j++){
    size_t b=a;while(b<pipes[field+1]&&text[b]!=',')b++;
    const char* label=copy(a,b);if(!label)return false;
    if(field==0)g_knobPtrs[fx][j]=label;else g_dropLblPtrs[fx][j]=label;a=b+1;
   }
  }
  size_t a=pipes[2]+1;
  for(uint8_t d=0;d<layout[fx][1];d++){
   size_t groupEnd=a;while(groupEnd<end&&text[groupEnd]!=';')groupEnd++;
   uint8_t options=0;
   if(a<groupEnd)for(;;){
    size_t b=a;while(b<groupEnd&&text[b]!=':')b++;
    const char* option=copy(a,b);if(!option)return false;g_optStrPtrs[fx][d][options++]=option;
    if(b==groupEnd)break;a=b+1;
   }
   g_optCounts[fx][d]=options;g_optArrPtrs[fx][d]=g_optStrPtrs[fx][d];a=groupEnd+1;
  }
  FX_LAYOUT[fx][0]=layout[fx][0];FX_LAYOUT[fx][1]=layout[fx][1];
  fxLayouts[fx].knobCount=layout[fx][0];fxLayouts[fx].knobLabels=g_knobPtrs[fx];
  fxLayouts[fx].dropCount=layout[fx][1];fxLayouts[fx].dropLabels=layout[fx][1]?g_dropLblPtrs[fx]:nullptr;
  fxLayouts[fx].dropOptions=layout[fx][1]?(const char***)g_optArrPtrs[fx]:nullptr;
  fxLayouts[fx].dropOptionCounts=layout[fx][1]?g_optCounts[fx]:nullptr;
  Serial.printf("[CFG] FX[%2u] %-8s k=%u d=%u\n",unsigned(fx),g_fxNameBufs[fx],unsigned(layout[fx][0]),unsigned(layout[fx][1]));
  start=end+1;
 }
 Serial.printf("[CFG] Loaded 18 effects (pool=%u bytes)\n",unsigned(g_cfgPoolUsed));return true;
}
