#ifndef MY_ROTARY_ENCODER_H
#define MY_ROTARY_ENCODER_H

#include <Arduino.h>

// ---------------------------------------------------------------------------
// PushSwitch – standalone debounced push-button with single / double / long
// ---------------------------------------------------------------------------
class PushSwitch {
public:
  explicit PushSwitch(int pinSw);

  void begin();
  void update();

  bool isButtonPressed();   // single click (consumed on read)
  bool isDoubleClick();     // double click  (consumed on read)
  bool isLongClick();       // long press    (consumed on read)
  bool isHeld() const;      // true while button is currently depressed (not consumed)
  void resetButton();

private:
  void checkButton();

  const int pinSw;

  // debounce
  unsigned long lastDebounceTime;
  static constexpr unsigned long debounceDelay = 50;
  int  buttonState;
  int  lastButtonState;

  // timing
  unsigned long btnPressTime;      // when the button went LOW
  unsigned long lastButtonPress;   // when the last release happened (for double-click)
  unsigned long pendingSingleTime; // when the pending single-click was recorded

  // flags
  bool btnPressed;
  bool doubleClick;
  bool longClick;
  bool pendingSingle; // single click waiting to confirm (not a double)
};

// ---------------------------------------------------------------------------
// RotaryEncoder – quadrature encoder + integrated push-button
// ---------------------------------------------------------------------------
class RotaryEncoder {
public:
  RotaryEncoder(int pinA, int pinB, int pinSw);

  void begin();
  void update();

  int  getPosition() const;
  void setPosition(int position);

  bool isButtonPressed();   // single click (consumed on read)
  bool isDoubleClick();     // double click  (consumed on read)
  bool isLongClick();       // long press    (consumed on read)
  void resetButton();

  // Software injection — lets external code (e.g. MIDI) simulate encoder events
  // without reaching into private members directly.
  void injectRotation(int delta);       // adds delta to encoderPos
  void injectButtonPress();             // simulates a short click
  void injectLongPress();               // simulates a long press

private:
  void calcEncoder();
  void checkButton();

  const int pinA, pinB, pinSw;

  // encoder
  int encoderPos;
  int lastStateA;  // previous A pin reading for edge detection

  // button debounce
  unsigned long lastDebounceTime;
  static constexpr unsigned long debounceDelay = 50;
  int  buttonState;
  int  lastButtonState;

  // button timing
  unsigned long buttonPressStart;
  unsigned long lastButtonPress;

  // button flags
  bool btnPressed;
  bool doubleClick;
  bool longClick;
};

#endif  // MY_ROTARY_ENCODER_H