#include "DisplayManager.h"
#include "JmSetupPortrait.hpp"
#include "JmTunerPortrait.hpp"
#include "JmFxGridPortrait.hpp"
#include "JmFxParamsPortrait.hpp"
#include "JmLooperPortrait.hpp"
#include "JmDrumPortrait.hpp"
#include "MainHomeLogic.hpp"
#include "BluetoothManager_binary.hpp"
#include <string.h>

extern BluetoothManager btManager;
extern void sendToDSP(const char cmd[4], uint8_t* payload, size_t len);
extern void syncMasterVolumeFromDisplay(uint8_t volume);

DisplayManager display;

DisplayManager::DisplayManager() 
  : tft(), currentState(STATE_MAIN_MENU), currentRectIndex(MainHome::FX) {
    
    // Defaults
    lastEncoder1Pos = 0; lastEncoder2Pos = 0;
    currentPresetTypeIndex = 0; currentPresetNumber = 1;
    
    // Connection Defaults
    connUART = false; connWeb = false; connA2DP = false; connMIDI = false;
    bypassEnabled = false;

    // Looper Defaults
    looperEnabled = false;
    looperTrackState = 0; // TS_IDLE
    looperRectIndex = 0; looperAdjusting = false;
    looperLevel = 100; looperNum = 0; looperSync = 0;
    looperAutoArm = true; looperBars = 0; looperPlayMode = 0;
    isRecording = false; loopStart = 0; loopLength = 0; lastStepTime = 0; currentArcAngle = 0.0f; lastArcColor = 0;
    lastBpmBeat = 0; bpmBlinkOn = false;
    loopLayerCount = 0;
    beatLedLastAppearance = -1;
    beatLedLastScreen = -1;
    drumTileNeedsRefresh = false;
    
    // Drum Defaults
    drumEnabled = false;
    drumRectIndex = 0; drumAdjusting = false; drumStyle = 0; drumPattern = 0; drumBPM = 120; drumLevel = 80;
    
    // Setup Defaults
    setupRectIndex = 0; setupAdjusting = false; setupFirstVisible = 0;
    setupConfirmIndex = -1; setupConfirmDeadline = 0;
    noiseEnabled = false; noiseLevel = 50;
    toneEnabled = false; toneLevel = 50; toneFreq = 440;
    btAudioEnabled = true; btAudioVol = 100;

    fxGridIndex = 0; fxEditIndex = 0; fxParamIndex = 0; fxParamAdjusting = false;
    mainMenuAdjusting = false;
    mainPresetNameCache[0] = '\0';
    lastSwitchTime = 0;
    overlayMsg[0] = '\0';
    overlayExpireAt = 0;
    statusLine[0] = '\0';

    // The Main screen now draws directly with TFT_eSPI. No heap-allocated
    // button objects or obsolete 18-effect grid are needed on this screen.
    for (int i = 0; i < TOTAL_MAIN_MENU_RECTS; ++i)
        mainMenuButtons[i] = nullptr;

}

void DisplayManager::begin() {
    tft.init();
    tft.setRotation(2);
    tft.fillScreen(TFT_BLACK);
    refresh();
}

void DisplayManager::handleGlobalInput() {
    int newPos2 = encoder2.getPosition();
    if (newPos2 != lastEncoder2Pos) {
        int delta = newPos2 - lastEncoder2Pos;
        int newVal = currentPreset.masterVolume + (delta * 5);
        if (newVal > 100) newVal = 100;
        if (newVal < 0) newVal = 0;
        if (newVal != currentPreset.masterVolume)
            setVolume((uint8_t)newVal);
        lastEncoder2Pos = newPos2;
    }
}

void DisplayManager::toggleBypass(bool enable) {
    bypassEnabled = enable;
    uint8_t p[1] = { (uint8_t)(enable ? 1 : 0) };
    sendToDSP("BYPS", p, 1);
    if (currentState == STATE_MAIN_MENU)
        drawMainScreen();
    showMessage(enable ? "BYPASS ON" : "BYPASS OFF");
}

void DisplayManager::showMessage(const char* msg) {
    strncpy(overlayMsg, msg, sizeof(overlayMsg) - 1);
    overlayMsg[sizeof(overlayMsg) - 1] = '\0';
    overlayExpireAt = millis() + 2000;

    // A centre-screen alert would cover the live ring and be erased again by
    // its next 40ms update. On the Looper, put notifications in the header.
    looperHeaderOverlay = (currentState == STATE_LOOPER);
    if (looperHeaderOverlay) {
        const uint16_t panel = tft.color565(8,25,44);
        tft.fillRect(0,0,240,29,panel);
        tft.drawFastHLine(0,29,240,tft.color565(41,68,92));
        tft.setTextFont(2);
        tft.setTextDatum(MC_DATUM);
        tft.setTextColor(TFT_YELLOW,panel);
        tft.drawString(overlayMsg,120,15,2);
        return;
    }

    // Box dimensions
    const int BW = 210, BH = 70;
    const int BX = (SCREEN_WIDTH - BW) / 2;
    const int BY = (SCREEN_HEIGHT - BH) / 2;

    // Draw overlay
    tft.fillRoundRect(BX, BY, BW, BH, 8, TFT_BLACK);
    tft.drawRoundRect(BX,     BY,     BW,     BH,     8, TFT_RED);
    tft.drawRoundRect(BX + 1, BY + 1, BW - 2, BH - 2, 7, TFT_RED);  // double border

    tft.setTextDatum(MC_DATUM);
    tft.setFreeFont(&FONT_GENERAL_BOLD);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    tft.drawString(overlayMsg, SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2);
}

void DisplayManager::loop() {
    handleGlobalInput();

    // Clear overlay and restore screen when timer expires
    if (overlayExpireAt > 0 && millis() >= overlayExpireAt) {
        overlayExpireAt = 0;
        overlayMsg[0] = '\0';
        if (looperHeaderOverlay && currentState == STATE_LOOPER) {
            JmLooperPortrait::header(tft);
            looperHeaderOverlay = false;
        } else switch (currentState) {
            case STATE_MAIN_MENU: drawMainScreen();   break;
            case STATE_TUNER:     drawTunerScreen();  break;
            case STATE_LOOPER:    drawLooperScreen();  break;
            case STATE_DRUM:      drawDrumScreen();   break;
            case STATE_SETUP:     drawSetupScreen();  break;
            case STATE_FX_EDIT:   drawFxEditScreen(); break;
            case STATE_FX_GRID:   drawFxGridScreen(); break;
        }
    }

    if (currentState == STATE_LOOPER && looperUiNeedsParameters) {
        looperUiNeedsParameters = false;
        drawLooperSettings();
    }
    switch (currentState) {
        case STATE_MAIN_MENU: handleMainMenu(); break;
        case STATE_LOOPER:    handleLooperMode(); break;
        case STATE_TUNER:     handleTunerMode(); break;
        case STATE_FX_EDIT:   handleFxEditMode(); break;
        case STATE_FX_GRID:   handleFxGridMode(); break;
        case STATE_DRUM:      handleDrumMode(); break;
        case STATE_SETUP:     handleSetupMode(); break;
    }
    if (drumTileNeedsRefresh) {
        drumTileNeedsRefresh = false;
        if (currentState == STATE_MAIN_MENU)
            highlightRect(MainHome::DRUMS, currentRectIndex == MainHome::DRUMS);
    }
    if (currentState == STATE_DRUM && overlayExpireAt == 0)
        updateDrumVisuals();
    // Always visible in the bottom-right corner. No full-screen redraw.
    drawBeatLed();
}

void DisplayManager::refresh() {
    currentPresetTypeIndex = currentPreset.bank;
    currentPresetNumber = currentPreset.number + 1;
    if (currentPresetTypeIndex >= TOTAL_BANKS) currentPresetTypeIndex = TOTAL_BANKS - 1;

    volumeValue = currentPreset.masterVolume;
    bpmValue = currentPreset.bpm;
    memcpy(mainPresetNameCache, currentPreset.name, PRESET_NAME_LENGTH);
    mainPresetNameCache[PRESET_NAME_LENGTH] = '\0';
    for (int i = 0; i < TOTAL_FX; i++) {
        fxEnabled[i] = currentPreset.effects[i].enabled;
    }

    if (currentState == STATE_MAIN_MENU) drawMainScreen();
    else if (currentState == STATE_FX_GRID) drawFxGridScreen();
    else if (currentState == STATE_FX_EDIT) drawFxEditScreen();
}

void DisplayManager::drawStatusLine() {
    // The shared footer owns CPU and BEAT only. No encoder hint text.
    const uint16_t bg=tft.color565(8,24,39);
    tft.fillRect(0,294,240,26,bg);
    tft.drawFastHLine(0,294,240,tft.color565(40,71,99));
    tft.setTextDatum(TL_DATUM);tft.setTextFont(2);
    tft.setTextColor(TFT_WHITE,bg);
    tft.drawString(lastDspCpuPercent<0 ? "CPU --":
                   String("CPU ")+String(lastDspCpuPercent)+"%",9,299,2);
    tft.fillRoundRect(101,304,91,6,2,tft.color565(27,48,66));
    if(lastDspCpuPercent>0)
       tft.fillRoundRect(101,304,91*(lastDspCpuPercent>100?100:lastDspCpuPercent)/100,
                         6,2,tft.color565(0,222,253));
    drawBeatLed(true);
}

void DisplayManager::onDspBeat(const uint8_t* payload, size_t len) {
    const uint32_t now = millis();
    if (!beatClock.Accept(payload, len, now)) return;
    // DSP can auto-start drums at the same sample as record begins.
    if (beatClock.WasAutoStart() && !drumEnabled) {
        drumEnabled = true;
        drumTileNeedsRefresh = true;
    }
    if (beatClock.WasRestarted() && looperTrackState != 3)
        looperBeatPhase.Reset();
    looperBeatPhase.OnBeat(beatClock, now);
    // Rendering is deferred to display.loop(): never redraw TFT on UART input.
}

void DisplayManager::drawBeatLed(bool force) {
    const uint32_t now = millis();
    const bool active = beatClock.Active(now);
    const bool lit = active && beatClock.Lit(now);
    // 0=off, 1=ordinary beat, 2=accented bar downbeat
    const int appearance = lit ? (beatClock.LastWasDownbeat() ? 2 : 1) : 0;
    const int screen = static_cast<int>(currentState);
    if (!force && appearance == beatLedLastAppearance && screen == beatLedLastScreen)
        return;

    // The status bar exists on MAIN; on other pages render the same tiny
    // indicator in the otherwise unused bottom-right corner.
    const int cx = SCREEN_WIDTH - 17, cy = SCREEN_HEIGHT - 16;
    const uint16_t bg=tft.color565(8,24,39);
    tft.fillRect(cx - 8, cy - 8, 17, 17, bg);
    tft.drawCircle(cx, cy, 6, active ? TFT_LIGHTGREY : TFT_DARKGREY);
    tft.fillCircle(cx, cy, 4, appearance == 2 ? TFT_YELLOW :
                                  appearance == 1 ? TFT_GREEN : TFT_DARKGREY);
    beatLedLastAppearance = static_cast<int8_t>(appearance);
    beatLedLastScreen = screen;
}

void DisplayManager::updateStatusLine(const char* msg) {
    strncpy(statusLine,msg,sizeof(statusLine)-1);
    statusLine[sizeof(statusLine)-1]=0;
    float cpu=0;
    if(sscanf(statusLine,"CPU: %f",&cpu)!=1 || cpu<0||cpu>100)return;
    const int next=int(cpu+0.5f);
    if(next==lastDspCpuPercent)return; // no SPI activity for identical LOAD values
    lastDspCpuPercent=next;
    switch(currentState) {
      case STATE_MAIN_MENU:drawStatusLine();break;
      case STATE_FX_GRID:JmFxGrid::footer(tft,next);drawBeatLed(true);break;
      case STATE_FX_EDIT:JmFxPortrait::footer(tft,next);drawBeatLed(true);break;
      case STATE_LOOPER:
        JmLooperPortrait::footerCpu(tft,next);break;
      case STATE_DRUM:{
        JmDrumPortrait::Model m{};m.cpu=next;
        JmDrumPortrait::footer(tft,m);drawBeatLed(true);break;
      }
      case STATE_SETUP:JmSetupPortrait::footer(tft,next);drawBeatLed(true);break;
      case STATE_TUNER:JmTunerPortrait::footer(tft,next);drawBeatLed(true);break;
    }
}

void DisplayManager::setTempo(uint8_t bpm) {
    bpm=bpm<20?20:bpm>250?250:bpm;
    currentPreset.bpm=bpm;bpmValue=bpm;drumBPM=bpm;
    const uint16_t bpm10=uint16_t(bpm)*10;
    const uint8_t ctl[]={1,1,uint8_t(bpm10),uint8_t(bpm10>>8)};
    sendToDSP("TCTL",const_cast<uint8_t*>(ctl),sizeof(ctl));
    // Some deployed Daisy builds apply tempo only through DRUM. Mirror the
    // current ESP-owned settings, not stale browser settings or button pulses.
    // Keep DRUM disabled if drums were stopped, and never disable a live loop.
    if(drumEnabled||looperEnabled||looperTrackState>0){
      uint8_t mirror[12]={uint8_t(drumEnabled),uint8_t(drumLevel),bpm,uint8_t(drumStyle),0,uint8_t(drumPattern),
        uint8_t(looperEnabled||looperTrackState>0),uint8_t((std::min(127,std::max(0,looperLevel))*100+63)/127),
        uint8_t(looperSync),uint8_t(looperAutoArm),uint8_t(looperBars),uint8_t(looperNum)};
      sendToDSP("DRUM",mirror,sizeof(mirror));
    }
    Serial.printf("[TEMPO] Requested %u BPM (transport + active-engine mirror)\n",bpm);
    if(currentState==STATE_MAIN_MENU)highlightRect(MainHome::BPM,currentRectIndex==MainHome::BPM);
}

void DisplayManager::setVolume(uint8_t vol) {
    currentPreset.masterVolume = vol;
    volumeValue = vol;
    syncMasterVolumeFromDisplay(vol);
    uint8_t dspPayload[4] = { vol, 0, currentPreset.bpm, 0 };
    sendToDSP("GEN ", dspPayload, 4);
    uint8_t blePacket[2] = { 0x26, vol };
    btManager.sendBLEData(blePacket, 2);
    
    if (currentState == STATE_MAIN_MENU) {
        highlightRect(MainHome::VOLUME, currentRectIndex == MainHome::VOLUME); 
    }
}