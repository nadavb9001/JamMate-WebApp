#pragma once
// JamMate 240x320 SETUP. TFT_eSPI primitives only, no offscreen bitmap.
// 11 real controls, six visible at a time, one selected row, fixed CPU/beat footer.
#include <TFT_eSPI.h>
#include <stdint.h>
#include <stdio.h>

namespace JmSetupPortrait {
static constexpr int kCount = 11;
static constexpr int kVisible = 6;
static constexpr int kFooterY = 294;
enum Kind : uint8_t { SWITCH, VALUE, ACTION };
struct Item { const char* name; const char* value; uint8_t percent; Kind kind; bool enabled; };
struct Model {
    Item items[kCount];
    uint8_t selected = 0;
    uint8_t first_visible = 0;
    bool editing = false;
    int8_t confirm_action = -1;  // display confirmation only for Reset / Flash
    int cpu = -1;
    bool beat_active = false;
    bool beat_lit = false;
    bool downbeat = false;
};
inline uint16_t rgb(TFT_eSPI& t,uint8_t r,uint8_t g,uint8_t b){return t.color565(r,g,b);}
inline uint16_t bg(TFT_eSPI& t){return rgb(t,3,9,21);}
inline uint16_t panel(TFT_eSPI& t){return rgb(t,10,24,43);}
inline uint16_t edge(TFT_eSPI& t){return rgb(t,39,72,96);}
inline uint16_t white(TFT_eSPI& t){return rgb(t,243,251,255);}
inline uint16_t muted(TFT_eSPI& t){return rgb(t,157,189,215);}
inline uint16_t cyan(TFT_eSPI& t){return rgb(t,0,225,248);}
inline uint16_t amber(TFT_eSPI& t){return rgb(t,255,176,40);}
inline uint16_t green(TFT_eSPI& t){return rgb(t,0,239,137);}
inline uint16_t red(TFT_eSPI& t){return rgb(t,255,76,104);}
inline void label(TFT_eSPI& t,const char* s,int x,int y,uint16_t c,uint16_t b){
    t.setTextDatum(ML_DATUM);t.setTextColor(c,b);t.drawString(s,x,y,2);
}
inline void header(TFT_eSPI& t){
    const uint16_t f=rgb(t,8,25,44);
    t.fillRect(0,0,240,30,f);t.drawFastHLine(0,29,240,edge(t));
    t.fillRoundRect(8,6,4,16,1,cyan(t));label(t,"SETUP",18,15,white(t),f);
}
inline void footer(TFT_eSPI& t,int cpu){
    const uint16_t f=rgb(t,8,24,39);
    t.fillRect(0,kFooterY,240,26,f);t.drawFastHLine(0,kFooterY,240,edge(t));
    char txt[24];if(cpu<0) snprintf(txt,sizeof(txt),"CPU --");
    else snprintf(txt,sizeof(txt),"CPU %d%%",cpu>100?100:cpu);
    label(t,txt,9,307,white(t),f);
    t.fillRoundRect(103,304,85,6,2,rgb(t,29,54,77));
    if(cpu>0)t.fillRoundRect(103,304,(cpu>100?100:cpu)*85/100,6,2,cyan(t));
    // beat LED center (223,304) is controlled by DisplayManager::drawBeatLed
    t.fillCircle(223,304,8,rgb(t,25,57,51));
}
inline void row(TFT_eSPI& t,int line,const Item& i,bool selected,bool editing,bool confirm){
    const int y=36+line*41;const uint16_t outline=selected?(editing||confirm?amber(t):cyan(t)):edge(t);
    const uint16_t fill=selected?rgb(t,13,37,55):panel(t);
    t.fillRoundRect(7,y,220,37,5,fill);t.drawRoundRect(7,y,220,37,5,outline);
    if(selected)t.drawFastVLine(9,y+8,20,outline);
    const uint16_t nameColor=i.kind==ACTION?amber(t):muted(t);
    label(t,i.name,17,y+16,nameColor,fill);
    const char* shown=confirm?"CONFIRM?":i.value;
    t.setTextDatum(MR_DATUM);t.setTextColor(confirm?red(t):(selected?white(t):muted(t)),fill);
    t.drawString(shown,217,y+16,2);
    if(i.kind==VALUE){
        const int w=95;
        t.fillRect(121,y+30,w,3,edge(t));
        t.fillRect(121,y+30,((i.percent>100?100:i.percent)*w)/100,3,selected&&editing?amber(t):cyan(t));
    } else if(i.kind==SWITCH) {
        t.fillRect(170,y+30,46,3,i.enabled?green(t):edge(t));
    }
}
inline void draw(TFT_eSPI& t,const Model& m){
    t.fillScreen(bg(t));header(t);
    const int first=m.first_visible<=kCount-kVisible?m.first_visible:kCount-kVisible;
    for(int j=0;j<kVisible;j++){
        const int index=first+j;
        row(t,j,m.items[index],index==m.selected,m.editing&&index==m.selected,
            m.confirm_action==index);
    }
    // Scroll position indicator. 11 items, 6 visible.
    const int trackY=38,trackH=241;
    t.fillRect(233,trackY,3,trackH,edge(t));
    t.fillRect(233,trackY+(first*trackH)/kCount,3,kVisible*trackH/kCount,cyan(t));
    footer(t,m.cpu);
}
} // namespace JmSetupPortrait
