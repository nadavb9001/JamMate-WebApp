#pragma once
#include <stdint.h>

// Pure, heap-free progress-ring update planner. Never erase the centre, beat,
// bar or footer to advance the ring; only change the 11-pixel annulus.
namespace JmLooperRing {
struct Delta {
    uint16_t erase_begin = 0, erase_end = 0;
    uint16_t paint_begin = 0, paint_end = 0;
    int16_t next = 0;
    bool changed = false;
    bool reset = false;
};

// first/forced/state-change: repaint the annulus once. Small backward clock
// corrections are ignored; a real revolution wraps once at the right edge.
inline Delta Plan(int16_t previous, int16_t requested, bool force) {
    Delta r;
    if (requested < 0) requested = 0;
    if (requested > 360) requested = 360;
    r.next = requested;
    if (force || previous < 0 || previous > 360) {
        r.erase_end = 360;
        r.paint_end = requested;
        r.changed = true;
        r.reset = true;
    } else if (requested == previous) {
        r.next = previous;
    } else if (requested > previous) {
        r.paint_begin = previous;
        r.paint_end = requested;
        r.changed = true;
    } else if ((previous >= 270 && requested <= 110) ||
               (previous - requested > 12)) {
        r.erase_end = previous;
        r.paint_end = requested;
        r.changed = true;
        r.reset = true;
    } else {
        // Ignore a minor backward sample-to-millis correction (<~33 ms on
        // a 1-second revolution). Do not erase/repaint at every BEAT packet.
        r.next = previous;
    }
    return r;
}
}
