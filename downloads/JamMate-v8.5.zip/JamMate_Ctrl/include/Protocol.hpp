#pragma once
#include <stdint.h>
#include <stddef.h>
#include <string.h>

// =================================================================
// 1. CONFIGURATION
// =================================================================
#define MAX_PACKET_SIZE 4096  
#define COBS_DELIMITER  0x00

// =================================================================
// 2. CRC32 (Fast Table-based implementation)
// =================================================================
static uint32_t crc32(const uint8_t* data, size_t len)
{
    static const uint32_t crc_table[16] = {
        0x00000000, 0x1DB71064, 0x3B6E20C8, 0x26D930AC,
        0x76DC4190, 0x6B6B51F4, 0x4DB26158, 0x5005713C,
        0xEDB88320, 0xF00F9344, 0xD6D6A3E8, 0xCB61B38C,
        0x9B64C2B0, 0x86D3D2D4, 0xA00AE278, 0xBDBDF21C
    };

    uint32_t crc = 0xFFFFFFFFu;
    for(size_t i = 0; i < len; i++)
    {
        crc ^= data[i];
        crc = (crc >> 4) ^ crc_table[crc & 0x0F];
        crc = (crc >> 4) ^ crc_table[crc & 0x0F];
    }
    return ~crc;
}

// =================================================================
// 3. COBS ENCODING / DECODING
// =================================================================
// Encodes 'src' into 'dst'. 'dst' must be at least len + len/254 + 1 bytes.
static size_t cobs_encode(const uint8_t *src, size_t len, uint8_t *dst) {
    size_t read_index = 0;
    size_t write_index = 1;
    size_t code_index = 0;
    uint8_t code = 1;

    while (read_index < len) {
        if (src[read_index] == 0) {
            dst[code_index] = code;
            code = 1;
            code_index = write_index++;
            read_index++;
        } else {
            dst[write_index++] = src[read_index++];
            code++;
            if (code == 0xFF) {
                dst[code_index] = code;
                code = 1;
                code_index = write_index++;
            }
        }
    }
    dst[code_index] = code;
    return write_index;
}

// Decodes 'src' into 'dst'. Returns 0 on error.
static size_t cobs_decode(const uint8_t *src, size_t len, uint8_t *dst) {
    size_t read_index = 0;
    size_t write_index = 0;
    uint8_t code;
    uint8_t i;

    while (read_index < len) {
        code = src[read_index];
        if (read_index + code > len && code != 1) return 0; // Error
        read_index++;

        for (i = 1; i < code; i++) {
            dst[write_index++] = src[read_index++];
        }
        if (code < 0xFF && read_index != len) {
            dst[write_index++] = 0;
        }
    }
    return write_index;
}

// =================================================================
// 4. PACKET STRUCTURE HELPER
// =================================================================
struct PacketHeader {
    uint32_t magic; // Optional safety
    uint32_t type;  // Command ID
    uint32_t len;   // Payload Length
    uint32_t crc;   // CRC of Payload
};

// Helper to build a packet buffer before encoding
// Buffer layout: [Header][Payload]
static void prepare_packet(uint8_t* buf, uint32_t type, const uint8_t* payload, uint32_t len) {
    PacketHeader* hdr = (PacketHeader*)buf;
    hdr->type = type;
    hdr->len = len;
    hdr->crc = crc32(payload, len);
    if (payload && len > 0) {
        memcpy(buf + sizeof(PacketHeader), payload, len);
    }
}

// =================================================================
// 5. JAMMATE PROTOCOL V2 ENVELOPE (migration-safe)
// =================================================================
// V2 runs INSIDE the existing PacketHeader/COBS frame using outer type "JMP2".
// This lets legacy commands (GATE/COMP/NAMH/...) coexist while command families
// migrate incrementally to the reliable transaction protocol.
//
// Wire layout for a V2 outer packet:
//   legacy PacketHeader.type = FOURCC("JMP2")
//   legacy payload           = [Jm2Header][Jm2 application payload]
//
// The existing outer CRC32 protects the complete Jm2Header + payload.

static constexpr uint16_t JM2_MAGIC   = 0x4D4Au; // bytes 'J','M' on little-endian MCU
static constexpr uint8_t  JM2_VERSION = 2u;

static constexpr uint32_t jm_fourcc(const char a,
                                    const char b,
                                    const char c,
                                    const char d)
{
    return ((uint32_t)(uint8_t)a)
         | ((uint32_t)(uint8_t)b << 8)
         | ((uint32_t)(uint8_t)c << 16)
         | ((uint32_t)(uint8_t)d << 24);
}

static inline uint32_t jm_fourcc(const char s[4])
{
    return jm_fourcc(s[0], s[1], s[2], s[3]);
}

static constexpr uint32_t JM2_OUTER_TYPE = jm_fourcc('J','M','P','2');

// Common V2 application message types.
static constexpr uint32_t JM2_HELO = jm_fourcc('H','E','L','O');
static constexpr uint32_t JM2_HELA = jm_fourcc('H','E','L','A');
static constexpr uint32_t JM2_ACK  = jm_fourcc('A','C','K',' ');
static constexpr uint32_t JM2_NACK = jm_fourcc('N','A','C','K');
static constexpr uint32_t JM2_PING = jm_fourcc('P','I','N','G');
static constexpr uint32_t JM2_PONG = jm_fourcc('P','O','N','G');
static constexpr uint32_t JM2_LOAD = jm_fourcc('L','O','A','D');
static constexpr uint32_t JM2_FREQ = jm_fourcc('F','R','E','Q');

// Future migration targets (not enabled by this foundation revision yet).
static constexpr uint32_t JM2_EFFT = jm_fourcc('E','F','F','T');
static constexpr uint32_t JM2_PBEG = jm_fourcc('P','B','E','G');
static constexpr uint32_t JM2_PDAT = jm_fourcc('P','D','A','T');
static constexpr uint32_t JM2_PEND = jm_fourcc('P','E','N','D');
static constexpr uint32_t JM2_SBEG = jm_fourcc('S','B','E','G');
static constexpr uint32_t JM2_SDAT = jm_fourcc('S','D','A','T');
static constexpr uint32_t JM2_SEND = jm_fourcc('S','E','N','D');

// Transport flags. Telemetry deliberately has no ACK requirement.
enum Jm2Flags : uint8_t
{
    JM2_F_RELIABLE  = 1u << 0,
    JM2_F_ACK       = 1u << 1,
    JM2_F_NACK      = 1u << 2,
    JM2_F_STREAM    = 1u << 3,
    JM2_F_TELEMETRY = 1u << 4,
};

#pragma pack(push, 1)
struct Jm2Header
{
    uint16_t magic;        // JM2_MAGIC
    uint8_t  version;      // JM2_VERSION
    uint8_t  flags;        // Jm2Flags
    uint32_t type;         // fourcc application type
    uint16_t transaction;  // groups a reliable operation / stream
    uint16_t sequence;     // packet index within transaction
    uint16_t payload_len;  // bytes following Jm2Header
    uint16_t reserved;     // must be zero for v2
};
#pragma pack(pop)

static_assert(sizeof(Jm2Header) == 16, "Jm2Header must remain 16 bytes");

struct Jm2PacketView
{
    const Jm2Header* header;
    const uint8_t*   payload;
};

// Build [Jm2Header][payload] into dst. Returns encoded envelope size, or 0.
static inline size_t jm2_build(uint8_t*       dst,
                               size_t         dst_capacity,
                               uint32_t       type,
                               uint8_t        flags,
                               uint16_t       transaction,
                               uint16_t       sequence,
                               const uint8_t* payload,
                               uint16_t       payload_len)
{
    const size_t total = sizeof(Jm2Header) + payload_len;
    if(dst == nullptr || total > dst_capacity)
        return 0;

    Jm2Header hdr{};
    hdr.magic       = JM2_MAGIC;
    hdr.version     = JM2_VERSION;
    hdr.flags       = flags;
    hdr.type        = type;
    hdr.transaction = transaction;
    hdr.sequence    = sequence;
    hdr.payload_len = payload_len;
    hdr.reserved    = 0;
    memcpy(dst, &hdr, sizeof(hdr));
    if(payload_len && payload)
        memcpy(dst + sizeof(hdr), payload, payload_len);
    return total;
}

// Validate an already CRC-checked outer JMP2 payload.
static inline bool jm2_parse(const uint8_t* data,
                             size_t         len,
                             Jm2PacketView* out)
{
    if(data == nullptr || out == nullptr || len < sizeof(Jm2Header))
        return false;

    const Jm2Header* hdr = (const Jm2Header*)data;
    if(hdr->magic != JM2_MAGIC || hdr->version != JM2_VERSION)
        return false;

    const size_t expected = sizeof(Jm2Header) + (size_t)hdr->payload_len;
    if(expected != len)
        return false;

    out->header  = hdr;
    out->payload = data + sizeof(Jm2Header);
    return true;
}

#pragma pack(push, 1)
struct Jm2HelloPayload
{
    uint16_t max_payload;    // largest V2 app payload accepted by sender
    uint16_t stream_chunk;   // preferred future bulk chunk size
    uint8_t  stream_window;  // preferred future bulk window
    uint8_t  reserved[3];
    uint32_t capabilities;
};
#pragma pack(pop)


#pragma pack(push, 1)
struct Jm2PresetBeginPayload
{
    uint16_t item_count;
    uint8_t  bank;
    uint8_t  preset;
    uint8_t  master_volume;
    uint8_t  bpm;
};

struct Jm2PresetEndPayload
{
    uint16_t item_count;
};
#pragma pack(pop)

// =================================================================
// 6. GENERIC BULK STREAM PAYLOADS
// =================================================================
// SBEG payload = Jm2StreamBeginPayload followed by metadata_len bytes.
// SDAT payload = Jm2StreamDataHeader followed by data_len bytes.
// SEND payload = Jm2StreamEndPayload.
//
// v6 migrates NAM onto this generic transport. IR/audio/resource files can
// reuse the exact same envelope later without changing UART framing.
static constexpr uint8_t  JM2_STREAM_OBJECT_NAM = 1u;
static constexpr uint8_t  JM2_STREAM_OBJECT_IR  = 2u;
static constexpr uint8_t  JM2_STREAM_OBJECT_AUDIO = 3u;
static constexpr uint16_t JM2_STREAM_CHUNK_BYTES = 128u;

#pragma pack(push, 1)
struct Jm2StreamBeginPayload
{
    uint8_t  object_type;
    uint8_t  reserved0;
    uint16_t chunk_size;
    uint32_t total_bytes;
    uint32_t object_crc32;
    uint32_t item_count;     // NAM: weight count; future objects may use 0
    uint16_t metadata_len;   // bytes immediately following this struct
    uint16_t reserved1;
};

struct Jm2StreamDataHeader
{
    uint32_t offset;
    uint16_t data_len;
    uint16_t reserved;
};

struct Jm2StreamEndPayload
{
    uint8_t  object_type;
    uint8_t  reserved[3];
    uint32_t total_bytes;
    uint32_t object_crc32;
    uint32_t item_count;
};

// ACK payload for stream packets. Header.transaction/header.sequence still
// identify the packet being acknowledged; next_sequence/received_bytes make
// the protocol ready for a future cumulative/sliding-window sender.
#define JM2_STREAM_REASON_CODES_V1 1
enum Jm2StreamError : uint16_t
{
    JM2_STREAM_OK              = 0u,
    JM2_STREAM_BAD_SEQUENCE    = 1u,
    JM2_STREAM_BAD_OFFSET      = 2u,
    JM2_STREAM_BAD_LENGTH      = 3u,
    JM2_STREAM_OVERFLOW        = 4u,
    JM2_STREAM_BAD_DATA        = 5u,
    JM2_STREAM_BAD_TRANSACTION = 6u,
    JM2_STREAM_BAD_METADATA    = 7u,
    JM2_STREAM_BAD_CRC         = 8u,
    JM2_STREAM_INCOMPLETE      = 9u,
    JM2_STREAM_LOAD_FAILED     = 10u,
    JM2_STREAM_BUSY            = 11u,
};

struct Jm2StreamAckPayload
{
    uint16_t next_sequence;
    uint16_t reserved;        // v6.1+: Jm2StreamError; 0 for ACK
    uint32_t received_bytes; // receiver-authoritative resume offset
};
#pragma pack(pop)

static_assert(sizeof(Jm2StreamBeginPayload) == 20, "stream begin layout changed");
static_assert(sizeof(Jm2StreamDataHeader) == 8, "stream data layout changed");
static_assert(sizeof(Jm2StreamEndPayload) == 16, "stream end layout changed");
static_assert(sizeof(Jm2StreamAckPayload) == 8, "stream ack layout changed");

static constexpr uint32_t JM2_CAP_EFFECTS = 1u << 0;
static constexpr uint32_t JM2_CAP_PRESETS = 1u << 1;
static constexpr uint32_t JM2_CAP_NAM     = 1u << 2;
static constexpr uint32_t JM2_CAP_IR      = 1u << 3;
static constexpr uint32_t JM2_CAP_TUNER   = 1u << 4;
static constexpr uint32_t JM2_CAP_AUDIO   = 1u << 5;
