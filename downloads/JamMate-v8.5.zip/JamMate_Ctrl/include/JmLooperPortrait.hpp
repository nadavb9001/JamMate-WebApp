#pragma once
// JamMate looper, 240x320 portrait, TFT_eSPI. Pure drawing (no UART/control).
// Layout: header 0-29; enlarged ring + beat/state panel 33-190;
// six editable parameters 194-290; CPU+DSP beat status footer 294-319.
#include <TFT_eSPI.h>
#include <stdint.h>
#include <math.h>
#include <stdio.h>
#include <string.h>

namespace JmLooperPortrait {

static constexpr int W = 240;
static constexpr int H = 320;

enum TrackState : uint8_t {
    UNKNOWN=255, IDLE=0, ARMED=1, WAIT=2, RECORDING=3, PLAYING=4
};

// selected parameter order matches current LOOP packet / DisplayManager_Tools.cpp:
// 0 Level, 1 Track, 2 Sync, 3 AutoArm, 4 Bars, 5 Play.
struct Model {
    uint8_t track = 0;                 // zero-based, selected track
    uint8_t state = IDLE;
    uint8_t layers = 0;                // selected track only
    uint8_t level = 100;               // 0..127
    uint8_t sync = 3;                  // 0 None, 1 Beat, 2 Bar, 3 DrumStart
    bool auto_arm = true;
    uint8_t bars = 4;                  // 0 Free; 1..16
    uint8_t play_mode = 0;             // 0 Parallel, 1 Series
    uint8_t selected = 2;              // 0..5
    bool editing = false;
    float progress = -1.f;             // 0..1 if known, -1 unknown
    uint8_t loop_bar = 0;              // 1-based, 0 unknown
    uint8_t beat = 0;                  // 1-based, 0 means no recent beat
    uint8_t beats_per_bar = 4;
    bool beat_lit = false;
    bool downbeat = false;
    int cpu = -1;                      // 0..100, -1 unknown
    // Only selected track is authoritative until DSP supplies per-track status.
    uint8_t other_states[4] = {UNKNOWN,UNKNOWN,UNKNOWN,UNKNOWN};
    uint8_t other_layers[4] = {0,0,0,0};
};

static inline uint16_t c(TFT_eSPI &t, uint8_t r, uint8_t g, uint8_t b) {
    return t.color565(r,g,b);
}

static inline uint16_t bg(TFT_eSPI& t) { return c(t,3,9,21); }
static inline uint16_t panel(TFT_eSPI& t) { return c(t,10,23,41); }
static inline uint16_t line(TFT_eSPI& t) { return c(t,41,68,92); }
static inline uint16_t white(TFT_eSPI& t) { return c(t,238,248,255); }
static inline uint16_t muted(TFT_eSPI& t) { return c(t,166,191,215); }
static inline uint16_t green(TFT_eSPI& t) { return c(t,0,244,140); }
static inline uint16_t cyan(TFT_eSPI& t) { return c(t,0,222,253); }
static inline uint16_t amber(TFT_eSPI& t) { return c(t,255,184,52); }
static inline uint16_t red(TFT_eSPI& t) { return c(t,255,72,102); }

static inline uint16_t stateColor(TFT_eSPI& t, uint8_t state) {
    switch (state) {
        case PLAYING: return green(t);
        case RECORDING: return red(t);
        case ARMED: return amber(t);
        case WAIT: return c(t,255,134,39);
        default: return muted(t);
    }
}
static inline const char* stateName(uint8_t state) {
    switch (state) {
        case PLAYING: return "PLAYING";
        case RECORDING: return "RECORD";
        case ARMED: return "ARMED";
        case WAIT: return "WAIT";
        default: return "IDLE";
    }
}
static inline void centered(TFT_eSPI& t, const char* s, int x, int y, int font,
                             uint16_t fg, uint16_t background) {
    t.setTextFont(font);
    t.setTextDatum(MC_DATUM);
    t.setTextColor(fg,background);
    t.drawString(s,x,y,font);
}
static inline void left(TFT_eSPI& t, const char* s, int x, int y, int font,
                         uint16_t fg, uint16_t background) {
    t.setTextFont(font);
    t.setTextDatum(TL_DATUM);
    t.setTextColor(fg,background);
    t.drawString(s,x,y,font);
}
static constexpr int DYNAMIC_X=7;
static constexpr int DYNAMIC_Y=33;
static constexpr int DYNAMIC_W=226;
static constexpr int DYNAMIC_H=157;

static inline void header(TFT_eSPI& t) {
    const uint16_t top=c(t,8,25,44);
    t.fillRect(0,0,W,29,top);
    t.drawFastHLine(0,29,W,line(t));
    t.fillRoundRect(8,6,4,16,1,green(t));
    left(t,"LOOPER",18,4,4,white(t),top);
    // No four-track icon strip. Track number remains visible next to beat info.
}

struct RingPoint { int16_t xInner,yInner,xOuter,yOuter; };
static inline const RingPoint* ringGeometry(){
    // Prepare once per ESP process, NOT at each animation frame. 360 radial
    // segments form an 11px-thick ring without any drawArc sprite requirement.
    static RingPoint p[360];
    static bool initialized=false;
    if(!initialized){
        for(int i=0;i<360;++i){
            const float a=(float)(i-90)*0.01745329251994329577f;
            const float cs=cosf(a),sn=sinf(a);
            p[i].xInner=(int16_t)lroundf(cs*56.f);
            p[i].yInner=(int16_t)lroundf(sn*56.f);
            p[i].xOuter=(int16_t)lroundf(cs*68.f);
            p[i].yOuter=(int16_t)lroundf(sn*68.f);
        }
        initialized=true;
    }
    return p;
}

// The older Looper was smooth because it advanced only the new arc segment.
// Keep the portrait layout, but likewise never repaint the beat panel or the
// ring centre for an ordinary animation frame.
static inline void ringSegments(TFT_eSPI& t, int first, int end, uint16_t color){
    if(first<0)first=0;
    if(end>360)end=360;
    const RingPoint* p=ringGeometry();
    const int cx=DYNAMIC_X+79,cy=DYNAMIC_Y+78;
    for(int i=first;i<end;++i)
        t.drawLine(cx+p[i].xInner,cy+p[i].yInner,
                   cx+p[i].xOuter,cy+p[i].yOuter,color);
}

static inline void staticDynamic(TFT_eSPI& t){
    const uint16_t area=c(t,7,17,31);
    t.fillRoundRect(DYNAMIC_X,DYNAMIC_Y,DYNAMIC_W,DYNAMIC_H,8,area);
    t.drawRoundRect(DYNAMIC_X,DYNAMIC_Y,DYNAMIC_W,DYNAMIC_H,8,line(t));
    ringSegments(t,0,360,c(t,33,58,77));
    left(t,"BEAT",DYNAMIC_X+159,DYNAMIC_Y+38,2,cyan(t),area);
}

// Inside the 56px inner radius, never touches the 11px ring.
static inline void ringCentre(TFT_eSPI& t,const Model& m){
    constexpr int SW=90,SH=57;
    const uint16_t area=c(t,7,17,31);
    const uint16_t accent=stateColor(t,m.state);
    const int cx=DYNAMIC_X+79,cy=DYNAMIC_Y+78;
    const char* label="IDLE";
    switch(m.state){
        case RECORDING:label="REC";break;
        case PLAYING:label="PLAY";break;
        case ARMED:label="ARM";break;
        case WAIT:label="WAIT";break;
    }
    char b[25];
    snprintf(b,sizeof(b),"LAYER %u",(unsigned)m.layers);
    static TFT_eSprite centre(&t);
    static bool ready=false,ok=false;
    if(!ready){ready=true;centre.setColorDepth(8);ok=centre.createSprite(SW,SH)!=nullptr;}
    if(ok){
        centre.fillSprite(area);
        centered(centre,label,SW/2,19,4,accent,area);
        centered(centre,b,SW/2,47,2,white(t),area);
        centre.pushSprite(cx-SW/2,cy-29);
    } else {
        t.fillRect(cx-SW/2,cy-29,SW,SH,area);
        centered(t,label,cx,cy-10,4,accent,area);
        centered(t,b,cx,cy+18,2,white(t),area);
    }
}

static inline void trackLabel(TFT_eSPI& t,const Model& m){
    const uint16_t area=c(t,7,17,31);
    char b[22];
    snprintf(b,sizeof(b),"TRACK %u",(unsigned)m.track+1);
    t.fillRect(DYNAMIC_X+151,DYNAMIC_Y+9,74,22,area);
    left(t,b,DYNAMIC_X+151,DYNAMIC_Y+11,2,muted(t),area);
}

// One small sprite per changing text field is pushed atomically. This avoids
// blank-then-write flashes on the high-contrast beat and bar readouts.
static inline void beatNumber(TFT_eSPI& t,const Model& m){
    constexpr int X=DYNAMIC_X+148, Y=DYNAMIC_Y+59, SW=77, SH=43;
    const uint16_t area=c(t,7,17,31);
    char b[26];
    const int n=m.beats_per_bar?m.beats_per_bar:4;
    if(!m.beat)snprintf(b,sizeof(b),"--/%d",n);
    else snprintf(b,sizeof(b),"%u/%d",(unsigned)m.beat,n);
    const uint16_t fg=(m.beat==1)?amber(t):white(t);
    static TFT_eSprite digits(&t);
    static bool ready=false,ok=false;
    if(!ready){ready=true;digits.setColorDepth(8);ok=digits.createSprite(SW,SH)!=nullptr;}
    if(ok){
        digits.fillSprite(area);
        centered(digits,b,SW/2,SH/2,n>=10?2:4,fg,area);
        digits.pushSprite(X,Y);
    } else {
        t.fillRect(X,Y,SW,SH,area);
        centered(t,b,X+SW/2,Y+SH/2,n>=10?2:4,fg,area);
    }
}

static inline void barNumber(TFT_eSPI& t,const Model& m){
    constexpr int X=DYNAMIC_X+148,Y=DYNAMIC_Y+105,SW=77,SH=20;
    const uint16_t area=c(t,7,17,31);
    char b[26];
    if(m.bars==0)strcpy(b,"BAR FREE");
    else if(m.loop_bar==0)snprintf(b,sizeof(b),"BAR --/%u",(unsigned)m.bars);
    else snprintf(b,sizeof(b),"BAR %u/%u",(unsigned)m.loop_bar,(unsigned)m.bars);
    static TFT_eSprite digits(&t);
    static bool ready=false,ok=false;
    if(!ready){ready=true;digits.setColorDepth(8);ok=digits.createSprite(SW,SH)!=nullptr;}
    if(ok){
        digits.fillSprite(area);
        left(digits,b,3,2,2,muted(t),area);
        digits.pushSprite(X,Y);
    } else {
        t.fillRect(X,Y,SW,SH,area);
        left(t,b,X+3,Y+2,2,muted(t),area);
    }
}

static inline void beatMarkers(TFT_eSPI& t,const Model& m){
    constexpr int X=DYNAMIC_X+149,Y=DYNAMIC_Y+130,SW=76,SH=16;
    const uint16_t area=c(t,7,17,31);
    const uint16_t faint=c(t,33,58,77);
    const int n=m.beats_per_bar?m.beats_per_bar:4;
    static TFT_eSprite dots(&t);
    static bool ready=false,ok=false;
    if(!ready){ready=true;dots.setColorDepth(8);ok=dots.createSprite(SW,SH)!=nullptr;}
    TFT_eSPI& dst = ok?static_cast<TFT_eSPI&>(dots):t;
    if(ok) dots.fillSprite(area);
    else t.fillRect(X,Y,SW,SH,area);
    if(n<=8){
        const int width=n<=4?13:7;
        const int gap=n<=4?4:2;
        for(int i=0;i<n;++i){
            const int x=(ok?4:X+4)+i*(width+gap);
            dst.fillRoundRect(x,ok?5:Y+5,width,6,2,
                              m.beat==i+1?(i==0?amber(t):green(t)):faint);
        }
    }
    if(ok) dots.pushSprite(X,Y);
}

// Full panel draw only on entry or after a complete screen refresh; the normal
// 25fps path calls ringSegments for newly swept angles only.
static inline void dynamic(TFT_eSPI& t,const Model& m){
    staticDynamic(t);
    float f=m.progress<0.f?0.f:m.progress;
    if(f>1.f)f=1.f;
    ringSegments(t,0,(int)(f*360.f+0.5f),stateColor(t,m.state));
    ringCentre(t,m);
    trackLabel(t,m);
    beatNumber(t,m);
    barNumber(t,m);
    beatMarkers(t,m);
}

static inline void parameter(TFT_eSPI& t,const Model& m,int i){
    if(i<0||i>5)return;
    static const char* labels[6]={"LEVEL","TRACK","SYNC","AUTO ARM","BARS","PLAY MODE"};
    char value[16]{};
    switch(i){
        case 0:snprintf(value,sizeof(value),"%u / 127",(unsigned)m.level);break;
        case 1:snprintf(value,sizeof(value),"T%u",(unsigned)m.track+1);break;
        case 2:{
            static const char* syncOpts[4]={"NONE","BEAT","BAR","DRUMSTART"};
            strncpy(value,syncOpts[m.sync<4?m.sync:0],sizeof(value)-1);
        }break;
        case 3:strcpy(value,m.auto_arm?"ON":"OFF");break;
        case 4:
            if(!m.bars)strcpy(value,"FREE");
            else snprintf(value,sizeof(value),"%u",(unsigned)m.bars);
            break;
        case 5:strcpy(value,m.play_mode==1?"SERIES":"PARALLEL");break;
    }
    const int x=7+(i%2)*115;
    const int y=194+(i/2)*33;
    const bool selected=(m.selected==i);
    const uint16_t edge=selected?(m.editing?amber(t):cyan(t)):line(t);
    const uint16_t fill=selected?
        (m.editing?c(t,45,30,19):c(t,13,41,58)):panel(t);
    t.fillRoundRect(x,y,111,30,5,fill);
    t.drawRoundRect(x,y,111,30,5,edge);
    if(selected)t.drawRoundRect(x+1,y+1,109,28,4,edge);
    left(t,labels[i],x+7,y+1,2,selected?white(t):muted(t),fill);
    left(t,value,x+7,y+15,2,selected?(m.editing?amber(t):cyan(t)):white(t),fill);
    if(i==0){
        t.fillRect(x+69,y+26,35,2,line(t));
        t.fillRect(x+69,y+26,(35*(int)m.level)/127,2,green(t));
    }
}

static inline void parameters(TFT_eSPI& t,const Model& m){
    for(int i=0;i<6;++i)parameter(t,m,i);
}

// CPU is independent of the beat LED: update only the first 194px of the
// footer when LOAD changes. This never clears the LED or drum/loop counters.
static inline void footerCpu(TFT_eSPI& t,int cpu){
    const uint16_t area=c(t,8,24,39);
    t.fillRect(0,295,195,25,area);
    t.drawFastHLine(0,294,195,line(t));
    char b[20];
    if(cpu>=0)snprintf(b,sizeof(b),"CPU %d%%",cpu>100?100:cpu);
    else strcpy(b,"CPU --");
    left(t,b,9,299,2,white(t),area);
    t.fillRoundRect(101,304,91,6,2,c(t,27,48,66));
    if(cpu>0)t.fillRoundRect(101,304,(91*(cpu>100?100:cpu))/100,6,2,cyan(t));
}

static inline void footer(TFT_eSPI& t,const Model& m){
    const uint16_t area=c(t,8,24,39);
    t.fillRect(0,294,240,26,area);
    t.drawFastHLine(0,294,240,line(t));
    footerCpu(t,m.cpu);
    t.fillCircle(223,307,11,c(t,7,50,39));
    t.drawCircle(223,307,8,c(t,31,131,85));
    t.fillCircle(223,307,5,m.beat_lit?(m.downbeat?amber(t):green(t)):c(t,27,64,53));
}

static inline void draw(TFT_eSPI& t, const Model& m) {
    t.fillScreen(bg(t));
    header(t);
    dynamic(t,m);
    parameters(t,m);
    footer(t,m);
}
}
