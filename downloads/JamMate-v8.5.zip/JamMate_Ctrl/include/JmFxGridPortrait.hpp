#pragma once
#include <TFT_eSPI.h>
#include <stdint.h>

// Display order (user-facing) is intentionally independent of DSP/config order.
namespace JmFxGrid {
static constexpr uint8_t order[18] = {0,1,2,3,4,15,5,6,7,8,9,10,11,12,13,14,16,17};
static constexpr const char* names[18] = {
  "GATE","COMP","WAH","DRIV","DIST","NAM",
  "EQ","HARM","VIBR","CHOR","OCTV","FLNG",
  "PHSR","TREM","AMP","DELY","RVRB","GNRC"
};
static inline uint16_t c(TFT_eSPI& t,int r,int g,int b){return t.color565(r,g,b);}
static inline uint16_t bg(TFT_eSPI& t){return c(t,3,9,21);}
static inline uint16_t bar(TFT_eSPI& t){return c(t,8,24,39);}
static inline uint16_t accent(TFT_eSPI& t, int n){
  static const uint8_t rgb[6][3]={{0,220,250},{255,182,42},{238,55,179},
                                  {8,234,127},{77,145,255},{190,94,247}};
  return c(t,rgb[n%6][0],rgb[n%6][1],rgb[n%6][2]);
}
static inline int dsp(int n){return order[n];}
static inline void tile(TFT_eSPI& t,int cell,bool enabled,bool selected){
    if(cell<0||cell>=18)return;
    const int x=5+(cell%3)*78, y=34+(cell/3)*43;
    const int w=74,h=39;
    const uint16_t active=accent(t,cell);
    const uint16_t edge=selected?c(t,0,255,255):enabled?active:c(t,53,75,95);
    const uint16_t body=selected?c(t,13,42,62):enabled?c(t,6,27,42):c(t,6,16,27);
    t.fillRoundRect(x,y,w,h,6,body);
    t.drawRoundRect(x,y,w,h,6,edge);
    if(selected)t.drawRoundRect(x+1,y+1,w-2,h-2,5,edge);
    // Tiny vector glyphs: enough personality without sacrificing label size.
    const uint16_t glyph=enabled?active:c(t,62,81,97);
    switch(cell % 6){
      case 0: // gates / envelope
        for(int n=0;n<5;n++) t.drawFastVLine(x+12+n*6,y+6+n/2,13-n*2,glyph);
        break;
      case 1: // compression curve
        t.drawLine(x+11,y+16,x+22,y+16,glyph);
        t.drawLine(x+22,y+16,x+29,y+8,glyph);
        t.drawLine(x+29,y+8,x+43,y+8,glyph);
        break;
      case 2: // waves / filters
        t.drawLine(x+11,y+15,x+18,y+6,glyph);
        t.drawLine(x+18,y+6,x+25,y+15,glyph);
        t.drawLine(x+25,y+15,x+33,y+6,glyph);
        t.drawLine(x+33,y+6,x+41,y+15,glyph);
        break;
      case 3: // drive slope
        t.drawLine(x+12,y+17,x+20,y+12,glyph);
        t.drawLine(x+20,y+12,x+28,y+9,glyph);
        t.drawLine(x+28,y+9,x+41,y+7,glyph);
        break;
      case 4: // pedal box
        t.drawRoundRect(x+14,y+5,26,14,3,glyph);
        t.fillCircle(x+23,y+11,2,glyph);
        t.fillCircle(x+32,y+11,2,glyph);
        break;
      default: // phase / modulation
        t.drawCircle(x+22,y+11,7,glyph);
        t.drawCircle(x+33,y+11,7,glyph);
        break;
    }
    t.fillCircle(x+w-11,y+9,3,enabled?c(t,0,239,137):c(t,70,84,102));
    t.setTextDatum(MC_DATUM);
    t.setTextFont(2);
    t.setTextColor(selected?TFT_WHITE:enabled?c(t,236,247,255):c(t,137,158,179),body);
    t.drawString(names[cell],x+w/2,y+26,2);
}
static inline void footer(TFT_eSPI& t,int cpu){
    const uint16_t b=bar(t);
    t.fillRect(0,294,240,26,b);
    t.drawFastHLine(0,294,240,c(t,45,74,94));
    t.setTextDatum(TL_DATUM);t.setTextFont(2);
    t.setTextColor(TFT_WHITE,b);
    if(cpu<0)t.drawString("CPU --",9,299,2);
    else t.drawString(String("CPU ")+String(cpu>100?100:cpu)+"%",9,299,2);
    t.fillRoundRect(101,304,91,6,2,c(t,27,48,66));
    if(cpu>0)t.fillRoundRect(101,304,(91*(cpu>100?100:cpu))/100,6,2,c(t,0,222,253));
}
static inline void draw(TFT_eSPI& t,const bool states[18],int selected,int cpu){
   t.fillScreen(bg(t));
   t.fillRect(0,0,240,29,c(t,8,25,44));
   t.fillRoundRect(8,6,4,16,1,c(t,0,222,253));
   t.setTextDatum(TL_DATUM);t.setTextFont(4);
   t.setTextColor(TFT_WHITE,c(t,8,25,44));t.drawString("FX",21,1,4);
   t.setTextFont(2);t.setTextColor(c(t,155,196,215),c(t,8,25,44));
   t.drawRightString("18 EFFECTS",230,8,2);
   for(int i=0;i<18;i++)tile(t,i,states[dsp(i)],i==selected);
   footer(t,cpu);
}
}
