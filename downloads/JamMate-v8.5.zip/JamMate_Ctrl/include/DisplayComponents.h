#pragma once
#include <TFT_eSPI.h> // <--- FIXED: Required for TFT_eSPI types
#include "DisplayConstants.h"

// --- Structs ---
struct FxLayout {
    uint8_t knobCount;
    const char** knobLabels;
    uint8_t dropCount;
    const char** dropLabels;
    const char*** dropOptions;      
    const uint8_t* dropOptionCounts;
};

// --- Base Button Class ---
class RectButton {
public:
    int x, y, w, h, radius;
    uint16_t bgColor, borderColor, progressColor;
    String label;
    RectButtonType type;
    uint8_t progressValue;
    bool selected, enabled, highlighted;

    RectButton(int x, int y, int w, int h, int radius, uint16_t bg, uint16_t border, String label, RectButtonType type = RECT_BUTTON)
        : x(x), y(y), w(w), h(h), radius(radius), bgColor(bg), borderColor(border), label(label), type(type),
          progressColor(TFT_GREEN), progressValue(0), selected(false), enabled(true), highlighted(false) {}
    virtual ~RectButton() {}
    virtual void draw(TFT_eSPI& tft) {}
};

// --- Enhanced Button Class ---
class EnhancedRectButton : public RectButton {
public:
    EnhancedRectButton(int x, int y, int w, int h, int radius, uint16_t bg, uint16_t border, String label, RectButtonType type = RECT_BUTTON)
        : RectButton(x, y, w, h, radius, bg, border, label, type) {}
    
    // Defined in DisplayData.cpp
    void drawWithFont(TFT_eSPI& tft, const GFXfont* font);
};

// --- External Data Declarations ---
extern const char* presetNames[TOTAL_BANKS];
extern const char* fxLabels[TOTAL_FX];
extern const uint16_t fxColors[7];
extern const char* extraLabels[TOTAL_EXTRA_BUTTONS];
extern const uint16_t extraColors[TOTAL_EXTRA_BUTTONS];
extern FxLayout fxLayouts[TOTAL_FX];  // mutable — updated at runtime by loadFxLayoutFromConfig()

// --- Font Declarations ---
extern const GFXfont& FONT_GENERAL_NORMAL;
extern const GFXfont& FONT_GENERAL_BOLD;
extern const GFXfont& FONT_PRESET_TITLE_NORMAL;
extern const GFXfont& FONT_LOOPER_BIG;