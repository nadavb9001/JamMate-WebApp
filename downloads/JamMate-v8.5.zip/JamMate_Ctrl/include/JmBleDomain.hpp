#pragma once
#include "JmV8.hpp"
// BLE-only layout envelope. Stored presets and the Daisy protocol stay v3.
namespace JmBleDomain {
inline bool layoutValid(const uint8_t* p){for(unsigned i=0;i<18;i++)if(p[2*i]>16||p[2*i+1]>10)return false;return true;}
inline bool decodeParam(const uint8_t* p,size_t n,const uint8_t layout[18][2],uint8_t& fx,uint8_t& flat,uint8_t& value){
 if(n!=4)return false;fx=p[0];const uint8_t kind=p[1],index=p[2];value=p[3];
 if(fx>=18||kind>2||(kind==0&&index)||(kind==1&&index>=layout[fx][0])||(kind==2&&index>=layout[fx][1]))return false;
 flat=kind==0?0:kind==1?index+1:layout[fx][0]+index+1;return true;
}
inline size_t encode(uint8_t op,const uint8_t* p,size_t n,const uint8_t layout[18][2],uint8_t* out){
 if(op==0x36&&n==3){
  const unsigned fx=p[0],flat=p[1];if(fx>=18||flat>1u*layout[fx][0]+layout[fx][1])return 0;
  out[0]=fx;out[1]=flat==0?0:flat<=layout[fx][0]?1:2;out[2]=flat==0?0:flat<=layout[fx][0]?flat-1:flat-layout[fx][0]-1;out[3]=p[2];return 4;
 }
 if(op==0x27&&n>=3&&p[0]<18){
  const unsigned fx=p[0];out[0]=fx;out[1]=layout[fx][0];out[2]=layout[fx][1];memcpy(out+3,p+2,n-2);return n+1;
 }
 if(op==0x31||op==0x34||op==0x3a){
  const size_t prefix=op==0x3a?2:0;if(n<prefix+4)return 0;
  if(prefix)memcpy(out,p,prefix);out[prefix]=4;memcpy(out+prefix+1,layout,36);memcpy(out+prefix+37,p+prefix,n-prefix);return n+37;
 }
 if(n)memcpy(out,p,n);return n;
}
}
