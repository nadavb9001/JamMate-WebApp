#pragma once
#include <stdint.h>

// Logical focus order for the 240x320 Main screen. The preset banner is not
// focusable; preset/bank changes remain on the existing momentary switches.
namespace MainHome {
    enum Item : uint8_t {
        BPM = 0,
        VOLUME = 1,
        FX = 2,
        LOOPER = 3,
        DRUMS = 4,
        TUNER = 5,
        SETUP = 6,
        ITEM_COUNT = 7
    };

    inline int Wrap(int index, int delta) {
        int next = (index + delta) % ITEM_COUNT;
        return next < 0 ? next + ITEM_COUNT : next;
    }

    inline uint8_t ClampBpm(int value) {
        if (value < 20) return 20;
        if (value > 240) return 240;
        return static_cast<uint8_t>(value);
    }

    inline uint8_t ClampVolume(int value) {
        if (value < 0) return 0;
        if (value > 100) return 100;
        return static_cast<uint8_t>(value);
    }
}
