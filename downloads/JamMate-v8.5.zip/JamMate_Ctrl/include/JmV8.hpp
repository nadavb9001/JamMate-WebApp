#pragma once
#include <stdint.h>
#include <stddef.h>
#include <string.h>
namespace JmV8 {
constexpr size_t HEADER=16, MAX=2048;
constexpr uint8_t DATA=1, ACK=2, HELLO=3;
inline uint16_t u16(const uint8_t* p){return p[0]|uint16_t(p[1])<<8;}
inline uint32_t u32(const uint8_t* p){return u16(p)|uint32_t(u16(p+2))<<16;}
inline void put16(uint8_t* p,uint16_t v){p[0]=v;p[1]=v>>8;}
inline void put32(uint8_t* p,uint32_t v){put16(p,v);put16(p+2,v>>16);}
inline uint16_t crc16(const uint8_t* p,size_t n){uint16_t c=65535;while(n--){c^=*p++;for(int j=0;j<8;j++)c=(c&1)?(c>>1)^0xa001:c>>1;}return c;}
inline uint32_t crc32(const uint8_t* p,size_t n,uint32_t c=0xffffffff){while(n--){c^=*p++;for(int j=0;j<8;j++)c=(c&1)?(c>>1)^0xedb88320:c>>1;}return c;}
inline void header(uint8_t* p,uint8_t type,uint8_t op,uint16_t id,uint16_t offset,uint16_t total,uint16_t crc,uint32_t session){
 p[0]=0xd8;p[1]=8;p[2]=type;p[3]=op;put16(p+4,id);put16(p+6,offset);put16(p+8,total);put16(p+10,crc);put32(p+12,session);
}
inline bool valid(const uint8_t* p,size_t n,uint32_t session){return n>=HEADER&&p[0]==0xd8&&p[1]==8&&session&&u32(p+12)==session;}
struct Receiver {
 uint8_t bytes[MAX+3];uint16_t id=0,total=0,used=0,crc=0;uint8_t op=0;bool complete=false;
 void reset(){id=total=used=0;complete=false;}
 // Returns true exactly once. Duplicate fragments return the cumulative offset.
 bool accept(const uint8_t* p,size_t n,uint32_t session,uint16_t& next){
  next=0xffff;
  if(!valid(p,n,session)||p[2]!=DATA||n<HEADER||!u16(p+4))return false;
  const uint16_t tx=u16(p+4),off=u16(p+6),len=u16(p+8),sum=u16(p+10);const size_t count=n-HEADER;
  if(len>MAX||off>len||count>size_t(len-off)||(!count&&len))return false;
  if(tx!=id){if(off){next=0;return false;}id=tx;total=len;used=0;crc=sum;op=p[3];complete=false;}
  if(len!=total||sum!=crc||op!=p[3])return false;
  next=used;
  if(off<used){if(off+count<=used&&memcmp(bytes+3+off,p+HEADER,count)==0)next=used;return false;}
  if(off!=used||complete)return false;
  memcpy(bytes+3+used,p+HEADER,count);used+=count;next=used;
  if(used!=total)return false;
  if(crc16(bytes+3,total)!=crc){used=0;next=0;return false;}
  bytes[0]=op;put16(bytes+1,total);complete=true;return true;
 }
};
}

namespace JmV8 {
// Access under the transport mutex. Only BLE callbacks modify characteristic
// values; the sender stores bounded bytes here, avoiding String races.
struct Readback {
 uint8_t data[244]{},ack[HEADER]{},hello[20]{};uint16_t size=0,ackSize=0,helloSize=0;
 void capture(const uint8_t* p,size_t n,uint32_t session){
  if(n==20&&p[2]==HELLO){memcpy(hello,p,n);helloSize=n;return;}
  if(!valid(p,n,session))return;
  if(p[2]==DATA&&n<=sizeof(data)){memcpy(data,p,n);size=n;helloSize=0;}
  if(p[2]==ACK&&n==sizeof(ack)){memcpy(ack,p,n);ackSize=n;}
 }
 size_t copy(uint8_t type,uint8_t* out,uint32_t session)const{
  if(type==DATA&&helloSize){memcpy(out,hello,helloSize);return helloSize;}
  const auto* p=type==ACK?ack:data;const size_t n=type==ACK?ackSize:size;
  if(!n||!valid(p,n,session))return 0;memcpy(out,p,n);return n;
 }
};

}
