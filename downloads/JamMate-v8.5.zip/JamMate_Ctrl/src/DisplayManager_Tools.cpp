#include "DisplayManager.h"
#include "JmSetupPortrait.hpp"
#include "JmLooperPortrait.hpp"
#include "LooperRingPlan.hpp"
#include "JmDrumPortrait.hpp"
#include "BluetoothManager_binary.hpp"

extern void sendToDSP(const char cmd[4], uint8_t *payload, size_t len);
extern BluetoothManager btManager;
extern bool checkUART;
extern uint32_t uartStartTime;
extern uint32_t lastUartAttempt;
extern void syncSetupA2DPEnabledFromDisplay(bool enabled);

// ===================================================================
// LOOPER IMPLEMENTATION
// ===================================================================

// Sends the 16-byte jm_looper update_param frame.
// Button args are momentary (1 = pressed this frame, auto-cleared by DSP edge-detection).
// Config values (sync, autoArm, bars, level, track) are always included.
void DisplayManager::sendLooperPacket(int recBtn, int stopBtn, int clearBtn, int undoBtn, int redoBtn)
{
  uint8_t p[16] = {};
  p[0] = (uint8_t)looperNum; // track select 0-3
  p[1] = recBtn ? 1 : 0;     // record button (rising-edge in DSP)
  p[2] = stopBtn ? 1 : 0;    // stop button
  p[3] = clearBtn ? 1 : 0;   // clear button
  p[4] = undoBtn ? 1 : 0;    // undo button
  p[5] = redoBtn ? 1 : 0;    // redo button
  // p[6] stop-all, p[7] clear-all: 0
  p[8] = (uint8_t)looperSync;     // 0=NONE,1=BEAT,2=BAR,3=DRUM_START
  p[9] = (uint8_t)looperPlayMode; // 0=PARALLEL,1=SERIES
  p[10] = (uint8_t)looperBars;    // auto-stop after N bars (0=free)
  p[11] = looperAutoArm ? 1 : 0;  // auto-arm enable
  p[12]=looperBounce?1:0;p[13]=looperMute;p[14]=looperSolo;
  p[15] = (uint8_t)looperLevel; // master level 0-127

  // Debug output
  if (recBtn || stopBtn || clearBtn || undoBtn || redoBtn)
  {
    Serial.printf("[LOOPER] SendPacket BUTTONS: rec=%d stop=%d clear=%d undo=%d redo=%d\n",
                  recBtn, stopBtn, clearBtn, undoBtn, redoBtn);
  }
  Serial.printf("[LOOPER] SendPacket CONFIG: track=%d sync=%d autoArm=%d bars=%d playMode=%d level=%d\n",
                p[0], p[8], p[11], p[10], p[9], p[15]);

  sendToDSP("LOOP", p, 16);
  // Explicit release: DSP uses rising-edge detection, so successive Record
  // presses must have a zero frame in between, even across BLE/UI actions.
  if (recBtn || stopBtn || clearBtn || undoBtn || redoBtn)
  {
    for (int i = 1; i <= 7; ++i) p[i] = 0;
    sendToDSP("LOOP", p, 16);
  }
}

// Single state machine for looper display state.
// Called from both switch handlers and DSP notification — one code path.
//   trigger 0 = REC button pressed
//   trigger 1 = DSP notified: armed→recording fired (audio threshold)
//   trigger 2 = STOP button pressed
//   trigger 3 = UNDO/CLEAR button pressed
void DisplayManager::applyLooperStateChange(int trigger, uint32_t loopMs)
{
  // looperTrackState: 0=IDLE,1=ARMED,2=WAITING_SYNC,3=RECORDING,4=PLAYING
  const char *stateNames[] = {"IDLE", "ARMED", "WAIT", "REC", "PLAY"};
  int oldState = looperTrackState;

  switch (trigger)
  {
  case 0: // REC pressed
    if (looperTrackState == 0)
    { // IDLE
      if (looperAutoArm)
      {
        looperTrackState = 1; // → ARMED
      }
      else if (looperSync != 0)
      {
        looperTrackState = 2; // → WAIT for bar/beat/DrumStart DSP confirmation
      }
      else
      {
        looperTrackState = 3; // → RECORDING immediately (unsynced)
        loopStart = millis();
        currentArcAngle = 0.0f;
        lastStepTime = millis();
      }
    }
    else if (looperTrackState == 1)
    { // ARMED → manual override; synced modes still wait for transport
      looperTrackState = (looperSync != 0) ? 2 : 3;
      if (looperTrackState == 3)
      {
        loopStart = millis();
        currentArcAngle = 0.0f;
        lastStepTime = millis();
      }
    }
    else if (looperTrackState == 2)
    { // Record again while waiting cancels the queued start.
      looperTrackState = 0;
    }
    else if (looperTrackState == 3)
    { // RECORDING → close loop
      if (loopLayerCount == 0)
      { // first loop only: fix the length
        loopLength = millis() - loopStart;
        loopLength = (loopLength / 16) * 16;
        loopLayerCount = 1;
        looperTrackState = 4; // → PLAYING
        currentArcAngle = 0.0f;
        lastStepTime = millis(); // reset arc for first loop
      }
      else
      { // overdub: keep arc rolling
        loopLayerCount++;
        looperTrackState = 4; // → PLAYING (no arc reset)
      }
    }
    else if (looperTrackState == 4)
    {                       // PLAYING → overdub
      looperTrackState = 3; // → RECORDING
    }
    Serial.printf("[LOOPER] REC pressed: %s → %s\n", stateNames[oldState], stateNames[looperTrackState]);
    break;

  case 1: // DSP notification: actual recording began (authoritative)
    // Handle dropped/late ESP control packets too, not only ARMED/WAIT.
    looperTrackState = 3;
    if (loopLayerCount == 0) {
      loopStart = millis();
      currentArcAngle = 0.0f;
      lastStepTime = millis();
    }
    break;

  case 2: // STOP
    looperTrackState = 0;
    loopLength = 0;
    currentArcAngle = 0.0f;
    lastStepTime = 0;
    break;

  case 3: // UNDO / CLEAR
    if (loopLayerCount > 0)
      loopLayerCount--;
    if (loopLayerCount == 0)
    {
      looperTrackState = 0;
      loopLength = 0;
      currentArcAngle = 0.0f;
      lastStepTime = 0;
    }
    break;

  case 4: // DSP notification: first loop closed (manual stop or bars auto-stop)
    if (looperTrackState == 3 || loopLayerCount == 0)
    { // DSP status is authoritative even if local button state was lost
      if (loopMs > 0)
        loopLength = loopMs; // sync arc to DSP loop length
      else
        loopLength = millis() - loopStart; // fallback
      loopLength = (loopLength / 16) * 16;
      loopLayerCount = 1;
      looperTrackState = 4; // → PLAYING
      currentArcAngle = 0.0f;
      lastStepTime = millis();
    }
    break;
  }
  isRecording = (looperTrackState == 3);
  // The DSP's LOOP status (trigger 1) is authoritative for actual onset.
  // Local button state is provisional in quantized modes.
  if (trigger == 1 && looperTrackState == 3 && loopLayerCount == 0)
  {
    loopStart = millis();
    looperBeatPhase.Reset();
    if (looperSync != 0)
      looperBeatPhase.OnRecordingStart(beatClock, loopStart, (uint8_t)looperSync);
  }
  else if (trigger == 0 && oldState == 0 && looperTrackState == 3 && looperSync == 0)
  {
    looperBeatPhase.Reset(); // unquantized: local time fallback
  }
  else if (trigger == 4 && looperTrackState == 4 && loopLayerCount == 1)
  {
    looperBeatPhase.OnLoopClosed(beatClock, (uint32_t)loopLength, (uint8_t)looperBars);
  }
  else if ((trigger == 2 || trigger == 3) && looperTrackState == 0)
  {
    looperBeatPhase.Reset();
  }
}

void DisplayManager::handleLooperMode()
{
  updateLooperVisuals();

  if (encoder1.isLongClick())
  {
    currentState = STATE_MAIN_MENU;
    encoder1.setPosition(currentRectIndex);
    drawMainScreen();
    return;
  }

  int newPos = encoder1.getPosition();
  bool click = encoder1.isButtonPressed();

  if (!looperAdjusting)
  {
    if (newPos != lastEncoder1Pos)
    {
      looperRectIndex += (newPos > lastEncoder1Pos) ? 1 : -1;
      if (looperRectIndex < 0)
        looperRectIndex = 5;
      if (looperRectIndex > 5)
        looperRectIndex = 0;
      drawLooperSettings();
      lastEncoder1Pos = newPos;
    }
    if (click)
    {
      looperAdjusting = true;
      int val = 0;
      switch (looperRectIndex)
      {
      case 0:
        val = looperLevel;
        break;
      case 1:
        val = looperNum;
        break;
      case 2:
        val = looperSync;
        break;
      case 3:
        val = looperAutoArm ? 1 : 0;
        break;
      case 4:
        val = looperBars;
        break;
      case 5:
        val = looperPlayMode;
        break;
      }
      encoder1.setPosition(val);
      lastEncoder1Pos = val;
      drawLooperSettings();
    }
  }
  else
  {
    // ADJUSTING
    if (newPos != lastEncoder1Pos)
    {
      int val = newPos;
      switch (looperRectIndex)
      {
      case 0:
        if (val < 0)
          val = 0;
        if (val > 127)
          val = 127;
        looperLevel = val;
        break;
      case 1:
        if (val < 0)
          val = 0;
        if (val > 3)
          val = 3;
        looperNum = val;
        break;
      case 2:
        if (val < 0)
          val = 0;
        if (val > 3)
          val = 3;
        looperSync = val;
        break;
      case 3:
        if (val < 0)
          val = 0;
        if (val > 1)
          val = 1;
        looperAutoArm = (val == 1);
        break;
      case 4:
        if (val < 0)
          val = 0;
        if (val > 16)
          val = 16;
        looperBars = val;
        break;
      case 5:
        if (val < 0)
          val = 0;
        if (val > 1)
          val = 1;
        looperPlayMode = val;
        break;
      }
      if (val != newPos)
        encoder1.setPosition(val);
      lastEncoder1Pos = val;
      sendLooperPacket(); // config update, no button bits
      if(looperRectIndex==1) drawLooperScreen(false); // selected track changed
      else drawLooperSettings();
    }
    if (click)
    {
      looperAdjusting = false;
      encoder1.setPosition(looperRectIndex);
      lastEncoder1Pos = looperRectIndex;
      drawLooperSettings();
    }
  }

  // --- SWITCH 1: cycle through IDLE→ARMED→REC→PLAY→OVERDUB ---
  if (switch1.isButtonPressed())
  {
    Serial.println("[LOOPER] SWITCH1 PRESSED");
    applyLooperStateChange(0);
    sendLooperPacket(1, 0, 0, 0, 0); // rec=1
    drawLooperScreen(false);
  }

  // --- SWITCH 2: cancel arm / undo layer / clear track ---
  if (switch2.isButtonPressed())
  {
    Serial.println("[LOOPER] SWITCH2 PRESSED");
    if (looperTrackState == 1)
    {                                  // ARMED: cancel arm via stop
      applyLooperStateChange(2);       // → IDLE locally
      sendLooperPacket(0, 1, 0, 0, 0); // stop=1 (DSP cancels arm)
    }
    else
    {
      bool willClear = (loopLayerCount <= 1);
      applyLooperStateChange(3);
      if (willClear)
        sendLooperPacket(0, 0, 1, 0, 0); // clear=1
      else
        sendLooperPacket(0, 0, 0, 1, 0); // undo=1
    }
    drawLooperScreen(false);
  }
}

// Display-only adapter. Uses the existing ESP values and DSP BEAT clock.
// The legacy LOOP packet reports *selected-track* record start/close, not
// independent states for tracks 1..4; unknown tabs are shown with "--".
static JmLooperPortrait::Model makeLooperPortraitModel(DisplayManager& d)
{
  JmLooperPortrait::Model m;
  m.track = (uint8_t)(d.looperNum < 0 ? 0 : (d.looperNum > 3 ? 3 : d.looperNum));
  m.state = (uint8_t)(d.looperTrackState < 0 ? 0 : (d.looperTrackState > 4 ? 4 : d.looperTrackState));
  m.layers = (uint8_t)(d.loopLayerCount < 0 ? 0 : (d.loopLayerCount > 99 ? 99 : d.loopLayerCount));
  m.level = (uint8_t)(d.looperLevel < 0 ? 0 : (d.looperLevel > 127 ? 127 : d.looperLevel));
  m.sync = (uint8_t)d.looperSync;
  m.auto_arm = d.looperAutoArm;
  m.bars = (uint8_t)(d.looperBars < 0 ? 0 : (d.looperBars > 16 ? 16 : d.looperBars));
  m.play_mode = (uint8_t)d.looperPlayMode;
  m.selected = (uint8_t)(d.looperRectIndex < 0 ? 0 : (d.looperRectIndex > 5 ? 5 : d.looperRectIndex));
  m.editing = d.looperAdjusting;

  const uint32_t now = millis();
  if (d.beatClock.Active(now)) {
    m.beat = (uint8_t)(d.beatClock.BeatIndex() + 1u);
    m.beats_per_bar = d.beatClock.BeatsPerBar();
    m.beat_lit = d.beatClock.Lit(now);
    m.downbeat = d.beatClock.LastWasDownbeat();
    const double f = d.looperBeatPhase.Fraction(
        d.beatClock, now, (uint8_t)d.looperBars, d.looperTrackState == 3);
    if (f >= 0.0 && f < 1.0) m.progress = (float)f;
  }
  // If the DSP beat anchor is unavailable, a free-running loop's local length
  // gives only an approximate progress display, never an authoritative beat.
  if (m.progress < 0.f && d.looperTrackState >= 3) {
    // The original UI animated the first free-length take even before it
    // had a known duration. This two-second *display* cycle is not a claim
    // about DSP loop length or recording start/stop time.
    const uint32_t duration = d.loopLength > 0 ? (uint32_t)d.loopLength : 2000u;
    m.progress = (float)((now - (uint32_t)d.loopStart) % duration) / duration;
  }
  if (m.progress >= 0.f && m.bars > 0 && d.looperTrackState >= 3) {
    int bar = 1 + int(m.progress * m.bars);
    if(bar > m.bars) bar=m.bars;
    m.loop_bar = (uint8_t)bar;
  }
  m.cpu = d.lastDspCpuPercent;
  return m;
}

void DisplayManager::drawLooperDynamic(bool force)
{
  if(currentState != STATE_LOOPER)return;
  const auto m = makeLooperPortraitModel(*this);
  const bool init = force || !looperDynamicBaseReady;
  if(init){
    // Full panel construction is limited to entry/full-screen recovery.
    // On normal frames only the annulus, changed digit, or state is painted.
    JmLooperPortrait::staticDynamic(tft);
    looperDynamicBaseReady = true;
    looperLastProgressStep = -1;
    looperLastState = -1;
    looperLastLayers = -1;
    looperLastBeat = -1;
    looperLastMeter = -1;
    looperLastBar = -1;
    looperLastBarsConfig = -1;
    looperLastTrack = -1;
  }
  float f = m.progress < 0.f ? 0.f : m.progress;
  if(f > 1.f)f = 1.f;
  const int progressStep = int(f * 360.f + 0.5f);
  const bool stateChanged = m.state != looperLastState;
  const auto plan = JmLooperRing::Plan(looperLastProgressStep,
                                      progressStep,init || stateChanged);
  if(plan.changed){
    if(!init && plan.erase_end > plan.erase_begin)
      JmLooperPortrait::ringSegments(tft,plan.erase_begin,plan.erase_end,
                         JmLooperPortrait::c(tft,33,58,77));
    if(plan.paint_end > plan.paint_begin)
      JmLooperPortrait::ringSegments(tft,plan.paint_begin,plan.paint_end,
                         JmLooperPortrait::stateColor(tft,m.state));
    looperLastProgressStep = plan.next;
  }
  if(init || stateChanged || m.layers != looperLastLayers){
    JmLooperPortrait::ringCentre(tft,m);
    looperLastState = m.state;
    looperLastLayers = m.layers;
  }
  if(init || m.track != looperLastTrack){
    JmLooperPortrait::trackLabel(tft,m);
    looperLastTrack = m.track;
  }
  if(init || m.beat != looperLastBeat ||
     m.beats_per_bar != looperLastMeter){
    JmLooperPortrait::beatNumber(tft,m);
    JmLooperPortrait::beatMarkers(tft,m);
    looperLastBeat = m.beat;
    looperLastMeter = m.beats_per_bar;
  }
  if(init || m.loop_bar != looperLastBar || m.bars != looperLastBarsConfig){
    JmLooperPortrait::barNumber(tft,m);
    looperLastBar = m.loop_bar;
    looperLastBarsConfig = m.bars;
  }
}

void DisplayManager::updateLooperVisuals()
{
  const uint32_t now = millis();
  if((uint32_t)(now-lastStepTime) < 40u) return; // at most 25fps
  lastStepTime=now;
  drawLooperDynamic();
}

void DisplayManager::drawLooperSettings(){
  if(currentState != STATE_LOOPER)return;
  const auto m=makeLooperPortraitModel(*this);
  const int values[6]={m.level,m.track,m.sync,int(m.auto_arm),m.bars,m.play_mode};
  for(int i=0;i<6;++i){
    const bool selectionChanged =
       (i==looperLastParamSelected || i==m.selected) &&
       (looperLastParamSelected!=m.selected || looperLastParamEditing!=m.editing);
    if(values[i]!=looperLastParamValues[i] || selectionChanged){
      JmLooperPortrait::parameter(tft,m,i);
      looperLastParamValues[i]=values[i];
    }
  }
  looperLastParamSelected=m.selected;
  looperLastParamEditing=m.editing;
}

void DisplayManager::drawLooperScreen(bool full)
{
  if(currentState != STATE_LOOPER)return;
  if(full){
    const auto m=makeLooperPortraitModel(*this);
    tft.fillScreen(JmLooperPortrait::bg(tft));
    JmLooperPortrait::header(tft);
    JmLooperPortrait::footer(tft,m);
    beatLedLastAppearance=-1;
    drawBeatLed(true);
    looperDynamicBaseReady=false;
    looperUiNeedsParameters=false;
    for(int &v : looperLastParamValues)v=-1;
    looperLastParamSelected=-1;
  }
  drawLooperSettings();
  drawLooperDynamic(full);
}

void DisplayManager::drawLooperControl(int idx, const char *label, String value, bool selected, bool adjusting)
{
  int r = idx / 2, c = idx % 2;
  int w = 110, h = 30;
  int x = 5 + c * 120;
  int y = 5 + r * 35;
  int radius = 4;

  if (y + h > 145)
    return;

  uint16_t bgColor = TFT_DARKGREY;
  tft.fillRoundRect(x - HIGHLIGHT_BORDER_THICKNESS, y - HIGHLIGHT_BORDER_THICKNESS,
                    w + 2 * HIGHLIGHT_BORDER_THICKNESS, h + 2 * HIGHLIGHT_BORDER_THICKNESS,
                    radius + HIGHLIGHT_BORDER_THICKNESS, TFT_BLACK);
  tft.fillRoundRect(x, y, w, h, radius, bgColor);

  tft.setTextDatum(ML_DATUM);
  tft.setTextColor(TFT_LIGHTGREY, bgColor);
  tft.setFreeFont(&FONT_GENERAL_NORMAL);
  tft.drawString(label, x + 5, y + h / 2);

  uint16_t valColor = (selected && adjusting) ? TFT_YELLOW : TFT_WHITE;
  tft.setTextDatum(MR_DATUM);
  tft.setTextColor(valColor, bgColor);
  tft.drawString(value, x + w - 5, y + h / 2);

  if (selected) {
    for (int i = 0; i < HIGHLIGHT_BORDER_THICKNESS; ++i)
      tft.drawRoundRect(x - i, y - i, w + 2 * i, h + 2 * i, radius + i, TFT_RED);
  }
}

void DisplayManager::drawLooperArc(float fromAngle, float toAngle, uint16_t color)
{
  tft.drawArc(120, 225, 80, 68, fromAngle, toAngle, color, TFT_BLACK);
}

// ===================================================================
// SETUP IMPLEMENTATION
// ===================================================================

// 240x320 scrollable SETUP page. Original 11 setting indices / packets retained.
// Encoder 1 navigates, click enters/exits adjustment, long click returns Main.
// Destructive DSP reset / flash require two separate short clicks within 5 s.
void DisplayManager::handleSetupMode()
{
  const uint32_t now = millis();
  if (setupConfirmIndex >= 0 && (int32_t)(now - setupConfirmDeadline) >= 0)
  {
    setupConfirmIndex = -1;
    drawSetupScreen(false,setupRectIndex,setupFirstVisible);
  }
  if (encoder1.isLongClick())
  {
    setupAdjusting = false;
    setupConfirmIndex = -1;
    currentState = STATE_MAIN_MENU;
    drawMainScreen();
    return;
  }

  const int pos = encoder1.getPosition();
  const int delta = pos - lastEncoder1Pos;
  lastEncoder1Pos = pos;
  const bool clicked = encoder1.isButtonPressed();
  if (!setupAdjusting)
  {
    if (delta != 0)
    {
      setupConfirmIndex = -1;
      const int previous = setupRectIndex;
      const int previousFirst = setupFirstVisible;
      const int next = (setupRectIndex + delta % JmSetupPortrait::kCount
                      + JmSetupPortrait::kCount) % JmSetupPortrait::kCount;
      setupRectIndex = next;
      if (setupRectIndex < setupFirstVisible)
          setupFirstVisible = setupRectIndex;
      if (setupRectIndex >= setupFirstVisible + JmSetupPortrait::kVisible)
          setupFirstVisible = setupRectIndex - JmSetupPortrait::kVisible + 1;
      drawSetupScreen(false,previous,previousFirst);
    }
    if (!clicked) return;
    if (setupRectIndex == 5) { sendToDSP("SD_R", nullptr, 0); return; }
    if (setupRectIndex == 8) { btManager.triggerMidiConnectionAttempt(); return; }
    if (setupRectIndex == 9 || setupRectIndex == 10)
    {
      if (setupConfirmIndex != setupRectIndex || (int32_t)(now-setupConfirmDeadline)>=0)
      {
        setupConfirmIndex = setupRectIndex;
        setupConfirmDeadline = now + 5000;
        drawSetupScreen(false,setupRectIndex,setupFirstVisible);
        return;
      }
      const int action = setupConfirmIndex;
      setupConfirmIndex = -1;
      if (action == 9)
      {
        Serial.println("[SETUP] Confirmed DSP reset");
        showMessage("Resetting DSP...");
        sendToDSP("RST ", nullptr, 0);
        delay(200); // Allow UART framing/queued TX to drain before shutdown.
        dspSerial.end();
        dspSerialOn = false;
        checkUART = true;
        uartStartTime = 0;
        lastUartAttempt = 0;
      }
      else
      {
        Serial.println("[SETUP] Confirmed DSP flash");
        showMessage("Flashing DSP...");
        sendToDSP("FLSH", nullptr, 0);
        delay(200); // Allow UART framing/queued TX to drain before shutdown.
        dspSerial.end();
        dspSerialOn = false;
      }
      return;
    }
    setupAdjusting = true;
    // Keep a continuous encoder count: change values relative to their current value.
    drawSetupScreen(false,setupRectIndex,setupFirstVisible);
    return;
  }

  if (delta != 0)
  {
    switch (setupRectIndex)
    {
    case 0: noiseEnabled = delta > 0; sendSetupPacket(0); break;
    case 1: noiseLevel = constrain(noiseLevel + delta, 0, 100); sendSetupPacket(0); break;
    case 2: toneEnabled = delta > 0; sendSetupPacket(1); break;
    case 3: toneLevel = constrain(toneLevel + delta, 0, 100); sendSetupPacket(1); break;
    case 4: toneFreq = constrain(toneFreq + delta * 10, 20, 5000); sendSetupPacket(1); break;
    case 6:
      btAudioEnabled = delta > 0;
      syncSetupA2DPEnabledFromDisplay(btAudioEnabled);
      if (btAudioEnabled) btManager.enableA2DP();
      else btManager.disableA2DP();
      break;
    case 7:
      btAudioVol = constrain(btAudioVol + delta, 0, 127);
      btManager.setA2DPvolume((uint8_t)btAudioVol);
      break;
    default: break;
    }
    drawSetupScreen(false,setupRectIndex,setupFirstVisible);
  }
  if (clicked)
  {
    setupAdjusting = false;
    drawSetupScreen(false,setupRectIndex,setupFirstVisible);
  }
}

void DisplayManager::sendSetupPacket(int type)
{
  if (type == 0) {
    uint8_t p[2] = {(uint8_t)(noiseEnabled ? 1 : 0), (uint8_t)noiseLevel};
    sendToDSP("NOIS", p, 2);
  } else if (type == 1) {
    uint8_t p[4] = {(uint8_t)(toneEnabled ? 1 : 0), (uint8_t)toneLevel,
                    (uint8_t)(toneFreq >> 8), (uint8_t)(toneFreq & 0xFF)};
    sendToDSP("TONE", p, 4);
  }
}

void DisplayManager::drawSetupScreen(bool full,int previousIndex,int previousFirst)
{
  JmSetupPortrait::Model m{};
  static const char* labels[] = {"Noise", "Noise level", "Test tone", "Tone level",
                                "Tone freq", "Read SD", "BT Audio", "BT volume",
                                "BLE scan", "Reset DSP", "Flash DSP"};
  char values[JmSetupPortrait::kCount][20]{};
  snprintf(values[0],sizeof(values[0]),"%s",noiseEnabled?"ON":"OFF");
  snprintf(values[1],sizeof(values[1]),"%d%%",noiseLevel);
  snprintf(values[2],sizeof(values[2]),"%s",toneEnabled?"ON":"OFF");
  snprintf(values[3],sizeof(values[3]),"%d%%",toneLevel);
  snprintf(values[4],sizeof(values[4]),"%d Hz",toneFreq);
  snprintf(values[5],sizeof(values[5]),"RUN");
  snprintf(values[6],sizeof(values[6]),"%s",btAudioEnabled?"ON":"OFF");
  snprintf(values[7],sizeof(values[7]),"%d",btAudioVol);
  snprintf(values[8],sizeof(values[8]),"START");
  snprintf(values[9],sizeof(values[9]),"RUN");
  snprintf(values[10],sizeof(values[10]),"RUN");
  for(int i=0;i<JmSetupPortrait::kCount;++i)
  {
    const bool sw=(i==0||i==2||i==6);
    const bool action=(i==5||i==8||i==9||i==10);
    const int prog=(i==1)?noiseLevel:(i==3)?toneLevel:
                   (i==4)?(toneFreq*100/5000):(i==7)?(btAudioVol*100/127):0;
    const bool enabled=(i==0)?noiseEnabled:(i==2)?toneEnabled:(i==6)?btAudioEnabled:false;
    m.items[i]={labels[i],values[i],(uint8_t)constrain(prog,0,100),
                 action?JmSetupPortrait::ACTION:(sw?JmSetupPortrait::SWITCH:JmSetupPortrait::VALUE),enabled};
  }
  m.selected=(uint8_t)setupRectIndex;
  m.first_visible=(uint8_t)setupFirstVisible;
  m.editing=setupAdjusting;
  m.confirm_action=(int8_t)setupConfirmIndex;
  m.cpu=lastDspCpuPercent;
  if(full) {
    JmSetupPortrait::draw(tft,m);
    beatLedLastAppearance=-1;drawBeatLed(true);
  } else {
    const int first=setupFirstVisible;
    if(previousFirst!=first) {
      for(int j=0;j<JmSetupPortrait::kVisible;j++) {
        const int i=first+j;
        JmSetupPortrait::row(tft,j,m.items[i],i==setupRectIndex,
                           i==setupRectIndex&&setupAdjusting,setupConfirmIndex==i);
      }
      tft.fillRect(233,38,3,241,JmSetupPortrait::edge(tft));
      tft.fillRect(233,38+(first*241)/JmSetupPortrait::kCount,3,
                   JmSetupPortrait::kVisible*241/JmSetupPortrait::kCount,
                   JmSetupPortrait::cyan(tft));
    } else {
      if(previousIndex>=first && previousIndex<first+JmSetupPortrait::kVisible)
        JmSetupPortrait::row(tft,previousIndex-first,m.items[previousIndex],
                previousIndex==setupRectIndex,
                setupAdjusting&&previousIndex==setupRectIndex,
                setupConfirmIndex==previousIndex);
      if(setupRectIndex>=first && setupRectIndex<first+JmSetupPortrait::kVisible &&
         setupRectIndex!=previousIndex)
        JmSetupPortrait::row(tft,setupRectIndex-first,m.items[setupRectIndex],true,
                             setupAdjusting,setupConfirmIndex==setupRectIndex);
    }
  }
}

// ===================================================================
// DRUM IMPLEMENTATION
// ===================================================================

// Uses the DrumStart DSP's TCTL packet for style/BPM/on-off updates.
// Level is part of the existing 12-byte DRUM config packet. Preserve looper
// fields when sending it, otherwise a level change could disable the looper.
static void sendDrumTctl(uint8_t operation, uint8_t lo, uint8_t hi=0)
{
  uint8_t payload[4]={1,operation,lo,hi};
  sendToDSP("TCTL",payload,sizeof(payload));
}

void DisplayManager::updateDrumVisuals()
{
  const uint32_t now=millis();
  // At most 25FPS; update only on a new DSP beat, a pulse expiry, or timeout.
  if ((uint32_t)(now-lastDrumBeatFrameMs)<40u) return;
  lastDrumBeatFrameMs=now;
  const bool active=drumEnabled && beatClock.Active(now);
  const int beat=active?int(beatClock.BeatIndex()+1u):0;
  const bool lit=active && beatClock.Lit(now);
  const int key=(active?0x100:0)|(lit?0x200:0)|beat|
                ((active?beatClock.BeatsPerBar():0)<<10);
  if (key==lastDrumBeatKey) return;
  lastDrumBeatKey=key;
  JmDrumPortrait::Model m;
  m.clock_active=active;
  m.beat=(uint8_t)beat;
  m.beats=active?beatClock.BeatsPerBar():4;
  m.bar=active?beatClock.BarIndex():0;
  m.beat_lit=lit;
  static TFT_eSprite sprite(&tft);
  static bool initialized=false,available=false;
  if(!initialized){initialized=true;sprite.setColorDepth(8);
    available=sprite.createSprite(226,134)!=nullptr;}
  if(available){JmDrumPortrait::beatAreaSprite(sprite,m);sprite.pushSprite(7,34);}
  else JmDrumPortrait::beatArea(tft,m);
}

void DisplayManager::handleDrumMode()
{
  if (encoder1.isLongClick()) {
    currentState=STATE_MAIN_MENU;
    encoder1.setPosition(currentRectIndex);
    lastEncoder1Pos=currentRectIndex;
    drawMainScreen();
    return;
  }
  const int pos=encoder1.getPosition();
  const int delta=pos-lastEncoder1Pos;
  const bool click=encoder1.isButtonPressed();
  if(delta!=0){
    lastEncoder1Pos=pos;
    if(!drumAdjusting){
      int next=(drumRectIndex+delta)%4;
      if(next<0)next+=4;
      drumRectIndex=next;
    } else {
      switch(drumRectIndex){
        case 0: {
          const int next=drumStyle+delta;
          drumStyle=next<0?0:next>3?3:next;
          sendDrumTctl(5,(uint8_t)drumStyle);
          break;
        }
        case 1: {
          const int next=int(currentPreset.bpm)+delta;
          const int bpm=next<20?20:next>250?250:next;
          if(bpm != currentPreset.bpm) {
            setTempo((uint8_t)bpm);
            // Shared transport controls the actual musical tempo.

          }
          break;
        }
        case 2: {
          const int next=drumLevel+delta;
          drumLevel=next<0?0:next>100?100:next;
          // TCTL op 8 is a small *drum-only* level update. Never send the
          // legacy 12-byte DRUM composite here: that could overwrite looper
          // enable/sync/recording settings while the user changes volume.
          sendDrumTctl(8,(uint8_t)drumLevel);
          break;
        }
        case 3: {
          const bool enable=delta>0;
          if(enable!=drumEnabled){
            drumEnabled=enable;
            if(!enable)beatClock.Invalidate();
            sendDrumTctl(4,enable?1:0);
          }
          break;
        }
      }
    }
    drawDrumSettings();
  }
  if(click){
    drumAdjusting=!drumAdjusting;
    if(drumAdjusting){
      int val=0;
      switch(drumRectIndex){
        case 0:val=drumStyle;break;
        case 1:val=currentPreset.bpm;break;
        case 2:val=drumLevel;break;
        case 3:val=drumEnabled?1:0;break;
      }
      encoder1.setPosition(val);lastEncoder1Pos=val;
    } else {
      encoder1.setPosition(drumRectIndex);lastEncoder1Pos=drumRectIndex;
    }
    drawDrumSettings();
  }
}

void DisplayManager::drawDrumScreen()
{
  JmDrumPortrait::Model m;
  const uint32_t now=millis();
  m.clock_active=drumEnabled && beatClock.Active(now);
  if(m.clock_active){
    m.beat=(uint8_t)(beatClock.BeatIndex()+1u);
    m.beats=beatClock.BeatsPerBar();
    m.bar=beatClock.BarIndex();
    m.beat_lit=beatClock.Lit(now);
  }
  m.running=drumEnabled;
  m.style=(uint8_t)drumStyle;
  m.bpm=currentPreset.bpm;
  m.level=(uint8_t)drumLevel;
  m.selected=(uint8_t)drumRectIndex;
  m.editing=drumAdjusting;
  m.cpu=lastDspCpuPercent;
  lastDrumBeatFrameMs=now;
  lastDrumBeatKey=-1; // Force sync on next frame after entering screen.
  beatLedLastAppearance=-1;
  JmDrumPortrait::draw(tft,m);
  drawBeatLed(true);
}

void DisplayManager::drawDrumSettings(){
  JmDrumPortrait::Model m{};
  m.running=drumEnabled;m.style=(uint8_t)drumStyle;
  m.bpm=currentPreset.bpm;m.level=(uint8_t)drumLevel;
  m.selected=(uint8_t)drumRectIndex;m.editing=drumAdjusting;
  JmDrumPortrait::settings(tft,m);
}

void DisplayManager::drawDrumControl(int idx, const char *label, String valueStr, bool isSelected, bool isAdjusting)
{
  int r = idx / 2, c = idx % 2;
  int x = 10 + c * 115;
  int y = 38 + r * 100;
  int w = 105, h = 80, radius = 6;
  uint16_t bgColor = TFT_DARKGREY;

  tft.fillRoundRect(x - HIGHLIGHT_BORDER_THICKNESS, y - HIGHLIGHT_BORDER_THICKNESS,
                    w + 2 * HIGHLIGHT_BORDER_THICKNESS, h + 2 * HIGHLIGHT_BORDER_THICKNESS,
                    radius + HIGHLIGHT_BORDER_THICKNESS, TFT_BLACK);
  tft.fillRoundRect(x, y, w, h, radius, bgColor);

  tft.setTextDatum(TC_DATUM);
  tft.setTextColor(TFT_LIGHTGREY, bgColor);
  tft.setFreeFont(&FONT_GENERAL_NORMAL);
  tft.drawString(label, x + w / 2, y + 6);

  uint16_t valColor = (isSelected && isAdjusting) ? TFT_YELLOW : TFT_WHITE;
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(valColor, bgColor);
  tft.setFreeFont(&FONT_GENERAL_BOLD);
  tft.drawString(valueStr, x + w / 2, y + h / 2 + 6);

  if (isSelected) {
    for (int i = 0; i < HIGHLIGHT_BORDER_THICKNESS; ++i)
      tft.drawRoundRect(x - i, y - i, w + 2 * i, h + 2 * i, radius + i, TFT_RED);
  }
}