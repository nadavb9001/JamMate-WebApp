/* Easy Mode parameter popup compatibility layer.
   The existing View.setupEffectsGrid() calls window.showSoloEffect(title, idx)
   after app.selectEffect(idx). This file turns that callback into a modal editor
   by moving the existing #effectControls node into a floating popup, then moving
   it back to its original place on close. This preserves all event listeners,
   knob instances, dropdown handlers and protocol callbacks. */
(function () {
  let overlay = null;
  let shell = null;
  let titleEl = null;
  let bodyEl = null;
  let closeBtn = null;
  let originalParent = null;
  let originalNextSibling = null;

  function ensurePopup() {
    if (overlay) return;

    overlay = document.createElement('div');
    overlay.id = 'easyEffectPopup';
    overlay.className = 'solo-effect-overlay easy-effect-popup';
    overlay.style.display = 'none';

    shell = document.createElement('div');
    shell.className = 'solo-effect-container easy-effect-shell';
    shell.setAttribute('role', 'dialog');
    shell.setAttribute('aria-modal', 'true');

    closeBtn = document.createElement('button');
    closeBtn.type = 'button';
    closeBtn.className = 'solo-effect-close-btn';
    closeBtn.setAttribute('aria-label', 'Close effect parameters');
    closeBtn.textContent = '×';

    titleEl = document.createElement('div');
    titleEl.className = 'solo-effect-title';

    bodyEl = document.createElement('div');
    bodyEl.className = 'easy-effect-popup-body';

    shell.append(closeBtn, titleEl, bodyEl);
    overlay.appendChild(shell);
    document.body.appendChild(overlay);

    closeBtn.addEventListener('click', window.closeSoloEffect);
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) window.closeSoloEffect();
    });
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && window.soloEffectOpen) window.closeSoloEffect();
    });
  }

  function rememberHome(node) {
    if (!originalParent) {
      originalParent = node.parentNode;
      originalNextSibling = node.nextSibling;
    }
  }

  function returnControlsHome() {
    const controls = document.getElementById('effectControls');
    if (!controls || !originalParent) return;
    if (originalNextSibling && originalNextSibling.parentNode === originalParent) {
      originalParent.insertBefore(controls, originalNextSibling);
    } else {
      originalParent.appendChild(controls);
    }
  }

  window.showSoloEffect = function showSoloEffect(title) {
    ensurePopup();
    const controls = document.getElementById('effectControls');
    if (!controls) return;

    rememberHome(controls);
    titleEl.textContent = title || 'Effect Parameters';

    bodyEl.innerHTML = '';
    bodyEl.appendChild(controls);

    document.body.classList.add('easy-popup-open');
    overlay.style.display = 'flex';
    window.soloEffectOpen = true;

    // Ensure canvas-based controls settle after being moved into the modal.
    requestAnimationFrame(() => {
      const iir = window.app && window.app.iirDesigner;
      if (iir && typeof iir.draw === 'function') iir.draw();
      shell.focus && shell.focus();
    });
  };

  window.closeSoloEffect = function closeSoloEffect() {
    if (!overlay) return;
    returnControlsHome();
    overlay.style.display = 'none';
    document.body.classList.remove('easy-popup-open');
    window.soloEffectOpen = false;
  };

  window.soloEffectOpen = false;


  window.ensureJamMateEasyMode = function ensureJamMateEasyMode(enabled) {
    const tab = document.getElementById('effects-tab');
    const btn = document.getElementById('btnEasyMode');
    if (!tab) return;
    tab.classList.toggle('easy-mode', !!enabled);
    if (btn) btn.classList.toggle('active', !!enabled);
    if (!enabled && window.closeSoloEffect) window.closeSoloEffect();
  };

  document.addEventListener('DOMContentLoaded', () => {
    ensurePopup();
    const easy = document.getElementById('btnEasyMode');
    const tab = document.getElementById('effects-tab');
    if (tab) {
      const obs = new MutationObserver(() => {
        if (!tab.classList.contains('easy-mode')) window.closeSoloEffect();
      });
      obs.observe(tab, { attributes: true, attributeFilter: ['class'] });
    }
    if (easy) {
      easy.addEventListener('click', () => {
        requestAnimationFrame(() => {
          const tab = document.getElementById('effects-tab');
          if (tab && !tab.classList.contains('easy-mode')) window.closeSoloEffect();
        });
      });
    }
  });
})();
